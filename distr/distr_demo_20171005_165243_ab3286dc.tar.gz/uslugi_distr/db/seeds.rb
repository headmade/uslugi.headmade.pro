# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


Rake::Task['import_old:categories'].invoke
Rake::Task['import_old:passports'].invoke
Rake::Task['import:external_system_request_types'].invoke

puts 'Create more passports/categories'
cat = Category.create!(name: 'Вывески', description: '', icon: '')
data = JSON.parse <<EOL
{"schema":{"definitions":{"organization":{"type":"object","properties":{"name":{"type":"string","title":"Название"},"inn":{"type":"string","title":"ИНН"},"kpp":{"type":"string","title":"КПП"},"ogrn":{"type":"string","title":"ОГРН"}}}},"title":"Паспорт типовой вывески","type":"object","required":["address"],"properties":{"organization":{"$ref":"#/definitions/organization","title":"Организация"},"address":{"type":"string","title":"Адрес объекта","default":"Казань"},"photo":{"type":"string","format":"data-url","title":"Фотографии исходной ситуации"},"frieze_geomerty":{"type":"number","title":"Форма фриза","enum":[1,2,3,4,5],"enumNames":["Полукруг","Только фронт","Фронт + боковая часть слева","Фронт + боковая часть справа","Фронт + две боковые части"],"default":2},"frieze_width":{"type":"number","format":"updown","title":"Ширина фронтальной части фриза (мм.)","minimum":1000},"frieze_height":{"type":"number","format":"updown","title":"Высота фронтальной части фриза (мм.)","minimum":500},"color":{"type":"string","format":"color","title":"Цвет фриза"},"type_of_business":{"type":"number","title":"Вид деятельности","enum":[1,2,3,4],"enumNames":["продукты","булочная","цветы","сувениры"]},"need_logo":{"type":"boolean","title":"Признак наличия логотипа"},"confirm":{"type":"boolean","title":"Подтверждаю правильность данных и даю согласие на их обработку","default":false}}}}
EOL

passport = Passport.create!(active: true, category: cat, name: 'Согласование вывески', description: 'Согласование разрешения установки вывески', documents: 'список документов: бла-бла', reglament: "1) ...\n2) ...", data: data, duration: 15.minute*PassportDecorator::DURATION_FRACTION)

puts 'Create servants'
servant = Servant.create!(surname: 'Иванов', name: 'Константин', patronymic_name: 'Геннадиевич', passports: Passport.first(2) + [passport])
s1 = Servant.create!(surname: 'Нигматуллина', name: 'Карина', patronymic_name: 'Вячеславовна')
s2 = Servant.create!(surname: 'Сафина', name: 'Лариса', patronymic_name: 'Сергеевна')

puts 'Create users'
default_password = '123'
servant_user = User.create!(phone: 'servant', password: default_password, state: :active, roles: %i(servant user), servants: [servant])
user_user = User.create!(phone: 'user', password: default_password, state: :active, roles: %i(user))

s1_user = User.create!(phone: '+79063249122', password: default_password, state: :active, roles: %i(servant), servants: [s1])
s2_user = User.create!(phone: '+79520401312', password: default_password, state: :active, roles: %i(servant), servants: [s2])

ActionContext.create_system

puts 'Create agents'
agent = Agent.create!(passport_number: '123456', surname: 'Длиннофамильский', name: 'Геннадий', patronymic_name: 'Константинович', email: 'somelongemail@somelongdomain.gov.ru', mobile: '+79876543210')

puts 'Create organizations-recipients of uslugas'
org_recipient = OrganizationRecipient.create!(inn: '1625000001', email: 'something.long@somewhere-in-the-world.dot.com', phone: '+7843123456', mobile: '+79998881234')

puts 'Create departments'
d1 = Department.create!(short_name: 'short_name_1', full_name: 'full_name_1')
d2 = Department.create!(short_name: 'short_name_2', full_name: 'full_name_2', parent: d1, servants: [servant])
d3 = Department.create!(short_name: 'short_name_3', full_name: 'full_name_3')

puts 'Create terminals'
t1 = Terminal.create!(name: 'кирмос', location: 'address', departments: d1.subtree)

puts 'Create UslugaRequests'
ur1 = UslugaRequest.create!(passport: passport, user: user_user, state: :created, agent: agent, organization_recipient: org_recipient, data: {name: :usluga, agent: agent, organization: org_recipient})

puts 'Create Uslugas'
usluga1 = Usluga.create!(passport: ur1.passport, servant: servant, user: ur1.user, usluga_request: ur1, agent: agent, organization_recipient: org_recipient, state: :created, request_data: ur1.data)

Rake::Task['import:culture_objects'].invoke
Rake::Task['import:main_streets'].invoke
Rake::Task['import:coloristic_solutions'].invoke

puts 'Done.'
