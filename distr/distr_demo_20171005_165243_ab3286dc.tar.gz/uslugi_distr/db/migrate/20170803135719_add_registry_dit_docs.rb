class AddRegistryDitDocs < ActiveRecord::Migration[5.1]
  def up
    Rake::Task['import:dit_docs'].invoke
  end
  def down
  end
end
