class CreateOrganizationRecipients < ActiveRecord::Migration[5.1]
  def change
    create_table :organization_recipients do |t|
      t.string :inn, null: false
      t.string :email
      t.string :phone
      t.string :mobile

      t.timestamps
      t.timestamp :deleted_at
    end

    add_index :organization_recipients, %i(inn), unique: true
  end
end
