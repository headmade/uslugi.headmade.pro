class CreateJoinTableDepartmentTerminal < ActiveRecord::Migration[5.1]
  def change
    create_table :departments_terminals, id: false do |t|
      t.references :department, null: false, foreign_key: true
      t.uuid :terminal_id, null: false
    end
    add_foreign_key :departments_terminals, :terminals
    add_index :departments_terminals, %i(terminal_id department_id), unique: true
  end
end
