class AddRejectDataToUslugaRequests < ActiveRecord::Migration[5.1]
  def change
    add_column :usluga_requests, :reject_data, :jsonb
  end
end
