class CreateUslugas < ActiveRecord::Migration[5.1]
  def change
    create_table :uslugas do |t|
      t.references :passport, null: false, foreign_key: true
      t.references :servant, null: false,  foreign_key: true
      t.references :user,                  foreign_key: true
      t.references :usluga_request,        foreign_key: true, index: true
      t.references :agent,                 foreign_key: true, index: true
      t.references :organization_recipient,foreign_key: true, index: true
      t.string :state, null: false
      t.jsonb :request_data, null: false
      t.jsonb :result_data

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
