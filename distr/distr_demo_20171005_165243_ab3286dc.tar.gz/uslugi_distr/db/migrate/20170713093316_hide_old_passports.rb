class HideOldPassports < ActiveRecord::Migration[5.1]
  def up
    execute 'UPDATE passports SET active = (id > 28)'
  end
  def down
    execute 'UPDATE passports SET active=true'
  end
end
