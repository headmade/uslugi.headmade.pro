class CreateTerminals < ActiveRecord::Migration[5.1]
  def change
    create_table :terminals, id: :uuid, default: 'gen_random_uuid()' do |t|
      t.string :name, null: false
      t.string :location, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
