class CreateJoinTableDepartmentServant < ActiveRecord::Migration[5.1]
  def change
    create_join_table :departments, :servants do |t|
      t.references :department, null: false, foreign_key: true
      t.references :servant, null: false, foreign_key: true
    end
    add_index :departments_servants, %i(department_id servant_id), unique: true
  end
end
