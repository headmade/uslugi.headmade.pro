class MigrateStateMachine < ActiveRecord::Migration[5.1]
  def up
    UslugaRequest.created.joins(:usluga).update_all(state: :accepted)
    Rake::Task['passport:schema_all'].invoke
  end
  def down
    puts "WARNING: cannot undo states and passport schemas"
  end
end
