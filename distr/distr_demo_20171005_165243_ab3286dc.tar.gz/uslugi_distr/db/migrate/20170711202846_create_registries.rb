class CreateRegistries < ActiveRecord::Migration[5.1]
  def up
    create_table :registries do |t|
      t.string :name, null: false
      t.jsonb :data, null: false
      t.jsonb :search, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    create_table :registry_histories do |t|
      t.references :user, null: false, foreign_key: true, index: true
      t.references :registry, null: false, foreign_key: false, index: true
      t.string :action, null: false
      t.string :previous_state, null: false
      t.string :current_state, null: false
      t.jsonb :previous, null: false
      t.jsonb :current, null: false
      t.jsonb :request_params, null: false
      t.jsonb :request_headers, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :registry_histories, :registries, on_delete: :cascade

    create_table :registry_items do |t|
      t.references :registry, null: false, index: true
      t.jsonb :data, null: false
      t.jsonb :search, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :registry_items, :registries

    create_table :registry_item_histories do |t|
      t.references :user, null: false, foreign_key: true, index: true
      t.references :registry_item, null: false, foreign_key: false, index: true
      t.string :action, null: false
      t.string :previous_state, null: false
      t.string :current_state, null: false
      t.jsonb :previous, null: false
      t.jsonb :current, null: false
      t.jsonb :request_params, null: false
      t.jsonb :request_headers, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :registry_item_histories, :registry_items, on_delete: :cascade

    Rake::Task['import:culture_objects'].invoke
    Rake::Task['import:main_streets'].invoke
    Rake::Task['import:coloristic_solutions'].invoke

    execute <<-SQL
      CREATE INDEX index_registry_items_search_inn ON registry_items((search->>'inn')) WHERE (search->>'inn') IS NOT NULL
    SQL

    execute <<-SQL
      CREATE INDEX index_registry_items_search_fias_id ON registry_items((search->>'fias_id')) WHERE (search->>'fias_id') IS NOT NULL
    SQL
  end

  def down
    drop_table :registry_items, force: :cascade
    drop_table :registries, force: :cascade
  end
end
