class RenameLandlordOrganizationToLandlordOrganizations < ActiveRecord::Migration[5.1]
  def up
    Usluga.where(passport_id: [29,43,44,45,46]).each do |u|
      rd = u.request_data
      next unless rd['lease_contracts']

      was_changed = false
      rd['lease_contracts'].each do |lc|
        if lc['landlord_organization']
          lc['landlord_organizations'] = [lc.delete('landlord_organization')]
          was_changed = true
        end
      end
      if was_changed
        u.update_columns(request_data: rd)
        p [:usluga, u.id, u]
      end
    end
  end
  def down
  end
end
