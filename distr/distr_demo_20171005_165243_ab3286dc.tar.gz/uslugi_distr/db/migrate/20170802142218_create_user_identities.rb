class CreateUserIdentities < ActiveRecord::Migration[5.1]
  def change
    create_table :user_identities do |t|
      t.references :user, foreign_key: false
      t.string :provider, null: false
      t.string :uid, null: false
      t.jsonb :data, null: false

      t.timestamps
      t.timestamp :deleted_at

      t.index %i(provider uid), unique: true
    end

    add_foreign_key :user_identities, :users, on_delete: :cascade

    User.where("phone like '+7%'").each do |u|
      u.user_identities.create!(provider: :mobile, uid: u.phone, data: {provider: :mobile, uid: u.phone})
    end
  end
end
