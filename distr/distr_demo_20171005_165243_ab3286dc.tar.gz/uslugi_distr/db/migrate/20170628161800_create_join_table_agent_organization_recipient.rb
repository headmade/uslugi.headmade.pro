class CreateJoinTableAgentOrganizationRecipient < ActiveRecord::Migration[5.1]
  def change
    create_join_table :agent, :organization_recipient do |t|
      t.references :agent, null: false, foreign_key: true
      t.references :organization_recipient, null: false, foreign_key: true
    end
    add_index :agent_organization_recipient, %i(agent_id organization_recipient_id), unique: true, name: 'index_agent_organization_recipient_on_agent_id_etc_uniq'
  end
end
