class CreateCultureObjects < ActiveRecord::Migration[5.1]
  def change
    create_table :culture_objects do |t|
      t.string :fias_id, index: true
      t.jsonb :data, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
