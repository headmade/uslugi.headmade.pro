class CreateServants < ActiveRecord::Migration[5.1]
  def change
    create_table :servants do |t|
      t.string :surname, null: false
      t.string :name, null: false
      t.string :patronymic_name, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
