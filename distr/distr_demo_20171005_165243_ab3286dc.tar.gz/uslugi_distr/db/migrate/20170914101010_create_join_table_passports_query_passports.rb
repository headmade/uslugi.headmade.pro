class CreateJoinTablePassportsQueryPassports < ActiveRecord::Migration[5.1]
  def change
    create_join_table :passports, :query_passports do |t|
      t.references :passport, null: false, foreign_key: true
      t.references :query_passport, null: false, foreign_key: true

      t.index %i(passport_id query_passport_id), unique: true, name: 'index_passports_query_passports_uniq'
    end
  end
end
