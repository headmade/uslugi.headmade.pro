class CreateDepartments < ActiveRecord::Migration[5.1]
  def change
    create_table :departments do |t|
      t.string :short_name, null: false
      t.string :full_name, null: false
      t.string :ancestry, null: true

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
