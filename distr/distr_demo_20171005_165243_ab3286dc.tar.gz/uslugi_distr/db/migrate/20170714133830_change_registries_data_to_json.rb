class ChangeRegistriesDataToJson < ActiveRecord::Migration[5.1]
  def change
    change_column :registries, :data, :json
  end
end
