class AddRejectDataToUslugas < ActiveRecord::Migration[5.1]
  def change
    add_column :uslugas, :reject_data, :jsonb
  end
end
