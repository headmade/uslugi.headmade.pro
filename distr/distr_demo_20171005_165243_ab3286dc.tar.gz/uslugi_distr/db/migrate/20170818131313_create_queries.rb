class CreateQueries < ActiveRecord::Migration[5.1]
  def change
    create_table :query_passports do |t|
      t.integer :department_id
      t.integer :servant_id
      t.integer :registry_id
      t.string :name, null: false
      t.string :state, null: false
      t.json :data, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :query_passports, :departments, column: :department_id, on_delete: :restrict
    add_foreign_key :query_passports, :servants, column: :servant_id, on_delete: :restrict
    add_foreign_key :query_passports, :registries, column: :registry_id, on_delete: :restrict

    create_table :queries do |t|
      t.references :query_passport, null: false, foreign_key: false
      t.references :usluga, null: false, foreign_key: false
      t.references :query, foreign_key: false
      t.references :servant, foreign_key: false
      t.integer :from_servant_id
      t.string :type, null: false
      t.string :state, null: false
      t.jsonb :query_params
      t.jsonb :query_data, null: false
      t.jsonb :result_data
      t.jsonb :reject_data

      t.timestamps
      t.timestamp :deleted_at
      t.timestamp :expires_at, null: false
    end

    add_foreign_key :queries, :query_passports, on_delete: :restrict # :cascade?
    add_foreign_key :queries, :uslugas, on_delete: :restrict # :cascade?
    add_foreign_key :queries, :queries, on_delete: :restrict # :cascade?

    add_foreign_key :queries, :servants, column: :from_servant_id, on_delete: :restrict
    add_foreign_key :queries, :servants, column: :servant_id, on_delete: :restrict

    create_table :query_passport_histories do |t|
      t.references :user, null: false, foreign_key: false, index: true
      t.references :query_passport, null: false, foreign_key: false, index: true
      t.string :action, null: false
      t.string :previous_state, null: false
      t.string :current_state, null: false
      t.jsonb :previous, null: false
      t.jsonb :current, null: false
      t.jsonb :request_params, null: false
      t.jsonb :request_headers, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :query_passport_histories, :users, on_delete: :cascade
    add_foreign_key :query_passport_histories, :query_passports, on_delete: :cascade

    create_table :query_histories do |t|
      t.references :user, null: false, foreign_key: false, index: true
      t.references :query, null: false, foreign_key: false, index: true
      t.references :sign_certificate, foreign_key: false, index: true
      t.string :action, null: false
      t.string :previous_state, null: false
      t.string :current_state, null: false
      t.jsonb :previous, null: false
      t.jsonb :current, null: false
      t.jsonb :request_params, null: false
      t.jsonb :request_headers, null: false

      t.jsonb :signed

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :query_histories, :users, on_delete: :cascade
    add_foreign_key :query_histories, :queries, on_delete: :cascade

    add_foreign_key :query_histories, :sign_certificates, on_delete: :restrict
  end
end
