class CreateCategories < ActiveRecord::Migration[5.1]
  def change
    create_table :categories do |t|
      t.string :name, null: false
      t.string :description, null: false
      t.string :icon, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
