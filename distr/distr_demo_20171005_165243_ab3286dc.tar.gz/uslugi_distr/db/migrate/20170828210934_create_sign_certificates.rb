class CreateSignCertificates < ActiveRecord::Migration[5.1]
  def change
    create_table :sign_certificates do |t|
      t.string :serial, null: false
      t.timestamp :expires_at, null: false, index: true
      t.jsonb :data, null: false

      t.timestamps
      t.timestamp :deleted_at

      t.index %i(serial), unique: true
    end
  end
end
