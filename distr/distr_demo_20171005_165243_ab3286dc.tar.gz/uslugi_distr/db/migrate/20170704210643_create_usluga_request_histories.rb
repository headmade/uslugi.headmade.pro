class CreateUslugaRequestHistories < ActiveRecord::Migration[5.1]
  def change
    create_table :usluga_request_histories do |t|
      t.references :user, null: false, foreign_key: true, index: true
      t.references :usluga_request, null: false, foreign_key: false, index: true
      t.string :action, null: false
      t.string :previous_state, null: false
      t.string :current_state, null: false
      t.jsonb :previous, null: false
      t.jsonb :current, null: false
      t.jsonb :request_params, null: false
      t.jsonb :request_headers, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :usluga_request_histories, :usluga_requests, on_delete: :cascade
  end
end
