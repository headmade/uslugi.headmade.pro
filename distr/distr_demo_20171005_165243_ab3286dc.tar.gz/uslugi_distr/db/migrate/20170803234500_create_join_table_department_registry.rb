class CreateJoinTableDepartmentRegistry < ActiveRecord::Migration[5.1]
  def change
    create_join_table :departments, :registries do |t|
      t.references :department, null: false, foreign_key: false # need cascade
      t.references :registry, null: false, foreign_key: false
    end
    add_index :departments_registries, %i(department_id registry_id), unique: true

    add_foreign_key :departments_registries, :departments, on_delete: :cascade
    add_foreign_key :departments_registries, :registries, on_delete: :cascade
  end
end
