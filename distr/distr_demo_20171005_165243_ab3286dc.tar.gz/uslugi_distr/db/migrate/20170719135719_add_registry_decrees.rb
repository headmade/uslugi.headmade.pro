class AddRegistryDecrees < ActiveRecord::Migration[5.1]
  def up
    Rake::Task['import:decrees'].invoke
  end
  def down
  end
end
