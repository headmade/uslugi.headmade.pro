class CreateExternalSystemRequests < ActiveRecord::Migration[5.1]
  def up
    create_table :external_system_request_types do |t|
      t.string :name, null: false
      t.jsonb :schema, null: false

      t.timestamps
      t.timestamp :deleted_at
    end

    create_table :external_system_requests do |t|
      t.references :external_system_request_type, null: false, index: false
      t.references :usluga_request, null: false, index: false
      t.jsonb :data, null: false
    end

    add_foreign_key :external_system_requests, :external_system_request_types
    add_foreign_key :external_system_requests, :usluga_requests

    add_index :external_system_requests, %i(usluga_request_id external_system_request_type_id), unique: true, name: 'index_esr_ur_uniq'

    create_join_table :external_system_request_types, :passports do |t|
      t.references :external_system_request_type, null: false, foreign_key: true, index: false
      t.references :passport, null: false, foreign_key: true, index: false
    end

    add_index :external_system_request_types_passports, %i(passport_id external_system_request_type_id), unique: true, name: 'index_passport_esrt_uniq'

    Rake::Task['import:external_system_request_types'].invoke
  end

  def down
    drop_table :external_system_request_types_passports, force: :cascade
    drop_table :external_system_requests, force: :cascade
    drop_table :external_system_request_types, force: :cascade
  end
end
