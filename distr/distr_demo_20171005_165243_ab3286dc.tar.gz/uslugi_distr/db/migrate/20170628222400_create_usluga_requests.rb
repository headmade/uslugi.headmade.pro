class CreateUslugaRequests < ActiveRecord::Migration[5.1]
  def change
    create_table :usluga_requests do |t|
      t.references :passport,               null: false,  foreign_key: true, index: true
      t.references :user,                                 foreign_key: true, index: true
      t.references :servant,                              foreign_key: true, index: true
      t.references :agent,                                foreign_key: true, index: true
      t.references :organization_recipient,               foreign_key: true, index: true

      t.string :state, null: false, index: true
      t.jsonb :data, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
