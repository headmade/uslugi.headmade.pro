class CreateUsers < ActiveRecord::Migration[5.1]
  def up
    create_table :users do |t|
      t.string :phone, null: false, unique: true
      t.string :password_digest, null: false
      t.string :state, null: false
      t.string :roles, null: false, array: true

      t.timestamps
      t.timestamp :deleted_at
    end

    User.create!(phone: 'admin', password: '123', state: :active, roles: %i(admin))

    #execute "CREATE UNIQUE INDEX user_unique_login_idx ON users (LOWER(phone))"
  end
  def down
    drop_table :users
  end
end
