class CreateAgents < ActiveRecord::Migration[5.1]
  def change
    create_table :agents do |t|
      t.string :passport_number, null: false
      t.string :surname, null: false
      t.string :name, null: false
      t.string :patronymic_name, null: false

      t.string :email
      t.string :mobile

      t.timestamps
      t.timestamp :deleted_at
    end

    add_index :agents, %i(passport_number surname), unique: true
  end
end
