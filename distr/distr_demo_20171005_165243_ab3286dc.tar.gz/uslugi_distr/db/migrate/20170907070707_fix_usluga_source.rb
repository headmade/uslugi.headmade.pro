class FixUslugaSource < ActiveRecord::Migration[5.1]
  def up
    created_by_servant = '01_servant'
    created_by_user = '02_user'

    puts '------------- 1 ---------------'
    UslugaRequest.created.joins(:usluga).each do |ur|
      u = ur.usluga
      ur.update_columns(state: :accepted, data: ur.data.merge('source' => created_by_servant))
      u.update_columns(request_data: u.request_data.merge('source' => created_by_servant))
      #puts '-----'
      #p ur.id
      #p ur
      #p u
    end
    puts '------------- 2 ---------------'
    UslugaRequest.where("data->>'source' is null").where("usluga_requests.updated_at - usluga_requests.created_at <= interval '2 second'").joins(:usluga).each do |ur|
      u = ur.usluga
      ur.update_columns(data: ur.data.merge('source' => created_by_servant))
      u.update_columns(request_data: u.request_data.merge('source' => created_by_servant))
      #puts '-----'
      #p ur.id
      #p ur
      #p u
    end
    puts '------------- 3 ---------------'
    UslugaRequest.where("data->>'source' is null").joins(:usluga).each do |ur|
      u = ur.usluga
      created_by = u.request_data['source'] || created_by_user
      #p [:created_by, u.id, u.request_data['source'], created_by]
      ur.update_columns(data: ur.data.merge('source' => created_by))
      u.update_columns(request_data: u.request_data.merge('source' => created_by))
      #puts '-----'
      #p ur.id
      #p ur
      #p u
    end
    puts '------------- 4 ---------------'
    UslugaRequest.not_consultations.where("data->>'source' is null").each do |ur|
      ur.update_columns(data: ur.data.merge('source' => created_by_user))
      #puts '-----'
      #p ur.id
      #p ur
    end
    puts '------------- 5 ---------------'
    p [:usluga_request, UslugaRequest.where("data->>'source' is null").count, UslugaRequest.consultations.count]
    p [:usluga, Usluga.where("request_data->>'source' is null").count]
    p [:usluga_request, :electronic, UslugaRequest.with_submission_type(:electronic).count]
    p [:usluga_request, :paper, UslugaRequest.with_submission_type(:paper).count]
    p [:usluga_request, :total, UslugaRequest.count]
    p [:usluga, :electronic, Usluga.with_submission_type(:electronic).count]
    p [:usluga, :paper, Usluga.with_submission_type(:paper).count]
    p [:usluga, :total, Usluga.count]
  end
  def down
    puts "WARNING: cannot undo"
  end
end
