class FixZeroInAgentPassportNumber < ActiveRecord::Migration[5.1]
  def up
    ActionContext.create_system
    UslugaRequest.where("data->>'comments' like '%паспорт%'").each do |u|
      u.data['agent']['passport_number'][0] = '0'
      u.save!
    end
  end
  def down
    ActionContext.create_system
    UslugaRequest.where("data->>'comments' like '%паспорт%'").each do |u|
      u.data['agent']['passport_number'][0] = '1'
      u.save!
    end
  end
end
