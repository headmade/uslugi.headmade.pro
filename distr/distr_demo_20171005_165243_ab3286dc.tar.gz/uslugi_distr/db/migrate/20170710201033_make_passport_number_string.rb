class MakePassportNumberString < ActiveRecord::Migration[5.1]
  def change
    UslugaRequest.connection.execute <<-EOL
      UPDATE usluga_requests SET data=JSONB_SET(data, '{"agent","passport_number"}', ('"'||(data->'agent'->>'passport_number')||'"')::jsonb)
    EOL
  end
end
