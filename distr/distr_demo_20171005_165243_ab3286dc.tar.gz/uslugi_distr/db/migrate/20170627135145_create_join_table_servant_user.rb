class CreateJoinTableServantUser < ActiveRecord::Migration[5.1]
  def change
    create_join_table :servants, :users do |t|
      t.references :servant, null: false, foreign_key: true
      t.references :user, null: false, foreign_key: true
    end
    add_index :servants_users, %i(user_id servant_id), unique: true
  end
end
