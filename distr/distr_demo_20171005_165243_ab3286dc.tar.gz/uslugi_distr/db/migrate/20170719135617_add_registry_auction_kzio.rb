class AddRegistryAuctionKzio < ActiveRecord::Migration[5.1]
  def up
    Rake::Task['import:auction_kzio'].invoke
  end
  def down
  end
end
