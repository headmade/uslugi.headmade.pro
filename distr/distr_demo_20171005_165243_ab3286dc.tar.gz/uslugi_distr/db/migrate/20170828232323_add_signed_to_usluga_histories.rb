class AddSignedToUslugaHistories < ActiveRecord::Migration[5.1]
  def change
    add_column :usluga_histories, :signed, :jsonb
    add_reference :usluga_histories, :sign_certificate, foreign_key: true
  end
end
