class CreateJoinTablePassportServant < ActiveRecord::Migration[5.1]
  def change
    create_join_table :passports, :servants do |t|
      t.references :passport, null: false, foreign_key: true
      t.references :servant, null: false, foreign_key: true
    end
    add_index :passports_servants, %i(servant_id passport_id), unique: true
  end
end
