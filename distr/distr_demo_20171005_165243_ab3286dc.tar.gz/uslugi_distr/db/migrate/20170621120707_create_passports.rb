class CreatePassports < ActiveRecord::Migration[5.1]
  def change
    create_table :passports do |t|
      t.boolean :active, null: false
      t.references :category, null: false
      t.bigint :duration, null: false
      t.string :name, null: false
      t.string :description, null: false
      t.string :reglament, null: false
      t.string :documents, null: false
      t.jsonb :data

      t.timestamps
      t.timestamp :deleted_at
    end

    add_foreign_key :passports, :categories

  end
end
