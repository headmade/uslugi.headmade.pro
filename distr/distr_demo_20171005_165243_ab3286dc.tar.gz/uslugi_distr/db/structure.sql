SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: agent_organization_recipient; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE agent_organization_recipient (
    agent_id bigint NOT NULL,
    organization_recipient_id bigint NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE agents (
    id bigint NOT NULL,
    passport_number character varying NOT NULL,
    surname character varying NOT NULL,
    name character varying NOT NULL,
    patronymic_name character varying NOT NULL,
    email character varying,
    mobile character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE agents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE agents_id_seq OWNED BY agents.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE categories (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description character varying NOT NULL,
    icon character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE categories_id_seq OWNED BY categories.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE departments (
    id bigint NOT NULL,
    short_name character varying NOT NULL,
    full_name character varying NOT NULL,
    ancestry character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE departments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE departments_id_seq OWNED BY departments.id;


--
-- Name: departments_registries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE departments_registries (
    department_id bigint NOT NULL,
    registry_id bigint NOT NULL
);


--
-- Name: departments_servants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE departments_servants (
    department_id bigint NOT NULL,
    servant_id bigint NOT NULL
);


--
-- Name: departments_terminals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE departments_terminals (
    department_id bigint NOT NULL,
    terminal_id uuid NOT NULL
);


--
-- Name: external_system_request_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE external_system_request_types (
    id bigint NOT NULL,
    name character varying NOT NULL,
    schema jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: external_system_request_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE external_system_request_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_system_request_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE external_system_request_types_id_seq OWNED BY external_system_request_types.id;


--
-- Name: external_system_request_types_passports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE external_system_request_types_passports (
    external_system_request_type_id bigint NOT NULL,
    passport_id bigint NOT NULL
);


--
-- Name: external_system_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE external_system_requests (
    id bigint NOT NULL,
    external_system_request_type_id bigint NOT NULL,
    usluga_request_id bigint NOT NULL,
    data jsonb NOT NULL
);


--
-- Name: external_system_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE external_system_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_system_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE external_system_requests_id_seq OWNED BY external_system_requests.id;


--
-- Name: organization_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE organization_recipients (
    id bigint NOT NULL,
    inn character varying NOT NULL,
    email character varying,
    phone character varying,
    mobile character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: organization_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE organization_recipients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organization_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE organization_recipients_id_seq OWNED BY organization_recipients.id;


--
-- Name: passports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE passports (
    id bigint NOT NULL,
    active boolean NOT NULL,
    category_id bigint NOT NULL,
    duration bigint NOT NULL,
    name character varying NOT NULL,
    description character varying NOT NULL,
    reglament character varying NOT NULL,
    documents character varying NOT NULL,
    data json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: passports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE passports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: passports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE passports_id_seq OWNED BY passports.id;


--
-- Name: passports_query_passports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE passports_query_passports (
    passport_id bigint NOT NULL,
    query_passport_id bigint NOT NULL
);


--
-- Name: passports_servants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE passports_servants (
    passport_id bigint NOT NULL,
    servant_id bigint NOT NULL
);


--
-- Name: queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE queries (
    id bigint NOT NULL,
    query_passport_id bigint NOT NULL,
    usluga_id bigint NOT NULL,
    query_id bigint,
    servant_id bigint,
    from_servant_id integer,
    type character varying NOT NULL,
    state character varying NOT NULL,
    query_params jsonb,
    query_data jsonb NOT NULL,
    result_data jsonb,
    reject_data jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE queries_id_seq OWNED BY queries.id;


--
-- Name: query_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE query_histories (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    query_id bigint NOT NULL,
    sign_certificate_id bigint,
    action character varying NOT NULL,
    previous_state character varying NOT NULL,
    current_state character varying NOT NULL,
    previous jsonb NOT NULL,
    current jsonb NOT NULL,
    request_params jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    signed jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: query_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE query_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: query_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE query_histories_id_seq OWNED BY query_histories.id;


--
-- Name: query_passport_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE query_passport_histories (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    query_passport_id bigint NOT NULL,
    action character varying NOT NULL,
    previous_state character varying NOT NULL,
    current_state character varying NOT NULL,
    previous jsonb NOT NULL,
    current jsonb NOT NULL,
    request_params jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: query_passport_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE query_passport_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: query_passport_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE query_passport_histories_id_seq OWNED BY query_passport_histories.id;


--
-- Name: query_passports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE query_passports (
    id bigint NOT NULL,
    department_id integer,
    servant_id integer,
    registry_id integer,
    name character varying NOT NULL,
    state character varying NOT NULL,
    data json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: query_passports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE query_passports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: query_passports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE query_passports_id_seq OWNED BY query_passports.id;


--
-- Name: registries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE registries (
    id bigint NOT NULL,
    name character varying NOT NULL,
    data json NOT NULL,
    search jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: registries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE registries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: registries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE registries_id_seq OWNED BY registries.id;


--
-- Name: registry_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE registry_histories (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    registry_id bigint NOT NULL,
    action character varying NOT NULL,
    previous_state character varying NOT NULL,
    current_state character varying NOT NULL,
    previous jsonb NOT NULL,
    current jsonb NOT NULL,
    request_params jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: registry_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE registry_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: registry_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE registry_histories_id_seq OWNED BY registry_histories.id;


--
-- Name: registry_item_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE registry_item_histories (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    registry_item_id bigint NOT NULL,
    action character varying NOT NULL,
    previous_state character varying NOT NULL,
    current_state character varying NOT NULL,
    previous jsonb NOT NULL,
    current jsonb NOT NULL,
    request_params jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: registry_item_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE registry_item_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: registry_item_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE registry_item_histories_id_seq OWNED BY registry_item_histories.id;


--
-- Name: registry_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE registry_items (
    id bigint NOT NULL,
    registry_id bigint NOT NULL,
    data jsonb NOT NULL,
    search jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: registry_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE registry_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: registry_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE registry_items_id_seq OWNED BY registry_items.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


--
-- Name: servants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE servants (
    id bigint NOT NULL,
    surname character varying NOT NULL,
    name character varying NOT NULL,
    patronymic_name character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: servants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE servants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: servants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE servants_id_seq OWNED BY servants.id;


--
-- Name: servants_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE servants_users (
    servant_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: sign_certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE sign_certificates (
    id bigint NOT NULL,
    serial character varying NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: sign_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE sign_certificates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sign_certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE sign_certificates_id_seq OWNED BY sign_certificates.id;


--
-- Name: terminals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE terminals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    location character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: user_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_identities (
    id bigint NOT NULL,
    user_id bigint,
    provider character varying NOT NULL,
    uid character varying NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: user_identities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_identities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_identities_id_seq OWNED BY user_identities.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE users (
    id bigint NOT NULL,
    phone character varying NOT NULL,
    password_digest character varying NOT NULL,
    state character varying NOT NULL,
    roles character varying[] NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: usluga_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE usluga_histories (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    usluga_id bigint NOT NULL,
    action character varying NOT NULL,
    previous_state character varying NOT NULL,
    current_state character varying NOT NULL,
    previous jsonb NOT NULL,
    current jsonb NOT NULL,
    request_params jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    signed jsonb,
    sign_certificate_id bigint
);


--
-- Name: usluga_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE usluga_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usluga_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE usluga_histories_id_seq OWNED BY usluga_histories.id;


--
-- Name: usluga_request_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE usluga_request_histories (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    usluga_request_id bigint NOT NULL,
    action character varying NOT NULL,
    previous_state character varying NOT NULL,
    current_state character varying NOT NULL,
    previous jsonb NOT NULL,
    current jsonb NOT NULL,
    request_params jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: usluga_request_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE usluga_request_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usluga_request_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE usluga_request_histories_id_seq OWNED BY usluga_request_histories.id;


--
-- Name: usluga_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE usluga_requests (
    id bigint NOT NULL,
    passport_id bigint NOT NULL,
    user_id bigint,
    servant_id bigint,
    agent_id bigint,
    organization_recipient_id bigint,
    state character varying NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    reject_data jsonb
);


--
-- Name: usluga_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE usluga_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usluga_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE usluga_requests_id_seq OWNED BY usluga_requests.id;


--
-- Name: uslugas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE uslugas (
    id bigint NOT NULL,
    passport_id bigint NOT NULL,
    servant_id bigint,
    user_id bigint,
    usluga_request_id bigint,
    agent_id bigint,
    organization_recipient_id bigint,
    state character varying NOT NULL,
    request_data jsonb NOT NULL,
    result_data jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    reject_data jsonb
);


--
-- Name: uslugas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE uslugas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uslugas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE uslugas_id_seq OWNED BY uslugas.id;


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY agents ALTER COLUMN id SET DEFAULT nextval('agents_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY categories ALTER COLUMN id SET DEFAULT nextval('categories_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments ALTER COLUMN id SET DEFAULT nextval('departments_id_seq'::regclass);


--
-- Name: external_system_request_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_request_types ALTER COLUMN id SET DEFAULT nextval('external_system_request_types_id_seq'::regclass);


--
-- Name: external_system_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_requests ALTER COLUMN id SET DEFAULT nextval('external_system_requests_id_seq'::regclass);


--
-- Name: organization_recipients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY organization_recipients ALTER COLUMN id SET DEFAULT nextval('organization_recipients_id_seq'::regclass);


--
-- Name: passports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY passports ALTER COLUMN id SET DEFAULT nextval('passports_id_seq'::regclass);


--
-- Name: queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY queries ALTER COLUMN id SET DEFAULT nextval('queries_id_seq'::regclass);


--
-- Name: query_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_histories ALTER COLUMN id SET DEFAULT nextval('query_histories_id_seq'::regclass);


--
-- Name: query_passport_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passport_histories ALTER COLUMN id SET DEFAULT nextval('query_passport_histories_id_seq'::regclass);


--
-- Name: query_passports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passports ALTER COLUMN id SET DEFAULT nextval('query_passports_id_seq'::regclass);


--
-- Name: registries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY registries ALTER COLUMN id SET DEFAULT nextval('registries_id_seq'::regclass);


--
-- Name: registry_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_histories ALTER COLUMN id SET DEFAULT nextval('registry_histories_id_seq'::regclass);


--
-- Name: registry_item_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_item_histories ALTER COLUMN id SET DEFAULT nextval('registry_item_histories_id_seq'::regclass);


--
-- Name: registry_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_items ALTER COLUMN id SET DEFAULT nextval('registry_items_id_seq'::regclass);


--
-- Name: servants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY servants ALTER COLUMN id SET DEFAULT nextval('servants_id_seq'::regclass);


--
-- Name: sign_certificates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY sign_certificates ALTER COLUMN id SET DEFAULT nextval('sign_certificates_id_seq'::regclass);


--
-- Name: user_identities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_identities ALTER COLUMN id SET DEFAULT nextval('user_identities_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: usluga_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_histories ALTER COLUMN id SET DEFAULT nextval('usluga_histories_id_seq'::regclass);


--
-- Name: usluga_request_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_request_histories ALTER COLUMN id SET DEFAULT nextval('usluga_request_histories_id_seq'::regclass);


--
-- Name: usluga_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_requests ALTER COLUMN id SET DEFAULT nextval('usluga_requests_id_seq'::regclass);


--
-- Name: uslugas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas ALTER COLUMN id SET DEFAULT nextval('uslugas_id_seq'::regclass);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: external_system_request_types external_system_request_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_request_types
    ADD CONSTRAINT external_system_request_types_pkey PRIMARY KEY (id);


--
-- Name: external_system_requests external_system_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_requests
    ADD CONSTRAINT external_system_requests_pkey PRIMARY KEY (id);


--
-- Name: organization_recipients organization_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY organization_recipients
    ADD CONSTRAINT organization_recipients_pkey PRIMARY KEY (id);


--
-- Name: passports passports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY passports
    ADD CONSTRAINT passports_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: query_histories query_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_histories
    ADD CONSTRAINT query_histories_pkey PRIMARY KEY (id);


--
-- Name: query_passport_histories query_passport_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passport_histories
    ADD CONSTRAINT query_passport_histories_pkey PRIMARY KEY (id);


--
-- Name: query_passports query_passports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passports
    ADD CONSTRAINT query_passports_pkey PRIMARY KEY (id);


--
-- Name: registries registries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registries
    ADD CONSTRAINT registries_pkey PRIMARY KEY (id);


--
-- Name: registry_histories registry_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_histories
    ADD CONSTRAINT registry_histories_pkey PRIMARY KEY (id);


--
-- Name: registry_item_histories registry_item_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_item_histories
    ADD CONSTRAINT registry_item_histories_pkey PRIMARY KEY (id);


--
-- Name: registry_items registry_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_items
    ADD CONSTRAINT registry_items_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: servants servants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY servants
    ADD CONSTRAINT servants_pkey PRIMARY KEY (id);


--
-- Name: sign_certificates sign_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY sign_certificates
    ADD CONSTRAINT sign_certificates_pkey PRIMARY KEY (id);


--
-- Name: terminals terminals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY terminals
    ADD CONSTRAINT terminals_pkey PRIMARY KEY (id);


--
-- Name: user_identities user_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_identities
    ADD CONSTRAINT user_identities_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: usluga_histories usluga_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_histories
    ADD CONSTRAINT usluga_histories_pkey PRIMARY KEY (id);


--
-- Name: usluga_request_histories usluga_request_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_request_histories
    ADD CONSTRAINT usluga_request_histories_pkey PRIMARY KEY (id);


--
-- Name: usluga_requests usluga_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_requests
    ADD CONSTRAINT usluga_requests_pkey PRIMARY KEY (id);


--
-- Name: uslugas uslugas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas
    ADD CONSTRAINT uslugas_pkey PRIMARY KEY (id);


--
-- Name: index_agent_organization_recipient_on_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_agent_organization_recipient_on_agent_id ON agent_organization_recipient USING btree (agent_id);


--
-- Name: index_agent_organization_recipient_on_agent_id_etc_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_agent_organization_recipient_on_agent_id_etc_uniq ON agent_organization_recipient USING btree (agent_id, organization_recipient_id);


--
-- Name: index_agent_organization_recipient_on_organization_recipient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_agent_organization_recipient_on_organization_recipient_id ON agent_organization_recipient USING btree (organization_recipient_id);


--
-- Name: index_agents_on_passport_number_and_surname; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_agents_on_passport_number_and_surname ON agents USING btree (passport_number, surname);


--
-- Name: index_departments_registries_on_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_registries_on_department_id ON departments_registries USING btree (department_id);


--
-- Name: index_departments_registries_on_department_id_and_registry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_departments_registries_on_department_id_and_registry_id ON departments_registries USING btree (department_id, registry_id);


--
-- Name: index_departments_registries_on_registry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_registries_on_registry_id ON departments_registries USING btree (registry_id);


--
-- Name: index_departments_servants_on_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_servants_on_department_id ON departments_servants USING btree (department_id);


--
-- Name: index_departments_servants_on_department_id_and_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_departments_servants_on_department_id_and_servant_id ON departments_servants USING btree (department_id, servant_id);


--
-- Name: index_departments_servants_on_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_servants_on_servant_id ON departments_servants USING btree (servant_id);


--
-- Name: index_departments_terminals_on_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_departments_terminals_on_department_id ON departments_terminals USING btree (department_id);


--
-- Name: index_departments_terminals_on_terminal_id_and_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_departments_terminals_on_terminal_id_and_department_id ON departments_terminals USING btree (terminal_id, department_id);


--
-- Name: index_esr_ur_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_esr_ur_uniq ON external_system_requests USING btree (usluga_request_id, external_system_request_type_id);


--
-- Name: index_organization_recipients_on_inn; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_organization_recipients_on_inn ON organization_recipients USING btree (inn);


--
-- Name: index_passport_esrt_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_passport_esrt_uniq ON external_system_request_types_passports USING btree (passport_id, external_system_request_type_id);


--
-- Name: index_passports_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_passports_on_category_id ON passports USING btree (category_id);


--
-- Name: index_passports_query_passports_on_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_passports_query_passports_on_passport_id ON passports_query_passports USING btree (passport_id);


--
-- Name: index_passports_query_passports_on_query_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_passports_query_passports_on_query_passport_id ON passports_query_passports USING btree (query_passport_id);


--
-- Name: index_passports_query_passports_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_passports_query_passports_uniq ON passports_query_passports USING btree (passport_id, query_passport_id);


--
-- Name: index_passports_servants_on_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_passports_servants_on_passport_id ON passports_servants USING btree (passport_id);


--
-- Name: index_passports_servants_on_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_passports_servants_on_servant_id ON passports_servants USING btree (servant_id);


--
-- Name: index_passports_servants_on_servant_id_and_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_passports_servants_on_servant_id_and_passport_id ON passports_servants USING btree (servant_id, passport_id);


--
-- Name: index_queries_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_query_id ON queries USING btree (query_id);


--
-- Name: index_queries_on_query_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_query_passport_id ON queries USING btree (query_passport_id);


--
-- Name: index_queries_on_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_servant_id ON queries USING btree (servant_id);


--
-- Name: index_queries_on_usluga_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_usluga_id ON queries USING btree (usluga_id);


--
-- Name: index_query_histories_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_query_histories_on_query_id ON query_histories USING btree (query_id);


--
-- Name: index_query_histories_on_sign_certificate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_query_histories_on_sign_certificate_id ON query_histories USING btree (sign_certificate_id);


--
-- Name: index_query_histories_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_query_histories_on_user_id ON query_histories USING btree (user_id);


--
-- Name: index_query_passport_histories_on_query_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_query_passport_histories_on_query_passport_id ON query_passport_histories USING btree (query_passport_id);


--
-- Name: index_query_passport_histories_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_query_passport_histories_on_user_id ON query_passport_histories USING btree (user_id);


--
-- Name: index_registry_histories_on_registry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_registry_histories_on_registry_id ON registry_histories USING btree (registry_id);


--
-- Name: index_registry_histories_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_registry_histories_on_user_id ON registry_histories USING btree (user_id);


--
-- Name: index_registry_item_histories_on_registry_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_registry_item_histories_on_registry_item_id ON registry_item_histories USING btree (registry_item_id);


--
-- Name: index_registry_item_histories_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_registry_item_histories_on_user_id ON registry_item_histories USING btree (user_id);


--
-- Name: index_registry_items_on_registry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_registry_items_on_registry_id ON registry_items USING btree (registry_id);


--
-- Name: index_registry_items_search_fias_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_registry_items_search_fias_id ON registry_items USING btree (((search ->> 'fias_id'::text))) WHERE ((search ->> 'fias_id'::text) IS NOT NULL);


--
-- Name: index_registry_items_search_inn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_registry_items_search_inn ON registry_items USING btree (((search ->> 'inn'::text))) WHERE ((search ->> 'inn'::text) IS NOT NULL);


--
-- Name: index_servants_users_on_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_servants_users_on_servant_id ON servants_users USING btree (servant_id);


--
-- Name: index_servants_users_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_servants_users_on_user_id ON servants_users USING btree (user_id);


--
-- Name: index_servants_users_on_user_id_and_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_servants_users_on_user_id_and_servant_id ON servants_users USING btree (user_id, servant_id);


--
-- Name: index_sign_certificates_on_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sign_certificates_on_expires_at ON sign_certificates USING btree (expires_at);


--
-- Name: index_sign_certificates_on_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_sign_certificates_on_serial ON sign_certificates USING btree (serial);


--
-- Name: index_user_identities_on_provider_and_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_user_identities_on_provider_and_uid ON user_identities USING btree (provider, uid);


--
-- Name: index_user_identities_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_identities_on_user_id ON user_identities USING btree (user_id);


--
-- Name: index_usluga_histories_on_sign_certificate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_histories_on_sign_certificate_id ON usluga_histories USING btree (sign_certificate_id);


--
-- Name: index_usluga_histories_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_histories_on_user_id ON usluga_histories USING btree (user_id);


--
-- Name: index_usluga_histories_on_usluga_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_histories_on_usluga_id ON usluga_histories USING btree (usluga_id);


--
-- Name: index_usluga_request_histories_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_request_histories_on_user_id ON usluga_request_histories USING btree (user_id);


--
-- Name: index_usluga_request_histories_on_usluga_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_request_histories_on_usluga_request_id ON usluga_request_histories USING btree (usluga_request_id);


--
-- Name: index_usluga_requests_on_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_requests_on_agent_id ON usluga_requests USING btree (agent_id);


--
-- Name: index_usluga_requests_on_organization_recipient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_requests_on_organization_recipient_id ON usluga_requests USING btree (organization_recipient_id);


--
-- Name: index_usluga_requests_on_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_requests_on_passport_id ON usluga_requests USING btree (passport_id);


--
-- Name: index_usluga_requests_on_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_requests_on_servant_id ON usluga_requests USING btree (servant_id);


--
-- Name: index_usluga_requests_on_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_requests_on_state ON usluga_requests USING btree (state);


--
-- Name: index_usluga_requests_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_usluga_requests_on_user_id ON usluga_requests USING btree (user_id);


--
-- Name: index_uslugas_on_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_uslugas_on_agent_id ON uslugas USING btree (agent_id);


--
-- Name: index_uslugas_on_organization_recipient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_uslugas_on_organization_recipient_id ON uslugas USING btree (organization_recipient_id);


--
-- Name: index_uslugas_on_passport_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_uslugas_on_passport_id ON uslugas USING btree (passport_id);


--
-- Name: index_uslugas_on_servant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_uslugas_on_servant_id ON uslugas USING btree (servant_id);


--
-- Name: index_uslugas_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_uslugas_on_user_id ON uslugas USING btree (user_id);


--
-- Name: index_uslugas_on_usluga_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_uslugas_on_usluga_request_id ON uslugas USING btree (usluga_request_id);


--
-- Name: passports_query_passports fk_rails_0179d4908d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY passports_query_passports
    ADD CONSTRAINT fk_rails_0179d4908d FOREIGN KEY (query_passport_id) REFERENCES query_passports(id);


--
-- Name: usluga_requests fk_rails_03886dcddd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_requests
    ADD CONSTRAINT fk_rails_03886dcddd FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: query_histories fk_rails_04084e6888; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_histories
    ADD CONSTRAINT fk_rails_04084e6888 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: usluga_histories fk_rails_05d5226d37; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_histories
    ADD CONSTRAINT fk_rails_05d5226d37 FOREIGN KEY (sign_certificate_id) REFERENCES sign_certificates(id);


--
-- Name: registry_histories fk_rails_06e7390f2e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_histories
    ADD CONSTRAINT fk_rails_06e7390f2e FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: usluga_histories fk_rails_10354f0a1d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_histories
    ADD CONSTRAINT fk_rails_10354f0a1d FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: query_histories fk_rails_1bdc65da9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_histories
    ADD CONSTRAINT fk_rails_1bdc65da9e FOREIGN KEY (query_id) REFERENCES queries(id) ON DELETE CASCADE;


--
-- Name: registry_items fk_rails_1bf1df6d3c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_items
    ADD CONSTRAINT fk_rails_1bf1df6d3c FOREIGN KEY (registry_id) REFERENCES registries(id);


--
-- Name: passports_servants fk_rails_1cb3b74055; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY passports_servants
    ADD CONSTRAINT fk_rails_1cb3b74055 FOREIGN KEY (servant_id) REFERENCES servants(id);


--
-- Name: usluga_requests fk_rails_1d8f92e98b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_requests
    ADD CONSTRAINT fk_rails_1d8f92e98b FOREIGN KEY (organization_recipient_id) REFERENCES organization_recipients(id);


--
-- Name: passports_query_passports fk_rails_1da913e556; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY passports_query_passports
    ADD CONSTRAINT fk_rails_1da913e556 FOREIGN KEY (passport_id) REFERENCES passports(id);


--
-- Name: servants_users fk_rails_23dce8b1d6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY servants_users
    ADD CONSTRAINT fk_rails_23dce8b1d6 FOREIGN KEY (servant_id) REFERENCES servants(id);


--
-- Name: uslugas fk_rails_297b848f65; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas
    ADD CONSTRAINT fk_rails_297b848f65 FOREIGN KEY (servant_id) REFERENCES servants(id);


--
-- Name: queries fk_rails_4076821cbb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY queries
    ADD CONSTRAINT fk_rails_4076821cbb FOREIGN KEY (query_id) REFERENCES queries(id) ON DELETE RESTRICT;


--
-- Name: passports fk_rails_433ff17516; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY passports
    ADD CONSTRAINT fk_rails_433ff17516 FOREIGN KEY (category_id) REFERENCES categories(id);


--
-- Name: departments_registries fk_rails_49b70e436d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_registries
    ADD CONSTRAINT fk_rails_49b70e436d FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE;


--
-- Name: queries fk_rails_4b1fc41243; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY queries
    ADD CONSTRAINT fk_rails_4b1fc41243 FOREIGN KEY (from_servant_id) REFERENCES servants(id) ON DELETE RESTRICT;


--
-- Name: query_passports fk_rails_596eb2ca74; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passports
    ADD CONSTRAINT fk_rails_596eb2ca74 FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT;


--
-- Name: registry_item_histories fk_rails_5ef344d05c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_item_histories
    ADD CONSTRAINT fk_rails_5ef344d05c FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: user_identities fk_rails_684b0e1ce0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_identities
    ADD CONSTRAINT fk_rails_684b0e1ce0 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: query_histories fk_rails_6d00df9ab3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_histories
    ADD CONSTRAINT fk_rails_6d00df9ab3 FOREIGN KEY (sign_certificate_id) REFERENCES sign_certificates(id) ON DELETE RESTRICT;


--
-- Name: query_passports fk_rails_76c1bb683c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passports
    ADD CONSTRAINT fk_rails_76c1bb683c FOREIGN KEY (registry_id) REFERENCES registries(id) ON DELETE RESTRICT;


--
-- Name: registry_item_histories fk_rails_7dd64c096c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_item_histories
    ADD CONSTRAINT fk_rails_7dd64c096c FOREIGN KEY (registry_item_id) REFERENCES registry_items(id) ON DELETE CASCADE;


--
-- Name: agent_organization_recipient fk_rails_84fedd2582; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY agent_organization_recipient
    ADD CONSTRAINT fk_rails_84fedd2582 FOREIGN KEY (organization_recipient_id) REFERENCES organization_recipients(id);


--
-- Name: servants_users fk_rails_86dbfa4f72; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY servants_users
    ADD CONSTRAINT fk_rails_86dbfa4f72 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: passports_servants fk_rails_893bb596be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY passports_servants
    ADD CONSTRAINT fk_rails_893bb596be FOREIGN KEY (passport_id) REFERENCES passports(id);


--
-- Name: usluga_requests fk_rails_896a40d77c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_requests
    ADD CONSTRAINT fk_rails_896a40d77c FOREIGN KEY (servant_id) REFERENCES servants(id);


--
-- Name: uslugas fk_rails_8b78906576; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas
    ADD CONSTRAINT fk_rails_8b78906576 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: uslugas fk_rails_9936209f95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas
    ADD CONSTRAINT fk_rails_9936209f95 FOREIGN KEY (agent_id) REFERENCES agents(id);


--
-- Name: queries fk_rails_9b3d065b47; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY queries
    ADD CONSTRAINT fk_rails_9b3d065b47 FOREIGN KEY (servant_id) REFERENCES servants(id) ON DELETE RESTRICT;


--
-- Name: departments_terminals fk_rails_9d08d18721; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_terminals
    ADD CONSTRAINT fk_rails_9d08d18721 FOREIGN KEY (terminal_id) REFERENCES terminals(id);


--
-- Name: registry_histories fk_rails_a122a2bb0e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY registry_histories
    ADD CONSTRAINT fk_rails_a122a2bb0e FOREIGN KEY (registry_id) REFERENCES registries(id) ON DELETE CASCADE;


--
-- Name: usluga_requests fk_rails_a17001099d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_requests
    ADD CONSTRAINT fk_rails_a17001099d FOREIGN KEY (passport_id) REFERENCES passports(id);


--
-- Name: queries fk_rails_b1691ceaf7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY queries
    ADD CONSTRAINT fk_rails_b1691ceaf7 FOREIGN KEY (usluga_id) REFERENCES uslugas(id) ON DELETE RESTRICT;


--
-- Name: query_passport_histories fk_rails_b269b98590; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passport_histories
    ADD CONSTRAINT fk_rails_b269b98590 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: uslugas fk_rails_b5da7fe8ea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas
    ADD CONSTRAINT fk_rails_b5da7fe8ea FOREIGN KEY (usluga_request_id) REFERENCES usluga_requests(id);


--
-- Name: departments_terminals fk_rails_b8b9e72f6d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_terminals
    ADD CONSTRAINT fk_rails_b8b9e72f6d FOREIGN KEY (department_id) REFERENCES departments(id);


--
-- Name: usluga_requests fk_rails_bced1c60bd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_requests
    ADD CONSTRAINT fk_rails_bced1c60bd FOREIGN KEY (agent_id) REFERENCES agents(id);


--
-- Name: queries fk_rails_bd0bdca179; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY queries
    ADD CONSTRAINT fk_rails_bd0bdca179 FOREIGN KEY (query_passport_id) REFERENCES query_passports(id) ON DELETE RESTRICT;


--
-- Name: departments_servants fk_rails_be8122c0d7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_servants
    ADD CONSTRAINT fk_rails_be8122c0d7 FOREIGN KEY (department_id) REFERENCES departments(id);


--
-- Name: usluga_histories fk_rails_c09bc54db0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_histories
    ADD CONSTRAINT fk_rails_c09bc54db0 FOREIGN KEY (usluga_id) REFERENCES uslugas(id) ON DELETE CASCADE;


--
-- Name: usluga_request_histories fk_rails_c1c549714c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_request_histories
    ADD CONSTRAINT fk_rails_c1c549714c FOREIGN KEY (usluga_request_id) REFERENCES usluga_requests(id) ON DELETE CASCADE;


--
-- Name: query_passport_histories fk_rails_c8c0efb5bc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passport_histories
    ADD CONSTRAINT fk_rails_c8c0efb5bc FOREIGN KEY (query_passport_id) REFERENCES query_passports(id) ON DELETE CASCADE;


--
-- Name: agent_organization_recipient fk_rails_c911da13c3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY agent_organization_recipient
    ADD CONSTRAINT fk_rails_c911da13c3 FOREIGN KEY (agent_id) REFERENCES agents(id);


--
-- Name: external_system_requests fk_rails_c9c4aa0f06; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_requests
    ADD CONSTRAINT fk_rails_c9c4aa0f06 FOREIGN KEY (external_system_request_type_id) REFERENCES external_system_request_types(id);


--
-- Name: external_system_requests fk_rails_d44929efe5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_requests
    ADD CONSTRAINT fk_rails_d44929efe5 FOREIGN KEY (usluga_request_id) REFERENCES usluga_requests(id);


--
-- Name: external_system_request_types_passports fk_rails_d65066a7b7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_request_types_passports
    ADD CONSTRAINT fk_rails_d65066a7b7 FOREIGN KEY (passport_id) REFERENCES passports(id);


--
-- Name: external_system_request_types_passports fk_rails_d8d9f1c1a9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY external_system_request_types_passports
    ADD CONSTRAINT fk_rails_d8d9f1c1a9 FOREIGN KEY (external_system_request_type_id) REFERENCES external_system_request_types(id);


--
-- Name: usluga_request_histories fk_rails_db4654e0ca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY usluga_request_histories
    ADD CONSTRAINT fk_rails_db4654e0ca FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: query_passports fk_rails_e57bf8d706; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY query_passports
    ADD CONSTRAINT fk_rails_e57bf8d706 FOREIGN KEY (servant_id) REFERENCES servants(id) ON DELETE RESTRICT;


--
-- Name: departments_registries fk_rails_e93367642b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_registries
    ADD CONSTRAINT fk_rails_e93367642b FOREIGN KEY (registry_id) REFERENCES registries(id) ON DELETE CASCADE;


--
-- Name: uslugas fk_rails_f61fe4814e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas
    ADD CONSTRAINT fk_rails_f61fe4814e FOREIGN KEY (passport_id) REFERENCES passports(id);


--
-- Name: uslugas fk_rails_fc40f0d216; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY uslugas
    ADD CONSTRAINT fk_rails_fc40f0d216 FOREIGN KEY (organization_recipient_id) REFERENCES organization_recipients(id);


--
-- Name: departments_servants fk_rails_fdbe519682; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY departments_servants
    ADD CONSTRAINT fk_rails_fdbe519682 FOREIGN KEY (servant_id) REFERENCES servants(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO "$user", public;

INSERT INTO "schema_migrations" (version) VALUES
('20170620130339'),
('20170621112443'),
('20170621120707'),
('20170622112742'),
('20170627112243'),
('20170627112745'),
('20170627133231'),
('20170627134658'),
('20170627135145'),
('20170627135408'),
('20170627161617'),
('20170628161221'),
('20170628161731'),
('20170628161800'),
('20170628222400'),
('20170628222406'),
('20170704210543'),
('20170704210643'),
('20170704232954'),
('20170704233054'),
('20170710201033'),
('20170710204312'),
('20170710222349'),
('20170711202846'),
('20170711232305'),
('20170713004405'),
('20170713093316'),
('20170714124153'),
('20170714124545'),
('20170714133830'),
('20170719135617'),
('20170719135719'),
('20170802142218'),
('20170803135719'),
('20170803234500'),
('20170818131313'),
('20170819191919'),
('20170820202020'),
('20170821212121'),
('20170828083223'),
('20170828210934'),
('20170828232323'),
('20170907070707'),
('20170914101010');


