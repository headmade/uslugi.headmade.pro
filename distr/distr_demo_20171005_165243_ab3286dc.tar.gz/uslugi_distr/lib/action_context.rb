class ActionContext

  class << self
    def create
      raise "action_context is already set" if present?
      Thread.current[:action_context] = ActionContext.new
    end

    def create_system
      ActionContext.create unless present?
      ActionContext.current_user = (User.system || User.new).decorate
    end

    def create_debug
      create_system
    end

    def instance
      raise "action_context is not set yet" if blank?
      Thread.current[:action_context]
    end

    def destroy
      Thread.current[:action_context] = nil
    end

    def method_missing(*args)
      instance.method_missing(*args)
    end

    def present?
      Thread.current[:action_context].present?
    end

    def blank?
      Thread.current[:action_context].blank?
    end
  end

  def initialize
    @action_context = {}.with_indifferent_access
  end

  def to_hash
    @action_context.freeze
  end

  def method_missing(*args)
    name = args[0]
    if name[-1] == '='
      @action_context[name[0..-2]] = args[1]
    else
      @action_context[name]
    end
  end

end
