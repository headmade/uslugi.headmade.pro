module AuthHelper

  def current_servant
    @current_servant ||= current_user&.servant&.decorate
  end

  def current_user
    if signed_in?
      if @current_user.blank?
        @current_user = User.find_by_id(session[:user_id])
        if @current_user
          @current_user = @current_user.decorate
        else
          sign_out
        end
      end
    else
      @current_user = nil
    end
    @current_user
  end

  def sign_in(user)
    session[:user_id] = user.id
    cookies.signed[:user_id] = user.id
  end

  def sign_out
    ActionCable.server.disconnect(current_user: @current_user)
    session[:user_id] = nil
    cookies.delete(:user_id)
  end

  def signed_in?
    session[:user_id]
  end

  def generate_password
    if Rails.env.development?
      '123'
    else
      @char_space ||= ('0'..'9').to_a.freeze
      res = (1..3).map{ @char_space.sample }
      res += res.sample(1)
      res.shuffle.join
    end
  end

end
