module AuthRoleHelper

  def current_user_main_role
    if signed_in?
      @main_role ||= current_user.roles.first
    end
  end

  def current_user_main_role_path
    if signed_in?
      @current_user_main_role_path ||= begin
        main_role = current_user_main_role
        send("#{main_role}_root_path") if main_role
      end
    end
  end

end
