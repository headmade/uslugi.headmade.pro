class UserService < ApplicationService
  class << self
    def create_regular_user(phone, password)
      User.create!(phone: phone, password: password, state: :active, roles: %i(user))
    end

    def create_regular_user_oauth(uid)
      User.create!(phone: uid, password: '*'+uid, state: :active, roles: %i(user)) # TOFIX: dirty hack with password
    end

    def create_servant_for_user(user)
      user_identity = user.user_identities.find_by(provider: :esia_oauth)
      user.update(roles: (%w(servant) + user.roles).uniq, servants: [::Servant.new(name: user_identity.name, surname: user_identity.surname, patronymic_name: user_identity.patronymic_name)])
      user.servant
    end

    def init_servant_from_esia(servant, esia_role)

      known_orgs = %w(1007369314 1020102075 1019547283)

      if esia_role.present? && known_orgs.include?(esia_role['oid'].to_s)

        servant.passports << Passport.where(id: [37,38]).to_a

        case esia_role['oid'].to_s
        when '1007369314'
          Rails.logger.debug [:esia_role, 'исполком']
        when '1020102075'
          Rails.logger.debug [:esia_role, 'уитис']
          Department.find(4).servants << servant
        when '1019547283'
          Rails.logger.debug [:esia_role, 'уаг']
          Department.find(1).servants << servant
        end

        servant

      end
    end

  end
end
