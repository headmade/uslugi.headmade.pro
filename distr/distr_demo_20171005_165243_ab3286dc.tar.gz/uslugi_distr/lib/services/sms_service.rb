class SmsService
  include Singleton
  include PhoneHelper

  class << self
    def send_password(phone, password)
      #TODO: revive template sending
      #message_text = Sms::ErbalT.new({password: password}).render(template)
      message_text = '%s - пароль ИС Услуги' % [password]
      send_message(phone, message_text)
    end

    def send_usluga_started(phone, *args)
      @send_usluga_started_template ||= 'Документы приняты, процедура предоставления услуги У-%d начата, окончание предоставления: %s'
      message_text = @send_usluga_started_template % args
      send_message(phone, message_text)
    end

    def send_usluga_request_submitted(phone, *args)
      #@send_usluga_request_submitted_template ||= 'Документы заявления З-%d на рассмотрение получены, окончание рассмотрения: %s'
      #message_text = @send_usluga_request_submitted % args
      #send_message(phone, message_text)
    end

    def send_usluga_registry_item(phone, *args)
      @send_usluga_registry_item_template = 'Запись в реестре %s: %s'
      message_text = @send_usluga_registry_item_template % args
      send_message(phone, message_text)
    end

    def send_usluga_request_rejected(phone, *args)
      @send_usluga_request_rejected_template ||= 'Документы заявления З-%d рассмотрены и отклонены из-за несоответствия регламенту оказания услуги'
      message_text = @send_usluga_request_rejected_template % args
      send_message(phone, message_text)
    end

    def send_usluga_rejected(phone, *args)
      @send_usluga_rejected_template ||= 'В предоставлении услуги У-%d отказано в соответствии с п.2.9 Регламента оказания услуги'
      message_text = @send_usluga_rejected_template % args
      send_message(phone, message_text)
    end

    def send_usluga_assigned_again(phone, *args)
      @send_usluga_assigned_again_template ||= 'У-%d получена на доработку'
      message_text = @send_usluga_assigned_again_template % args
      send_message(phone, message_text)
    end

    def send_usluga_assigned_again(phone, *args)
      @send_usluga_assigned_again_template ||= 'У-%d получена на доработку'
      message_text = @send_usluga_assigned_again_template % args
      send_message(phone, message_text)
    end

    def send_usluga_expires_at_changed(phone, *args)
      @send_usluga_expires_at_changed ||= 'У-%d продлена до %s, паспорт направлен в МК РТ'
      message_text = @send_usluga_expires_at_changed % args
      send_message(phone, message_text)
    end

    def send_message(phones, message, options={})
      return unless message.present? && phones.present?
      phones = [phones.to_s] unless phones.is_a?(Array)
      message_trimmed = trim(message)
      phones.compact.uniq.each { |phone| instance.provider.send_message(instance.normalize_mobile(phone), message_trimmed, options) }
    end

    def trim(message, max_length = nil)
      max_length ||= Rails.application.config.x.sms_service.sms_max_length
      if max_length > 0 && max_length < message.length
        message[0, max_length - 1] + '…'
      else
        message
      end
    end
  end

  def provider
    @provider ||= begin
      klass = "SmsProviders::#{Rails.application.config.x.sms_service.provider.classify}".safe_constantize
      klass.respond_to?(:new) ? klass.new : SmsProviders::MockSms.new
    end
  end

end
