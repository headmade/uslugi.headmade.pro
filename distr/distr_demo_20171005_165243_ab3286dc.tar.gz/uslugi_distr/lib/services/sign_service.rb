class SignService < ApplicationService
  class << self

    def sign_url(url)
      [url, '?SHA1=', Digest::SHA1.hexdigest(url)].join
    end
    def substitute_url_get(attrs)
      attrs = attrs.deep_dup
      attrs.deep_values.each {|v| v.replace(SignService.sign_url(URI.unescape(v))) if signable_url?(v) }
      attrs
    end

    def signable_url?(url)
      url.is_a?(String) && (url.starts_with?('https://') || url.starts_with?('http://'))
    end

  end
end
