class SignCertificateService < ApplicationService
  class << self

    def parse(string)
      cert = OpenSSL::X509::Certificate.new(Base64.decode64(string.strip))
      subject = cert.subject.to_s(OpenSSL::X509::Name::RFC2253 & ~4).force_encoding(Encoding::UTF_8)
      issuer = cert.issuer.to_s(OpenSSL::X509::Name::RFC2253 & ~4).force_encoding(Encoding::UTF_8)
      {
        subject: parse_x509_name(subject),
        issuer: parse_x509_name(issuer),
        not_after: cert.not_after,
        not_before: cert.not_before,
        serial: cert.serial.to_s,
      }
    end

    def parse_x509_name(str)
      p str
      data = {}
      str.split(',').each do |d|
        next if d == ""
        prt = d.split('=')
        data[prt[0]] = prt[1]
      end
      data
    end
  end

end
