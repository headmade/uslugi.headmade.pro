class S3Service < ApplicationService
  class << self

    def sign_file_get(path)
      check_init()
      @s3_service_storage.get_object_url(
        @s3_service_config.bucket,
        path,
        @s3_service_config.upload_url_expire.to_i.seconds.from_now.to_time.to_i,
        @s3_service_options
      )
    end

    def sign_url_get(url)
      check_init()
      return nil unless signable_url?(url)
      path = url[@s3_service_url_prefix.length..-1]
      @s3_service_storage.get_object_url(
        @s3_service_config.bucket,
        path,
        @s3_service_config.upload_url_expire.to_i.seconds.from_now.to_time.to_i,
        @s3_service_options
      )
    end

    def sign_file_put(path, content_type)
      check_init()
      s3_service_headers = {"Content-Type" => content_type, "x-amz-acl" => "public-read"}
      @s3_service_storage.put_object_url(
        @s3_service_config.bucket,
        path,
        @s3_service_config.upload_url_expire.to_i.seconds.from_now.to_time.to_i,
        s3_service_headers,
        @s3_service_options,
      )
    end


    def substitute_url_get(attrs)
      attrs = attrs.deep_dup
      attrs.deep_values.each {|v| v.replace(S3Service.sign_url_get(URI.unescape(v))) if signable_url?(v) }
      attrs
    end

    # TODO: check why need this (probabluy do not)
    def substitute_url_remove_query(attrs)
      attrs = attrs.deep_dup
      attrs.deep_values.each {|v| p [signable_url?(v), v, v.split('?').first], v.replace(v.split('?').first) if signable_url?(v) }
      attrs
    end

    def signable_url?(url)
      check_init()
      url.is_a?(String) && url.starts_with?(@s3_service_url_prefix)
    end

    def substiture_url_for_demo(attrs, path)
      check_init()
      url = [@s3_service_url_prefix, path].join
      attrs.deep_values.each {|v| v.replace(url) if v.is_a?(String) && v.start_with?('http') }
      attrs
    end

    private

    def check_init
      unless @s3_service_config
        # TODO: cannot assign @s3_service_config at the top (for threaded/concurrent execution)
        s3_service_config = Rails.application.config.x.s3
        @s3_service_storage = Fog::Storage.new(
          endpoint: s3_service_config.endpoint,
          provider: 'AWS',
          aws_access_key_id: s3_service_config.aws_access_key_id,
          aws_secret_access_key: s3_service_config.aws_secret_access_key
        )
        @s3_service_options = {path_style: true}
        @s3_service_url_prefix = [s3_service_config.endpoint, s3_service_config.bucket,''].join('/')
        @s3_service_config = s3_service_config
      end
    end

  end
end
