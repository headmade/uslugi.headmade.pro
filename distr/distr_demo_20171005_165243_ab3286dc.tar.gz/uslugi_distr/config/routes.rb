require 'sidekiq/web'

# https://github.com/mperham/sidekiq/wiki/Monitoring
#Sidekiq::Web.set :session_secret, Rails.application.secrets[:secret_key_base]
#Sidekiq::Web.set :sessions, false


Rails.application.routes.draw do

  get 'test_index/index'

  namespace :api, defaults: {format: :json} do
    get '/s3/sign', to: 's3#sign'
    namespace :admin do
      resource :session, only: %i(show)
      resources :statistics, only: %i(index) do
        collection do
          get ':report_key', to: 'statistics#report_key'
        end
      end
    end
    namespace :servant do
      resource :session, only: %i(show)
      resources :passports, only: %i(index show)
      resources :query_passports, only: %i(index show)
      resources :registries, only: %i(index) do
        member do
          get :registry_items
        end
      end
      resources :registry_items, only: %i(index show create update)
      resource :checkout, only:[] do
        get :address
      end
      resources :agents, only: %i(index) do
        member do
          get :usluga_requests
        end
      end
      resources :organization_recipients, only: %i(index) do
        member do
          get :usluga_requests
        end
      end
      resources :usluga_requests, only: %i(index show create update) do
        member do
          post :event
          get :event if Rails.env.development?
        end
        # TODO: check if used on collection
        collection do
          get :user_requests
          get :my_user_requests
          get :consultations
          get :my_consultations
        end
      end
      resources :uslugas, only: %i(index show create) do
        resources :queries, only: %i(create)
        member do
          post :event
          get :event if Rails.env.development?
        end
      end
      resources :queries, only: %i(index show) do
        member do
          post :event
          get :event if Rails.env.development?
        end
        collection do
          get :recipients
        end
      end
      resources :statistics, only: %i(index) do
        collection do
          get ':report_key', to: 'statistics#report_key'
        end
      end
    end

    namespace :user do
      resource :session, only: %i(show)
      resources :passports, only: %i(index show)
      resources :uslugas, only: %i(index show)
      resources :usluga_requests, only: %i(index show create) do
        member do
          post :event
          get :event if Rails.env.development?
        end
      end
    end

    namespace :v1 do
      resources :registries, only: %i() do
        resources :registry_items, only: %i(index show)
      end
    end
  end

  scope module: :web, defaults: {format: :html} do

    get '/auth/:provider/callback', to: 'sessions#auth'

    root 'welcome#index'
    resource :session, only: %i(new create destroy) do
      get :logout, to: 'sessions#destroy'
      get :organizations
      patch :organizations, to: 'sessions#set_organization'
    end

    post "/form", to: 'welcome#form'
    #get "/health_check", to: 'health_check#index'

    resources :categories, only: %i(index show)
    resources :passports, only: %i(index show)

    namespace :admin do
      #root to: redirect(path: '/admin/categories')
      root 'welcome#index'

      resources :categories
      resources :departments
      resources :external_system_request_types
      resources :passports
      resources :query_passports
      resources :users
    end

    namespace :user do
      root 'welcome#index'
      get "/*path", to: 'welcome#index'
    end
    namespace :servant do
      root 'welcome#index'
      get "/*path", to: 'welcome#index'
    end

  end

  # https://github.com/mperham/sidekiq/wiki/Monitoring
	Sidekiq::Web.use Rack::Auth::Basic do |username, password|
		# Protect against timing attacks:
		# - See https://codahale.com/a-lesson-in-timing-attacks/
		# - See https://thisdata.com/blog/timing-attacks-against-string-comparison/
		# - Use & (do not use &&) so that it doesn't short circuit.
		# - Use digests to stop length information leaking (see also ActiveSupport::SecurityUtils.variable_size_secure_compare)
    settings = Rails.application.config.x.sidekiq
    Rails.logger.debug [:sidekiq, [username, settings.user], [password, settings.password]]
    ActiveSupport::SecurityUtils.secure_compare(::Digest::SHA256.hexdigest(username), ::Digest::SHA256.hexdigest(settings.user)) &
      ActiveSupport::SecurityUtils.secure_compare(::Digest::SHA256.hexdigest(password), ::Digest::SHA256.hexdigest(settings.password))
	end if Rails.env.production?
  mount Sidekiq::Web => '/sidekiq'

  health_check_routes
  get "/*path", to: 'web/welcome#index'

end
