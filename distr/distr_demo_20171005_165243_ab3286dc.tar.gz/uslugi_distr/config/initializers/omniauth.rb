
def base_url
  Rails.application.config.x.base_url || 'http://localhost:3000'
end

def auth_redirect_uri(provider)
  "#{base_url}/auth/#{provider}/callback"
end



Rails.application.config.middleware.use OmniAuth::Builder do
  #provider :developer unless Rails.env.production?
  provider :esia_oauth, { #:api_key, :api_secret, {
    name: :esia_oauth,
    client_id: Rails.application.config.x.esia.client_id,
    redirect_uri: auth_redirect_uri(:esia_oauth),
    scope: Rails.application.config.x.esia.scopes,
    cert_path: "#{Rails.root}/cert/cert.crt",
    pkey_path: "#{Rails.root}/cert/private.key",
    site: Rails.application.config.x.esia.auth_site,
  }
end
OmniAuth.config.logger = Rails.logger

