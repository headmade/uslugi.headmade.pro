Sidekiq.configure_server do |config|
  config.redis = {url: Rails.application.config.x.redis.sidekiq_url}
end

Sidekiq.configure_client do |config|
  config.redis = {url: Rails.application.config.x.redis.sidekiq_url}
end

puts 'Run "echo flushall | redis-cli" from shell console to cleanup redis (for all projects)' if Rails.env.development?
