class Hash
  def deep_values
    values.map {|v| (v.is_a?(Hash) || v.is_a?(Array)) ? v.deep_values : v }.flatten
  end
end
