if defined?(::Rails::Console).present?
  require 'action_context'
  ActionContext.create_system
  puts "Current user: '#{ActionContext.current_user.phone}'"
end
