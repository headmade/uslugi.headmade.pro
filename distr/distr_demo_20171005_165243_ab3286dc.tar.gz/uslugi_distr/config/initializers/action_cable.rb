Rails.application.config.action_cable.mount_path = '/websocket'

