// module.exports =  {
//   test: /\.svg$/,
//   exclude: /node_modules/,
//   loader: 'svg-inline-loader'
// }