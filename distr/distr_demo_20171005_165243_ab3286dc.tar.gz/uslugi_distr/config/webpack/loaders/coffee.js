module.exports = {
  test: /\.coffee(\.erb)?$/,
  loader: 'coffee-loader'
}
