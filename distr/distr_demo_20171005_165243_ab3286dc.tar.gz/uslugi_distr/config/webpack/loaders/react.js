module.exports = {
  test: /\.(js|jsx)?(\.erb)?$/,
  exclude: /node_modules/,
  //loader: 'babel-loader'
  loaders: [ 'happypack/loader?id=jsx' ]
}
