#/bin/sh

echo Install postgres, redis
apt-get update && apt-get install -q postgres redis

echo 'Install nodejs etc (takes long time)'
curl -sL https://deb.nodesource.com/setup_7.x | bash - && \
  curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | apt-key add - && \
  echo "deb https://dl.yarnpkg.com/debian/ stable main" | tee /etc/apt/sources.list.d/yarn.list && \
  apt-get update && \
  apt-get install -qy locales nodejs yarn && \
  localedef -i ru_RU -c -f UTF-8 -A /usr/share/locale/locale.alias ru_RU.UTF-8 && \
  apt-get clean && rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/* && \

echo Install rvm
gpg --keyserver hkp://keys.gnupg.net --recv-keys 409B6B1796C275462A1703113804BB82D39DC0E3 7D2BAF1CF37B13E2069D6956105BD0E739499BDB
\curl -sSL https://get.rvm.io | bash -s stable

echo Setup USLUGI env
rvm reload
rvm @global do gem install bundler rake
rvm install ruby-2.4.2
bundle install
TIME_ZONE=Moscow INSTANCE_NAME=demo RAILS_ENV=production bundle exec rails assets:precompile

echo Prepare data/config
cp distr.env .env
createuser -s dev
createdb -O dev uslugi_kzn_production
bzcat dump_demo.sql.bz2 | psql -U dev uslugi_kzn_production

echo ''
echo To run the project, type:
echo RAILS_ENV=production rails server
echo and navigate to http://localhost:3000

