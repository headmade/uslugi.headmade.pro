module SignInHelper
  include AuthHelper
  def sign_in_admin
    sign_in(User.find(1))
  end
  def sign_in_servant
    sign_in(User.find(2))
  end
  def sign_in_user
    sign_in(User.find(3))
  end
end
