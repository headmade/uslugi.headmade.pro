require 'rails_helper'

RSpec.describe TestIndexDecorator do
end
