require 'rails_helper'

RSpec.describe Web::Servant::WelcomeController, type: :controller do
  include SignInHelper

  before do
    sign_in_servant
  end

  describe "GET index" do
    it "renders the index template" do
      get :index
      expect(response).to render_template("index")
    end
  end
end
