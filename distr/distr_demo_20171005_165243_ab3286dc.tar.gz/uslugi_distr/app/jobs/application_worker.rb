class ApplicationWorker
  include Sidekiq::Worker
  sidekiq_options queue: :default, retry: 1, backtrace: true
end
