class NotificationWorker < ApplicationWorker
  def perform(notification_type, *args)
    SmsService.send(notification_type, *args)
  end
end
