class OrganizationRecipient < ApplicationRecord
  has_and_belongs_to_many :agents
  has_many :usluga_requests
  has_many :uslugas

  scope :inn_like, ->(inn) { where("inn like ?||'%'", inn) if inn.present? }
end
