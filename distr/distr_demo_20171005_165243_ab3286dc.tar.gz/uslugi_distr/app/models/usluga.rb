class Usluga < ApplicationRecord
  include Historiable
  include UslugaStateMachine

  belongs_to :passport
  belongs_to :servant, optional: true
  belongs_to :user, optional: true
  belongs_to :usluga_request
  belongs_to :agent, optional: true
  belongs_to :organization_recipient, optional: true

  has_many :queries
  has_many :query_passports, through: :passport

  scope :with_passport_ids, ->(ids) { where(passport_id: ids) if ids }
  scope :without_user, ->() { where(user_id: nil) }
  scope :signed, ->() { where(state: %i(completed_signed rejected_signed)) }
  scope :with_submission_type, ->(st) { where("request_data->>'source' = ?", {electronic: '01_servant', paper: '02_user'}.with_indifferent_access[st] ) }
end
