class Servant < ApplicationRecord
  has_and_belongs_to_many :users
  has_and_belongs_to_many :passports
  has_and_belongs_to_many :departments

  has_many :uslugas
  has_many :usluga_requests

  has_many :registries, through: :departments
  has_many :query_passports

  def user
    users.first
  end

end
