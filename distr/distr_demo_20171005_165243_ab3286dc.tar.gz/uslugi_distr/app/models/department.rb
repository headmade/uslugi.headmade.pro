class Department < ApplicationRecord
  has_ancestry

  has_and_belongs_to_many :terminals
  has_and_belongs_to_many :servants
  has_and_belongs_to_many :registries

  has_many :passports, through: :servants

  def terminal
    terminals.first
  end
end
