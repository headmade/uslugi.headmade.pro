class UslugaRequest < ApplicationRecord
  include Historiable
  include UslugaRequestStateMachine

  belongs_to :passport
  belongs_to :user, optional: true
  belongs_to :servant, optional: true
  belongs_to :agent, optional: true
  belongs_to :organization_recipient, optional: true

  has_one :usluga
  has_many :external_system_requests

  scope :with_passport_ids, ->(ids) { where(passport_id: ids) if ids }
  scope :without_user, ->() { where(user_id: nil) }
  scope :with_work_for_servant, ->() { where(state: %i(submitted assigned rejected)) }
  scope :consultations, ->() { where(state: %i(consultation consulted)) }
  scope :not_consultations, ->() { where.not(state: %i(consultation consulted)) }
  scope :with_submission_type, ->(st) { where("data->>'source' = ?", {electronic: '01_servant', paper: '02_user'}.with_indifferent_access[st] ) }
end
