class QueryPassport < ApplicationRecord
  #include Historiable # TODO

  belongs_to :department, optional: true
  belongs_to :servant, optional: true
  belongs_to :registry, optional: true

  has_many :queries

  has_and_belongs_to_many :passports
end
