class SignCertificate < ApplicationRecord
end
