class Category < ApplicationRecord
  has_many :passports
end
