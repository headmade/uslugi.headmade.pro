class Registry < ApplicationRecord
  include Historiable

  has_and_belongs_to_many :departments
  has_many :registry_items

  def state
    deleted_at.present? ? :deleted : :active
  end
end
