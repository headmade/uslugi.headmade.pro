class Agent < ApplicationRecord
  has_and_belongs_to_many :organization_recipients
  has_many :usluga_requests
  has_many :uslugas

  scope :passport_number_like, ->(pn) { where("passport_number like ?||'%'", pn) if pn.present? }
end
