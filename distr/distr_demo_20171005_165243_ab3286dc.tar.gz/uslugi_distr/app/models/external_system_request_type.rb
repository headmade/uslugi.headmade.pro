class ExternalSystemRequestType < ApplicationRecord
  has_many :external_system_requests
  has_many :usluga_requests, through: :external_system_requests
end
