class UserIdentity < ApplicationRecord
  belongs_to :user

  # TODO: move to decorator? store_attributes?
  def name() data.dig('info', 'first_name'); end
  def surname() data.dig('info', 'last_name'); end
  def patronymic_name() data.dig('info', 'middle_name'); end

end
