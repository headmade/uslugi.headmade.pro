class User < ApplicationRecord
  include Roleable
  has_secure_password

  has_and_belongs_to_many :servants

  has_many :user_identities
  has_many :usluga_requests
  has_many :uslugas
  has_many :passports, through: :servants
  has_many :departments, through: :servants

  after_commit :send_password_notify

  scope :active, ->() { where(state: :active) }
  scope :with_roles, -> (array) { where("roles @> ARRAY[?]::varchar[]", array) unless array.empty? }

  scope :system, -> { find_by(id: 1) }

  def servant
    has_role?(:servant) ? servants.first : nil
  end

  def send_password_notify
    SmsService.send_password(self.phone, self.password) if self.password.present? && self.password != '*'+self.phone  # TOFIX: dirty hack to not send sms to new ESIA user
  end

end
