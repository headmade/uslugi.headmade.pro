class ExternalSystemRequest < ApplicationRecord
  belongs_to :external_system_request_type
  belongs_to :usluga_request
end
