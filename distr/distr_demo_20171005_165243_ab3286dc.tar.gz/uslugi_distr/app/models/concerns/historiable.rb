module Historiable
  extend ActiveSupport::Concern

  included do
    def self.history_class_name() [base_class.name,'History'].join end

    history_owner = base_class.model_name.singular
    Object.const_set(history_class_name, Class.new(ApplicationRecord) {
      belongs_to :user
      belongs_to history_owner.to_sym
      #has_one :sign_certificate if has_sign? # TODO: make this work!

      def self.history_owner_class_name
        @history_owner_class_name ||= base_class.name.sub('History','')
      end
    })

    before_save :fetch_previous_attributes
    after_commit :save_history

    has_many :histories, class_name: history_class_name #, dependent: :delete_all  - this is done in postgres 'on delete cascade'
  end

  def fetch_previous_attributes
    @previous_attributes ||= self.id.present? && self.class.find_by(id: id)&.attributes
    @previous_attributes ||= {}
  end

  def save_history
    fetch_previous_attributes()
    previous_state = @previous_attributes['state'] || ''
    current_state = state
    current = attributes.to_hash
    if respond_to?(:queries)
      # TODO: save only relevant queries (created on this event)
      current[:queries] = queries.pluck(:id).sort
    end
    request_params = ActionContext.request_params || {}
    request_headers = ActionContext.request_headers || {}
    action = request_params['action'] || :system
    user_id = (ActionContext.current_user || User.system.decorate).id
    attrs = {
      [self.class.base_class.model_name.singular,'_id'].join => self.id,
      user_id: user_id,
      action: action,
      previous_state: previous_state,
      current_state: current_state,
      previous: @previous_attributes,
      current: current,
      request_params: request_params,
      request_headers: request_headers,
    }
    if has_sign?
      signed = request_params.dig('data', 'signed')
      if signed.present?
        cert_str = Hash.from_xml(signed)['usluga']['Signature']['KeyInfo']['X509Data']['X509Certificate'] # TODO: FIX usae of 'usluga' !!!
        cert = SignCertificateService.parse(cert_str)
        sign_certificate = SignCertificate.create_with(expires_at: cert[:not_after], data: cert).find_or_create_by(serial: cert[:serial])
        attrs.merge!(signed: signed, sign_certificate_id: sign_certificate.id)
      end
    end
    history_class.create!(attrs)
  end

  def history_class
    self.class.history_class_name.constantize
  end

  def has_sign?
    history_class.attribute_names.include?('signed')
  end

end
