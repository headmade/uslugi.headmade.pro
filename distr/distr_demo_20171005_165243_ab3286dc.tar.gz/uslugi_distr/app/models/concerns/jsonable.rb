module Jsonable
  extend ActiveSupport::Concern

  included do
  end

  def attr_json(attr_name)
    define_method("#{attr_name}=")  do |attr_value|
      attr_value = JSON.parse(attr_value) if attr_value.is_a?(String)
      super(attr_value)
    end
  end

end
