module Roleable
  extend ActiveSupport::Concern

  included do
    Rails.application.config.x.roles.each do |role|
      define_method("#{role}?") { has_role?(role) }
    end
  end

  def has_role?(role)
    roles.include?(role.to_s)
  end
end
