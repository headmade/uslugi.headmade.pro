class Query < ApplicationRecord
  include Historiable
  include QueryStateMachine

  belongs_to :query_passport
  belongs_to :usluga

  belongs_to :query, optional: true
  has_many :queries

  belongs_to :from_servant, class_name: '::Servant', optional: true  # servant who sent this query manually
  belongs_to :servant, class_name: '::Servant', optional: true       # servant who responds to query

  before_save :init_from_query_passport
  after_commit :notify_expires_at

  scope :incomplete, ->() { where.not(state: %i(completed rejected cancelled)) }

  def init_from_query_passport
    query_config = query_passport.data['query']

    self.type = query_config['type'].constantize
    self.usluga_id ||= self.query.usluga_id
    self.query_params ||= query_config['params']
    self.query_data = copy_data_from_source() || self.query_data
    self.expires_at ||= Time.now + query_passport.data.dig('duration', 'total')
  end

  def copy_data_from_source
    source_config = query_passport.data.dig('query','source')
    if source_config.present?
      source = query&.query_data || usluga.request_data
      source_config.map{ |k,v| [k, source.dig(*v)] }.to_h
    end
  end

  def notify_expires_at
    Rails.logger.debug [:notify_expires_at, self]
    # TODO: dirty hack, because queries are created via generic Query.new, not Query::Paper.new
    if type == 'Query::Paper'
      u = self.usluga
      NotificationWorker.perform_async(
        :send_usluga_expires_at_changed,
        u.agent.mobile,
        u.id,
        I18n.l(UslugaUserDecorator.decorate(u).expires_at.end_of_day, format: :long)
      )
    end
  end
end
