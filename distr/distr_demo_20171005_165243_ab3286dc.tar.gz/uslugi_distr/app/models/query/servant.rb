class Query::Servant < Query
end
