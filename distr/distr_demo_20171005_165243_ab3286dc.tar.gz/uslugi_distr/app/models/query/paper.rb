class Query::Paper < Query
end
