class Query::Department < Query
end
