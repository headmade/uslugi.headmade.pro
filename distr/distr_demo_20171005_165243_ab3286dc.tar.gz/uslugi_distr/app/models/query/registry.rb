class Query::Registry < Query
end
