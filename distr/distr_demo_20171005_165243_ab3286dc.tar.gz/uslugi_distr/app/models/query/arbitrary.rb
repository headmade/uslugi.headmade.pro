class Query::Arbitrary < Query
end
