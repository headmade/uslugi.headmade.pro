class RegistryItem < ApplicationRecord
  include Historiable

  belongs_to :registry

  before_save :set_search

  scope :search, ->(name, value) { where("search->>'#{name}' is not null").where("search->>'#{name}' = ?", value) }

  scope :search_inn, ->(inn) { search(:inn, inn) if inn.present? }
  scope :search_fias_id, ->(fias_id) { search(:fias_id, fias_id) if fias_id.present? }

  def state
    deleted_at.present? ? :deleted : :active
  end

  private
  def set_search
    self.search = registry.search.map{ |pair| pair[1] = data.dig(*(pair[1])); pair }.to_h.compact
  end
end
