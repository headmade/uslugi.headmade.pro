class Passport < ApplicationRecord
  # duration - in nanoseconds, for golang
  # type Duration int64

  # TODO: add Historiable
  #include Historiable

  belongs_to :category

  has_many :uslugas
  has_many :usluga_requests

  has_and_belongs_to_many :servants
  has_and_belongs_to_many :external_system_request_types
  has_and_belongs_to_many :query_passports

  scope :active, -> { where(active: true) }
end
