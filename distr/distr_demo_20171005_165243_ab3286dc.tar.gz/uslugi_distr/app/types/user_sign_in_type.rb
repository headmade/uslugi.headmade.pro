class UserSignInType
  include BaseTypeWithoutActiveRecord

  attribute :login, String
  attribute :password, String

  validates :login, presence: true
  validates :password, presence: true

  validate :check_authenticate, if: :login

  def user
    unless @user
      phone = login.strip
      @user = User.active.find_by_phone(phone)
    end
    @user
  end

  def user=(user)
    @user = user
  end

  def need_confirm?
    login.present? && !password.present?
  end

  private
  def check_authenticate
    if !user.try(:authenticate, password)
      errors.add(:password, :user_or_password_invalid)
      return
    end
  end
end
