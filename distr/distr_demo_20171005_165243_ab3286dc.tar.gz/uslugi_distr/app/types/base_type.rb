module BaseType
  extend ActiveSupport::Concern

  module ClassMethods
    delegate :sti_name,  to: :superclass
    delegate :model_name, to: :superclass

    def find_sti_class(_)
      ActiveSupport::Dependencies.constantize(self.name)
    end

    # TODO: изжить костыль (удаление и добавление inheritance_column для STI-моделей)
    def new(*args)
      attrs = args.first
      has_sti = attrs && attrs.has_key?(inheritance_column)
      return super unless has_sti
      type = attrs.delete(inheritance_column)
      res = super
      res[inheritance_column] = type
      res
    end
  end
end
