class UserCreateType
  include BaseTypeWithoutActiveRecord

  attribute :phone, String
  attribute :password, String

  attribute :surname, String
  attribute :name, String
  attribute :patronymic_name, String

  validates :login, presence: true
  validates :password, presence: true

  validates :surname, presence: true
  validates :name, presence: true
  validates :patronymic_name, presence: true
end
