module UslugaStateMachine
  extend ActiveSupport::Concern

  included do
    include ApplicationStateMachine

    aasm column: :state, no_direct_assignment: true do
      state :created, initial: true
      state :started
      state :assigned
      state :assigned_again
      state :completed
      state :completed_signed
      state :rejected
      state :rejected_signed

      after_all_transitions :add_queries

      event :start, after: :after_start do
        transitions from: :created, to: :started# , unless: :current_user_user? # TODO: cannot use "current_user_user?", because it crashes for user with roles=[servant,user]
      end

      event :assign do
        transitions from: :started, to: :assigned, guards: [:current_user_servant?], after: :after_assign
        transitions from: :assigned, to: :assigned, guards: [:current_user_servant?, :not_assigned_to_me?], after: :after_assign
        transitions from: :assigned_again, to: :assigned_again, guards: [:current_user_servant?, :not_assigned_to_me?], after: :after_assign
      end

      event :complete, after: :after_completed do
        transitions from: :assigned, to: :completed, guards: [:current_user_servant?, :assigned_to_me?, :has_no_incomplete_queries], after: :assign_result_data
        transitions from: :assigned_again, to: :completed, guards: [:current_user_servant?, :assigned_to_me?, :has_no_incomplete_queries], after: :assign_result_data
      end

      event :reject do
        transitions from: :assigned, to: :rejected, guards: [:current_user_servant?, :assigned_to_me?, :has_no_incomplete_queries], after: :assign_reject_data
        transitions from: :assigned_again, to: :rejected, guards: [:current_user_servant?, :assigned_to_me?, :has_no_incomplete_queries], after: :assign_reject_data
      end

      event :sign do
        transitions from: :completed, to: :completed_signed, guards: [:current_user_servant?], success: :after_sign_completed
        transitions from: :rejected, to: :rejected_signed, guards: [:current_user_servant?], success: :notify_rejected
      end

      event :assign_again do
        transitions from: :completed, to: :assigned_again, guards: [:current_user_servant?], after: :after_assign_again
        transitions from: :rejected, to: :assigned_again, guards: [:current_user_servant?], after: :after_assign_again
      end

    end
  end

  def signed_states()
    @signed_states ||= %i(completed_signed rejected_signed).map{|k| [k,true]}.to_h.freeze
  end

  private

  def has_no_incomplete_queries
    self.queries.incomplete.empty?
  end

  def after_start
    notify_started
  end

  def assign_servant(data)
    raise 'No data given to "assign_servant"' unless data
    self.servant = data[:servant_id].present? ? Servant.find(data[:servant_id]) : current_servant.model
  end

  def after_assign(data)
    assign_servant(data)
    notify_assigned
  end

  def after_assign_again(data)
    notify_assigned_again
  end

  def assign_result_data(data)
    self.result_data = data
  end

  def assign_reject_data(data)
    self.reject_data = data
  end


  def notify_started
    NotificationWorker.perform_async(
      :send_usluga_started,
      self.agent.mobile,
      self.id,
      I18n.l(((self.created_at || Time.now) + 17.day).end_of_day, format: :long) # TODO: sometimes created_at returns nil :-?
    )
  end

  def notify_assigned
    Rails.logger.debug [:notify_assigned, self.servant, self.id] unless assigned_to_me?  # TODO
  end

  def notify_assigned_again
    servant_mobile  = self.servant.user.decorate.mobile
    if servant_mobile.present?
      NotificationWorker.perform_async(
        :send_usluga_assigned_again,
        servant_mobile,
        self.id,
      )
    else
      Rails.logger.debug [:notify_assigned_again, self.servant, self.id]
    end
  end

  def after_completed
  end

  def after_sign_completed
    notify_completed
    process_registry
  end
  def notify_completed
    Rails.logger.debug [:notify_completed, self.agent, self.id]  # TODO
  end

  def notify_rejected
    Rails.logger.debug [:notify_rejected, self.agent, self.id]
    NotificationWorker.perform_async(
      :send_usluga_rejected,
      self.agent.mobile,
      self.id,
    )
  end

  def add_queries
    return if aasm.from_state == aasm.to_state

    current_event = aasm.current_event.to_s
    current_event.chop! if current_event[-1] == '!'

    queries_config = passport.data.dig(self.class.base_class.model_name.singular, 'queries', 'events', current_event)
    return unless queries_config.present?

    new_queries = queries_config.map do |qc|
      self.queries.create!(query_passport_id: qc['query_passport_id'])
    end
    new_queries.first.start!
    new_queries
  end

  def process_registry
    registry_config = self.passport.data.dig('usluga','registry')
    if registry_config
      command_data = registry_config['source'].map{ |k,v| [k, self.request_data.dig(*v)] }.to_h
      Rails.logger.debug [:process_registry, registry_config['registry_id'], registry_config['command'], command_data]
      registry_item = RegistryService.process_command(registry_config['registry_id'], registry_config['command'], command_data)
      unless request_data['registry_item_id'].present?
        self.update_columns(request_data: {registry_item_id: registry_item.id}.merge(self.request_data))
      end
      notify_registry_item(registry_config['registry_id'], self.request_data['registry_item_id'])
    end
  end

  def notify_registry_item(registry_id, registry_item_id)
    Rails.logger.debug [
      :send_usluga_registry_item,
      self.agent.mobile,
      Rails.application.routes.url_helpers.api_v1_registry_registry_item_url(registry_id, registry_item_id, {host: Rails.application.config.x.base_url})
    ]
    NotificationWorker.perform_async(
      :send_usluga_registry_item,
      self.agent.mobile,
      Rails.application.routes.url_helpers.api_v1_registry_registry_item_url(registry_id, registry_item_id, {host: Rails.application.config.x.base_url})
    )
  end

end
