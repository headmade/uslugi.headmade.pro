module ApplicationStateMachine
  extend ActiveSupport::Concern

  included do
    include AASM
  end

  def permitted_events
    permitted_events ||= aasm.events(permitted: true).map(&:name)
  end

  def permitted_events_config   # TODO: change of state must invalidate cache
    @permitted_events_config ||= aasm.events(permitted: true).map do |event|
      key=event.name.to_s
      {
        key: key,
        name: I18n.t(key, scope: 'state_machine.event'),
        style: I18n.t(key.to_s, scope: 'state_machine.event_style'),
        require_sign: event.transitions.map(&:to).select{|to| signed_states[to]}.compact.present?,
      }
    end
  end

  private

  def current_user
    ActionContext.current_user
  end
  def current_servant
    ActionContext.current_servant
  end

  def current_user_user?
    current_user.user?
  end
  def current_user_servant?
    current_user.servant?
  end

  def assigned_to_me?
    self.servant_id == current_servant.id
  end
  def not_assigned_to_me?
    !assigned_to_me?
  end
end
