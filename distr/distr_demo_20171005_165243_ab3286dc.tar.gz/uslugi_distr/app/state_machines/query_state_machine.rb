module QueryStateMachine
  extend ActiveSupport::Concern

  included do
    include ApplicationStateMachine

    aasm column: :state, no_direct_assignment: true do
      state :created, initial: true
      state :started
      state :assigned
      state :completed
      state :completed_signed
      state :rejected
      state :rejected_signed

      after_all_transitions :add_queries

      event :start, after: :after_start do
        transitions from: :created, to: :started
      end

      event :assign do
        transitions from: :started, to: :assigned, after: :after_assign
      end

      event :complete, after: :after_complete do
        transitions from: :assigned, to: :completed, guards: [:assigned_to_me?,:has_no_incomplete_queries], after: :assign_result_data
      end

      event :reject, after: :after_reject do
        transitions from: :assigned, to: :rejected, guards: [:assigned_to_me?,:has_no_incomplete_queries], after: :assign_reject_data
      end

      #event :sign do
        #transitions from: :completed, to: :completed_signed
        #transitions from: :rejected, to: :rejected_signed
      #end
    end

  end

  def has_no_incomplete_queries
    self.queries.incomplete.empty?
  end

  def after_start
    Rails.logger.debug [:after_start, 1]
  end

  def assign_servant(data)
    raise 'No data given to "assign_servant"' unless data
    self.servant = data[:servant_id].present? ? Servant.find(data[:servant_id]) : current_servant.model
  end

  def after_assign(data)
    assign_servant(data)
  end

  def assign_result_data(data)
    self.result_data = data
  end
  def after_complete
    get_queries.created.first&.start!
    # notify browser
  end

  def get_queries
    if self.query_id
      self.query.queries
    else
      self.usluga.queries
    end
  end

  def assign_reject_data(data)
    self.reject_data = data
  end
  def after_reject
    get_queries.created.update_all(state: :cancelled)
    # notify browser
  end

  def signed_states()
    @signed_states ||= %i().map{|k| [k,true]}.to_h.freeze
  end

  def add_queries
    return if aasm.from_state == aasm.to_state

    current_event = aasm.current_event.to_s
    current_event.chop! if current_event[-1] == '!'

    queries_config = query_passport.data.dig(self.class.base_class.model_name.singular, 'queries', 'events', current_event)
    return unless queries_config.present?

    new_queries = queries_config.map do |qc|
      self.queries.create!( query_passport_id: qc['query_passport_id'])
    end
    new_queries.first.start!
    new_queries
  end

end
