module UslugaRequestStateMachine
  extend ActiveSupport::Concern

  included do
    include ApplicationStateMachine

    aasm column: :state, no_direct_assignment: true do
      state :created, initial: true
      state :submitted
      state :assigned
      state :accepted
      state :rejected
      state :rejected_signed

      state :consultation
      state :consulted

      event :submit, after: :after_submit do
        transitions from: :created, to: :submitted
      end

      event :assign, after: :after_assign do
        transitions from: :submitted, to: :assigned, guards: [:current_user_servant?], after: :assign_servant
        transitions from: :assigned, to: :assigned, guards: [:current_user_servant?, :not_assigned_to_me?], after: :assign_servant
        transitions from: :consultation, to: :consultation, guards: [:current_user_servant?, :not_assigned_to_me?], after: :assign_servant
      end

      event :accept, after: :after_accept do
        transitions from: :assigned, to: :accepted, guards: [:current_user_servant?, :assigned_to_me?], after: :create_usluga
      end

      event :reject do
        transitions from: :assigned, to: :rejected, guards: [:current_user_servant?, :assigned_to_me?], after: :after_reject
      end

      #event :sign do
        #transitions from: :rejected, to: :rejected_signed, guards: [:current_user_servant?], after: :notify_rejected
      #end

      event :begin_consultation do
        transitions from: :created, to: :consultation, guards: [:current_user_servant?, :assigned_to_me?]
      end
      event :end_consultation do
        transitions from: :consultation, to: :consulted, guards: [:current_user_servant?, :assigned_to_me?]
      end

    end
  end

  def signed_states()
    @signed_states ||= %i(rejected_signed).map{|k| [k,true]}.to_h.freeze
  end

  private

  def after_submit
    notify_submitted
  end

  def after_assign
    notify_assigned
  end

  def after_reject(data)
    assign_reject_data(data)
    notify_rejected
  end

  def assign_servant(data={})
    self.servant = data && data[:servant_id].present? ? Servant.find(data[:servant_id]) : current_servant.model
  end

  def create_usluga
    Usluga.transaction do
      build_usluga(request_data: {'source' => '02_user'}.merge(self.data), passport_id: self.passport_id, user_id: self.user_id, agent_id: self.agent_id, organization_recipient_id: self.organization_recipient_id)
      usluga.save!
      usluga.start!
    end
  end
  def after_accept
    notify_accepted
  end

  def assign_reject_data(data)
    self.reject_data = data
  end

  def notify_submitted
    #NotificationWorker.perform_async(
      #:send_usluga_request_submitted,
      #self.agent.mobile,
      #I18n.l((self.created_at + 1.day).end_of_day, format: :long)
    #)
  end

  def notify_assigned  # TODO
    Rails.logger.debug [:notify_assigned, self.servant] unless assigned_to_me?
  end

  def notify_accepted
    #NotificationWorker.perform_async(
      #:send_usluga_request_accepted,
      #self.agent.mobile,
    #)
  end

  def notify_rejected
    NotificationWorker.perform_async(
      :send_usluga_request_rejected,
      self.agent.mobile,
      self.id,
    )
  end

end
