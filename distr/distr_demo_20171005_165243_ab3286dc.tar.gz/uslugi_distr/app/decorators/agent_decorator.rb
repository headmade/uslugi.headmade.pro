class AgentDecorator < ApplicationDecorator

  def title
    full_name
  end

  def full_name
    [surname, name, patronymic_name].compact.join(' ')
  end

  def as_json_to_sign
    {
      id: id,
      title: title,
    }
  end
end
