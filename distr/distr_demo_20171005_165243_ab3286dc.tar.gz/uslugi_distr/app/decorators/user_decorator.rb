class UserDecorator < ApplicationDecorator

  def mobile
    @mobile ||= user_identities.decorate.map(&:mobile).compact.first
  end

  def title
    @title ||= user_identities.find_by(provider: :esia_oauth)&.decorate&.title || id.to_s
  end

  def esia_roles()
    user_identities.find_by(provider: :esia_oauth)&.data&.dig('info','roles')
  end

  def as_json(_)
    model.attributes.to_hash.except('password_digest').compact.merge(
      mobile: mobile,
      title: title,
    )
  end
end
