class UslugaHistoryDecorator < ApplicationDecorator
  include HistoriableDecorator
end
