class UslugaServantDecorator < UslugaUserDecorator
  decorates_association :servant
  decorates_association :query_passports

  def events
    res = histories.order(id: :desc).decorate.map(&:as_json_event).compact

    h_last = histories.last
    if h_last

      queries = model.queries
      queries = queries.where.not(id: h_last.current['queries']) if h_last.current['queries'].present?
      queries = queries.decorate.map(&:as_json_event)

      if queries.any?
        event = {
          key: 'not_yet',
          name: '(ожидается)',
          style: 'default',
        }

        state_name = model.state
        state = {
            key: state_name,
            name: I18n.t(state_name, scope: 'state_machine.state'),
            style: I18n.t(state_name, scope: 'state_machine.state_style'),
            #signed: signed_states.include?(self.state.to_sym),
        }

        request_params = h_last.request_params
        request_params['data'].delete('signed')
        request_params.delete('action')
        request_params.delete('format')
        request_params.delete('controller')

        res.unshift( {
          id: 0,
          created_at: Time.now(),
          event: event,
          state: state,
          servant: model.servant.decorate.as_json,
          request_params: request_params,
          queries: queries,
        })
      end
    end
    res
  end

  def as_json
    pec = permitted_events_config
    may_sign = pec.select{|ec| ec[:require_sign]}.any?

    # TODO: need smth better
    qps = []
    if (model.assigned? || model.assigned_again?) && model.servant_id == ActionContext.current_servant.id # dirty hack
      qps = self.query_passport_ids
      qps = QueryPassport.pluck(:id) unless qps.any?
    end

    super.merge(
      servant: servant.as_json,
      permitted_events_config: pec,
      query_passports: qps,
      'state' => {
        key: state,
        name: I18n.t(state, scope: 'state_machine.state'),
        style: I18n.t(state, scope: 'state_machine.state_style'),
        signed: signed_states.include?(self.state.to_sym),
      },
    ).merge(may_sign ? {data_to_sign: as_json_to_sign.to_xml(root: 'usluga', skip_types: true, skip_instruct: false, indent: 0)} : {})
  end

  def as_json_to_sign
    {
      id: id,
      state: {key: state, name: I18n.t(state, scope: 'state_machine.state'),},
      servant: servant.as_json_to_sign,
      current_servant: ActionContext.current_servant.as_json_to_sign,
      agent: agent.as_json_to_sign,
      organization_recipient: organization_recipient.as_json_to_sign,
      request_data: SignService.substitute_url_get(request_data),
      result_data: result_data,
      reject_data: reject_data,
      created_at: created_at,
      updated_at: updated_at,
    }
  end

end
