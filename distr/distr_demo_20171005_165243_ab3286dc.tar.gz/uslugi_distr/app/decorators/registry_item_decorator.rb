class RegistryItemDecorator < ApplicationDecorator

  def registry_name
    registry.name
  end

  def as_json
    {registry_name: registry_name}.merge(model.attributes)
  end

  def as_json_s3signed
    S3Service.substitute_url_get(as_json)
  end
end
