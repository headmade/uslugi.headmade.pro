class QueryPassportDecorator < ApplicationDecorator
  decorates_association :department
  decorates_association :servant
  decorates_association :registry

  def title
    model.name
  end

  def as_json(options = nil)
    super.merge(title: title)
  end
end
