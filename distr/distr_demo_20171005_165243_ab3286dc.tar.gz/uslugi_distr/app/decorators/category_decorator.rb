class CategoryDecorator < ApplicationDecorator
  decorates_association :passports
end
