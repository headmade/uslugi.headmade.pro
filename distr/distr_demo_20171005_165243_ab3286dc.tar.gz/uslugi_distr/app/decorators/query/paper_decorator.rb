class Query::PaperDecorator < QueryDecorator
end
