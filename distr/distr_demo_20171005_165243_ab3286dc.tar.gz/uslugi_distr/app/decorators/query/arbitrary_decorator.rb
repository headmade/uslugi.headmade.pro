class Query::ArbitraryDecorator < QueryDecorator
end
