class Query::RegistryDecorator < QueryDecorator

  def title
    super % [::Registry.find(query_passport.data.dig('query','params','registry_id')).decorate.title]
  end
end
