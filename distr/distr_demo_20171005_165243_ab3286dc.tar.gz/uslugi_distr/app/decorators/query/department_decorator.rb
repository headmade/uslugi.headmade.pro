class Query::DepartmentDecorator < QueryDecorator
end
