class Query::ServantDecorator < QueryDecorator
end
