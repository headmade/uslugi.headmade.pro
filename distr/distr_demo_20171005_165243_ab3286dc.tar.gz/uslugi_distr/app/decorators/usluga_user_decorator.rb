class UslugaUserDecorator < ApplicationDecorator
  decorates_association :agent
  decorates_association :organization_recipient

  delegate :name, to: :passport # TODO: replace with title?

  def sign_certificate
    # TODO: always last? sure?
    sc_id = histories.where.not(sign_certificate_id: nil).last&.sign_certificate_id
    SignCertificate.find(sc_id) if sc_id.present?
  end

  def work_duration
    case self.passport_id
    when 29  # signboards
      18.day
    when 30  # annulirovanie
      18.day
    when 37
      1.day
    when 38
      1.day
    when 39
      14.day
    when 40
      5.day
    when 43..48  # signboards
      18.day
    else
      raise 'unknown passport: ' + self.passport_id.to_s
    end
  end

  def expires_at
    expires_at = self.created_at + work_duration

    # TODO: take into account sub-queries
    latest_query = self.queries.order(expires_at: :desc).select(:expires_at).first
    expires_at = [expires_at, latest_query.expires_at].max if latest_query
    expires_at
  end

  def as_json
    is_signed = signed_states.include?(model.state.to_sym)
    user_state = is_signed ? model.state : :submitted

    super.merge(
      'expires_at' => expires_at.end_of_day,
      'state' => {
        key: user_state,
        name: I18n.t(user_state, scope: 'state_machine.state'),
        style: I18n.t(user_state, scope: 'state_machine.state_style'),
        signed: is_signed,
      },
    )
  end

  def as_json_s3signed
    S3Service.substitute_url_get(as_json)
  end
end
