class UserIdentityDecorator < ApplicationDecorator

  def title
    [surname, name[0]+'.', (patronymic_name.present? ? patronymic_name[0]+'.' : nil)].compact.join(' ')
  end

  def mobile
    case provider
    when 'mobile'
      data.dig('data','uid')
    when 'esia_oauth'
      data.dig('info','mobile')
    else
      raise 'Unsupported provider: ' + self.inspect
    end
  end

  def full_name
    [surname, name, patronymic_name].compact.join(' ')
  end
end
