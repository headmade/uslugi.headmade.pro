class RegistryDecorator < ApplicationDecorator
end
