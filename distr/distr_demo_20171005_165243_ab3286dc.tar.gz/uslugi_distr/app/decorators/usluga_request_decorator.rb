class UslugaRequestDecorator < ApplicationDecorator
  delegate :name, to: :passport # TODO: replace with title?

  def events
    histories.order(id: :desc).decorate.map(&:as_json_event).compact
  end

  def as_json
    super.merge(
      servant: servant.as_json,
      permitted_events_config: permitted_events_config,
      state: {
        key: state,
        name: I18n.t(state, scope: 'state_machine.state'),
        style: I18n.t(state, scope: 'state_machine.state_style'),
        signed: signed_states.include?(self.state.to_sym),
      }
    )
  end

  def as_json_s3signed
    S3Service.substitute_url_get(as_json)
  end
end
