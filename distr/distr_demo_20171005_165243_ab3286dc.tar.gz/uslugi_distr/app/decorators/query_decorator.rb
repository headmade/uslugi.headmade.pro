class QueryDecorator < ApplicationDecorator
  decorates_association :usluga
  decorates_association :from_servant
  decorates_association :query_passport

  def title
    query_passport.title
  end

  def events
    histories.order(id: :desc).decorate.map(&:as_json_event).compact
  end

  def as_json_event
    {
      'id' => id,
      title: title,
      servant: from_servant,
      query_passport_id: model.query_passport_id,
      'query_data' => query_data,
      'result_data' => result_data,
      'reject_data' => reject_data,
      'state' => {
        key: state,
        name: I18n.t(state, scope: 'state_machine.state'),
        style: I18n.t(state, scope: 'state_machine.state_style'),
        #signed: signed_states.include?(self.state.to_sym),
      },
    }
  end

  def as_json(options = nil)
    pec = model.permitted_events_config
    #may_sign = pec.select{|ec| ec[:require_sign]}.any?

    super.merge(as_json_event).merge(
      permitted_events_config: pec,
    )
  end

  def as_json_s3signed
    S3Service.substitute_url_get(as_json)
  end
end
