module HistoriableDecorator
  extend ActiveSupport::Concern

  #included do
  #end

  def as_json_event
    request_params = model.request_params
    event_name = request_params['name']
    return nil unless event_name.present?

    event = {
      key: event_name,
      name: I18n.t(event_name, scope: 'state_machine.event'),
      style: I18n.t(event_name.to_s, scope: 'state_machine.event_style'),
      #require_sign: event.transitions.map(&:to).select{|to| signed_states[to]}.compact.present?,
    }

    state_name = model.current_state
    state = {
        key: state_name,
        name: I18n.t(state_name, scope: 'state_machine.state'),
        style: I18n.t(state_name, scope: 'state_machine.state_style'),
        #signed: signed_states.include?(self.state.to_sym),
    }

    queries = Query.where(id: model.current['queries']).decorate.map(&:as_json_event) if model.current['queries'].present?

    #history_owner_name = model.class.history_owner_class_name.constantize.model_name.singular
    #history_owner_id_name = [history_owner_name,'_id'].join
    #history_owner = send(history_owner_name)

    request_params['data'].delete('signed')
    request_params.delete('action')
    request_params.delete('format')
    request_params.delete('controller')
    #request_params.delete(history_owner_name)

    {
      id: model.id,
      created_at: model.created_at,
      event: event,
      state: state,
      servant: model.user.servant.decorate.as_json,
      request_params: request_params,
      queries: queries,
    }
  end

  # TODO: check if need this
  def as_json_short_user
    history_owner = model_name.singular
    history_owner_id_name = [history_owner,'_id'].join
    {
      id: model.id,
      action: model.action,
      created_at: model.created_at,
      current_state: model.current_state,
      request_params: {
        data: model.request_params['data'].except('comments','attachments','signed'),
        name: model.request_params['name']
      },
    }
  end

end

