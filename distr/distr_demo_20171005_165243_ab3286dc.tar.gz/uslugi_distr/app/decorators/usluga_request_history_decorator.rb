class UslugaRequestHistoryDecorator < ApplicationDecorator
  include HistoriableDecorator
end
