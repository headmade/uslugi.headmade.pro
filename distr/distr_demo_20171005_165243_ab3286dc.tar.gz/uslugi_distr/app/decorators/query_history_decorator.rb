class QueryHistoryDecorator < ApplicationDecorator
  include HistoriableDecorator
end
