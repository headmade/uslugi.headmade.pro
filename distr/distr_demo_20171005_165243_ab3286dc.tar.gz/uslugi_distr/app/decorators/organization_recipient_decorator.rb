class OrganizationRecipientDecorator < ApplicationDecorator

  def as_json_to_sign
    {
      id: id,
      inn: inn,
    }
  end
end
