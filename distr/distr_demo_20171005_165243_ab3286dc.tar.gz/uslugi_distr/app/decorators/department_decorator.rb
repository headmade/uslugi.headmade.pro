class DepartmentDecorator < ApplicationDecorator
  decorates_association :passports
  decorates_association :servants

  def title
    model.short_name
  end
end
