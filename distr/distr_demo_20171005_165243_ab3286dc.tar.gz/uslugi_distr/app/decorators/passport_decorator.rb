class PassportDecorator < ApplicationDecorator
  decorates_association :category
  decorates_association :external_system_request_types

  DURATION_FRACTION = 1000000000 # duration is in nanoseconds

  def category_name
    category.name
  end

  def title
    model.name
  end

  def as_json
    esrt = model.external_system_request_types
    esrt = ExternalSystemRequestType.all unless esrt.present?
    super.merge(title: title, external_system_request_types: esrt)
  end

end
