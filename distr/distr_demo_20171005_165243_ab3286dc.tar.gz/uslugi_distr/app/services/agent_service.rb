class AgentService < ApplicationService

  class << self
    def find_or_create_agent(data_agent)
      data_agent = data_agent.clone()
      data_passport_number = data_agent['passport_number']
      fio_passport = (data_agent.delete('fio') || {}).merge('passport_number' => data_passport_number)
      agent = Agent.find_or_initialize_by(fio_passport)
      agent.update!(data_agent.compact)
      return agent
    end
  end

end
