class OrganizationRecipientService < ApplicationService

  class << self
    def find_or_create_organization_recipient(data_or)
      organization_recipient = OrganizationRecipient.find_or_initialize_by('inn' => data_or['inn'])
      organization_recipient.update!(data_or.compact)
      return organization_recipient
    end
  end

end
