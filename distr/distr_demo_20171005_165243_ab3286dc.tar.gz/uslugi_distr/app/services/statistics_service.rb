class StatisticsService < ApplicationService

  class << self
    # TODO: fix: 'usluga_requests' means 'consultations'
    KNOWN_REPORTS = %w(
      top_agents_usluga_requests
      top_agents_uslugas
      top_organizations_usluga_requests
      top_organizations_uslugas
      distribution_time_usluga_requests
      distribution_time_uslugas
      count_per_hour_usluga_requests
      count_per_date_usluga_requests
      count_per_hour_uslugas
      count_per_date_uslugas
      share_per_external_system_request_type_usluga_requests
      share_per_passport_usluga_requests
      share_per_passport_uslugas
      percental_usluga_requests
      percental_uslugas
    )

    def top_agents_usluga_requests(filters)
      rel = Agent
        .joins(:usluga_requests)
        .where(usluga_requests: {state: %i(consultation consulted)})
        .where(usluga_requests: {created_at: filter_date_from(filters)..filter_date_to(filters)})
        .group('agents.id')
        .order('count_all desc')
        .limit(10)

      passport_id = filter_passport_id(filters)
      rel = rel.where(usluga_requests: {passport_id: passport_id}) if passport_id.present?

      rel.count.map{|k,v| {value: v, object: Agent.find(k)}}
    end

    def top_agents_uslugas(filters)
      rel = Agent
        .joins(:uslugas)
        .where(uslugas: {created_at: filter_date_from(filters)..filter_date_to(filters)})
        .group('agents.id')
        .order('count_all desc')
        .limit(10)

      passport_id = filter_passport_id(filters)
      rel = rel.where(uslugas: {passport_id: passport_id}) if passport_id.present?

      rel.count.map{|k,v| {value: v, object: Agent.find(k)}}
    end

    def top_organizations_usluga_requests(filters)
      passport_id = filter_passport_id(filters)
      has_passport_id = passport_id.present?
      sql = %q(
        select
          coalesce(data->'organization'->>'name','(не указано)') as key,
          count(*) as value
        from usluga_requests
        where created_at between $1 and $2
          and state = 'consulted'
          %s
        group by data->'organization'->>'name'
        order by count(*) desc
        limit 10
      ) % [where_passport_id('passport_id', filters)]

      sql_params = [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]
      UslugaRequest.connection.exec_query(sql, 'top_organizations_usluga_requests', sql_params).to_a
    end

    def top_organizations_uslugas(filters)
      passport_id = filter_passport_id(filters)
      has_passport_id = passport_id.present?
      sql = %q(
        select
          request_data->'organization'->>'name' as key,
          count(*) as value
        from uslugas
        where created_at between $1 and $2 %s
        group by request_data->'organization'->>'name'
        order by count(*) desc
        limit 10
      ) % [where_passport_id('passport_id', filters)]

      sql_params = [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]].to_a
      Usluga.connection.exec_query(sql, 'top_organizations_uslugas', sql_params)
    end

    def distribution_time_usluga_requests(filters)
      sql = %q(
        select p.id as passport_id, p.name as passport_name,
            (sum(((ur.updated_at - ur.created_at) between interval '00:00:00' and interval '00:04:59')::integer::float)*100/count(*))::integer as "0..5",
            (sum(((ur.updated_at - ur.created_at) between interval '00:05:00' and interval '00:09:59')::integer::float)*100/count(*))::integer as "5..10",
            (sum(((ur.updated_at - ur.created_at) between interval '00:10:00' and interval '00:14:59')::integer::float)*100/count(*))::integer as "10..15",
            (sum(((ur.updated_at - ur.created_at) between interval '00:15:00' and interval '00:20:00')::integer::float)*100/count(*))::integer as "15..20",
            (sum(((ur.updated_at - ur.created_at) > interval '00:20:00')::integer::float)*100/count(*))::integer as "20+"
        from usluga_requests as ur
            join passports as p on ur.passport_id=p.id
        where ur.deleted_at is null
          and ur.state = 'consulted'
          and ur.created_at between $1 and $2
          and ur.updated_at > ur.created_at
        group by p.id, p.name
        order by p.id
      ) % [where_passport_id('ur.passport_id', filters)]

      UslugaRequest.connection.exec_query(sql, 'distribution_time_usluga_requests', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a

      # in items (not in percents)
      #distribution_time_usluga_requests = UslugaRequest.connection.execute(
      #%q(
        #select p.id as passport_id, p.name as passport_name,
            #sum(((ur.updated_at - ur.created_at) between interval '00:00:00' and interval '00:04:59')::integer) as "0..5",
            #sum(((ur.updated_at - ur.created_at) between interval '00:05:00' and interval '00:09:59')::integer) as "5..10",
            #sum(((ur.updated_at - ur.created_at) between interval '00:10:00' and interval '00:14:59')::integer) as "10..15",
            #sum(((ur.updated_at - ur.created_at) between interval '00:15:00' and interval '00:20:00')::integer) as "15..20",
            #sum(((ur.updated_at - ur.created_at) > interval '00:20:00')::integer) as "20+"
        #from usluga_requests as ur
            #join passports as p on ur.passport_id=p.id
        #where ur.deleted_at is null and ur.updated_at > ur.created_at
        #  and ur.created_at between $1 and $2
        #group by p.id, p.name
        #order by p.id
      #)).to_a
    end

    def distribution_time_uslugas(filters)
      sql = %q(
        select p.id as passport_id, p.name as passport_name,
          (sum(((u.updated_at - u.created_at) between interval '00:00:00' and interval '5 day')::integer::float)*100/count(*))::integer as "0..5",
          (sum(((u.updated_at - u.created_at) between interval '5 day' and interval '10 day')::integer::float)*100/count(*))::integer as "5..10",
          (sum(((u.updated_at - u.created_at) between interval '10 day' and interval '15 day')::integer::float)*100/count(*))::integer as "10..15",
          (sum(((u.updated_at - u.created_at) between interval '15 day' and interval '18 day')::integer::float)*100/count(*))::integer as "15..18",
          (sum(((u.updated_at - u.created_at) > interval '18 day')::integer::float)*100/count(*))::integer as "18+"
        from uslugas as u
          join passports as p on u.passport_id=p.id
        where u.deleted_at is null
          and u.created_at between $1 and $2
          and state in ('completed_signed', 'rejected_signed')
        group by p.id, p.name
        order by p.id
      ) % [where_passport_id('u.passport_id', filters)]

      Usluga.connection.exec_query(sql, 'distribution_time_uslugas', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a
    end

    def count_per_hour_usluga_requests(filters)
      sql = %q(
        select extract(hour from created_at) as name, count(*) as value
        from usluga_requests
        where created_at between $1 and $2
          and deleted_at is null
          and state not in ('consultation','consulted')
        group by extract(hour from created_at)
        order by extract(hour from created_at)
      ) % [where_passport_id('passport_id', filters)]

      created = UslugaRequest.connection.exec_query(sql, 'count_per_date_usluga_requests_created', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a

      sql = %q(
        select extract(hour from updated_at) as name, count(*) as value
        from usluga_requests
        where created_at between $1 and $2
          and deleted_at is null
          and state not in ('consultation','consulted')
        group by extract(hour from updated_at)
        order by extract(hour from updated_at)
      ) % [where_passport_id('passport_id', filters)]

      updated = UslugaRequest.connection.exec_query(sql, 'count_per_date_usluga_requests_updated', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a

      res = (0..23).map{|h| [h, {name: h, created: 0, updated: 0}]}.to_h

      created.each { |rec| res[rec['name'].to_i][:created] = rec['value'] }
      updated.each { |rec| res[rec['name'].to_i][:updated] = rec['value'] }

      res.values.select { |v| v[:created] + v[:updated] > 0 }
    end

    def count_per_date_usluga_requests(filters)
      sql = %q(
        select date(created_at), count(*)
        from usluga_requests
        where created_at between $1 and $2
          and state = 'consulted'
          and deleted_at is null
          %s
        group by date(created_at)
        order by date(created_at)
      ) % [where_passport_id('passport_id', filters)]

      UslugaRequest.connection.exec_query(sql, 'count_per_date_usluga_requests', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a
    end

    def count_per_hour_uslugas(filters)
      sql = %q(
        select extract(hour from created_at) as name, count(*) as value
        from uslugas
        where created_at between $1 and $2
          and deleted_at is null
          %s
        group by extract(hour from created_at)
        order by extract(hour from created_at)
      ) % [where_passport_id('passport_id', filters)]

      created = Usluga.connection.exec_query(sql, 'count_per_date_uslugas_created', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a

      sql = %q(
        select extract(hour from updated_at) as name, count(*) as value
        from uslugas
        where created_at between $1 and $2
          and deleted_at is null
          %s
        group by extract(hour from updated_at)
        order by extract(hour from updated_at)
      ) % [where_passport_id('passport_id', filters)]

      updated = Usluga.connection.exec_query(sql, 'count_per_date_uslugas_updated', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a

      res = (0..23).map{|h| [h, {name: h, created: 0, updated: 0}]}.to_h

      created.each { |rec| res[rec['name'].to_i][:created] = rec['value'] }
      updated.each { |rec| res[rec['name'].to_i][:updated] = rec['value'] }

      res.values.select { |v| v[:created] + v[:updated] > 0 }
    end

    def count_per_date_uslugas(filters)
      sql = %q(
        select date(created_at), count(*)
        from uslugas
        where created_at between $1 and $2
          and deleted_at is null
          %s
        group by date(created_at)
        order by date(created_at)
      ) % [where_passport_id('passport_id', filters)]
      Usluga.connection.exec_query(sql, 'count_per_date_uslugas', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a
    end

    def share_per_external_system_request_type_usluga_requests(filters)
      sql = %q(
        select esrt.name as name, count(*) as value
        from external_system_requests as esr
          join external_system_request_types as esrt on esr.external_system_request_type_id=esrt.id
          join usluga_requests as ur on esr.usluga_request_id=ur.id
        where ur.deleted_at is null
          and ur.created_at between $1 and $2
          and ur.state = 'consulted'
          %s
        group by esrt.name
        order by esrt.name
      ) % [where_passport_id('ur.passport_id', filters)]

      UslugaRequest.connection.exec_query(sql, 'share_per_external_system_request_type_usluga_requests', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a
    end

    def share_per_passport_usluga_requests(filters)
      sql = %q(
        select p.id as passport_id, p.name as passport_name, count(*)
        from usluga_requests as ur
          join passports as p on ur.passport_id=p.id
        where ur.deleted_at is null
          and ur.created_at between $1 and $2
          and ur.state = 'consulted'
          %s
        group by p.id, p.name
        order by p.id
      ) % [where_passport_id('p.id', filters)]

      UslugaRequest.connection.exec_query(sql, 'share_per_passport_usluga_requests', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a
    end

    def share_per_passport_uslugas(filters)
      sql = %q(
        select p.id as passport_id, p.name as passport_name, count(*)
        from uslugas as u
          join passports as p on u.passport_id=p.id
        where u.deleted_at is null
          and u.created_at between $1 and $2
          %s
        group by p.id, p.name
        order by p.id
      ) % [where_passport_id('p.id', filters)]

      Usluga.connection.exec_query(sql, 'share_per_passport_uslugas', [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)]]).to_a
    end

    def percental_percent()
      0.9.to_s
    end

    def percental_usluga_requests(filters)
      # '30 minute' - in order to cut off forgotten/error ("not closed") consultations
      passport_id = filter_passport_id(filters)
      rel = Passport.active
      rel = rel.where(id: passport_id) if passport_id.present?
      rel.order(:id).pluck(:id, :name).map do |pas|
        cond = %q{passport_id=$3 and state='consulted' and deleted_at is null and created_at between $1 and $2}
        sql = %Q(
          select (extract(epoch from diff)/60)::integer as minutes
          from (
            select updated_at-created_at as diff from usluga_requests
            where
              updated_at-created_at < interval '30 minute'
              and #{cond}
            order by (updated_at-created_at) asc
            limit (
              select count(*)*($4::float)
              from usluga_requests
              where updated_at-created_at < interval '30 minute' and #{cond}
            )
          ) as t1
          order by diff desc
          limit 1
        )
        res = UslugaRequest.connection.exec_query(
          sql,
          'percental_usluga_requests',
          [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)], [nil, pas[0]], [nil, percental_percent]]
        ).to_a.first
        {id: pas[0], name: pas[1], minutes: res['minutes']} if res
      end.compact
    end

    def percental_uslugas(filters)
      passport_id = filter_passport_id(filters)
      rel = Passport.active
      rel = rel.where(id: passport_id) if passport_id.present?
      rel.order(:id).pluck(:id, :name).map do |pas|
        cond = "passport_id=$3 and updated_at > created_at and deleted_at is null and created_at between $1 and $2 and state in ('completed_signed', 'rejected_signed')"
        sql = %Q(
          select (extract(epoch from diff)/86400)::integer as days
          from (
            select updated_at-created_at as diff from uslugas
            where #{cond}
            order by (updated_at-created_at) asc
            limit (
              select count(*)*($4::float)
              from uslugas
              where #{cond}
            )
          ) as t1
          order by diff desc
          limit 1
        )
        res = Usluga.connection.exec_query(
          sql,
          'percental_uslugas',
          [[nil,filter_date_from(filters)], [nil,filter_date_to(filters)], [nil, pas[0]], [nil, percental_percent]]
        ).to_a.first
        {id: pas[0], name: pas[1], days: res['days']} if res
      end.compact
    end

    def build_reports(filters, report_keys=nil)
      report_keys ||= KNOWN_REPORTS
      report_keys.map{|rk| [rk, send(rk, filters)]}.to_h
    end

    private

    def filter_date_from(filters)
      date_from = filters[:date_from]
      date_from = date_from.present? ? date_from.to_date : Time.at(0)
      date_from.beginning_of_day
    end

    def filter_date_to(filters)
      date_to = filters[:date_to]
      date_to = date_to.present? ? date_to.to_date : (ActionContext.now || Time.now) # TODO: fix timezone of Time.now
      date_to.end_of_day
    end

    def filter_passport_id(filters)
      filters[:passport_id]
    end

    def where_passport_id(field, filters)
      passport_id = filter_passport_id(filters)
      if passport_id.present?
        [" and #{field} in (", passport_id.map(&:to_i).join(','), ') '].join
      else
        ''
      end
    end

    def rel_passport_id(rel, filters)
      passport_id = filter_passport_id(filters)
      if passport_id.present?
        rel.where(passport_id: passport_id)
      else
        rel
      end
    end


  end

end
