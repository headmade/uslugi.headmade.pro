class RegistryService < ApplicationService

  class << self
    # returns the new/modified registry item
    def process_command(registry_id, command, data)
      registry = Registry.find(registry_id)
      case command
      when 'add'
        registry.registry_items.create!(data: data)
      when 'change'
        Rails.logger.debug 'change'
      when 'delete'
        Rails.logger.debug 'delete'
      else
        raise 'unsupportted command: ' + command
      end
    end
  end

end
