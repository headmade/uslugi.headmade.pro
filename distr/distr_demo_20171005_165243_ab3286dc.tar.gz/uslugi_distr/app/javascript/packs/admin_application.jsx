import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import { createStore, applyMiddleware } from 'redux'
import { Provider } from 'react-redux';
import logger from 'redux-logger'
import * as Statistics from '~/routing/statistics'

axios.defaults.headers['X-CSRF-Token'] = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
axios.defaults.baseURL='/api/admin'

const RouterApp = ({ store }) => (
  <Provider className="test" store={store}>
    <div>
      <Statistics.Show />
    </div>
  </Provider>
)

RouterApp.propTypes = {
  store: PropTypes.object.isRequired,
}

const initialState = {
  current_user: {},
}

function stateApp(state=initialState, action) {
  switch (action.type){
    case "SET_CURRENT_USER":
      return Object.assign({}, state, {current_user: action.session})
    default:
     return state
  }
}

let store = createStore(stateApp, applyMiddleware(logger))

axios.get("/session.json")
  .then((response)=>{
    store.dispatch({type: "SET_CURRENT_USER", session: response.data})
  })
  .catch((error)=>{
    console.log(error)
  })

document.addEventListener('DOMContentLoaded', () => {
  ReactDOM.render(
    <RouterApp store={store}/>,
    document.getElementById('admin_application')
  )
})
