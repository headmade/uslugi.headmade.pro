import React from 'react'
import ReactDOM from 'react-dom'
import axios from 'axios'
import App from '~/user/app'
import '~/configs'

axios.defaults.baseURL='/api/user'

document.addEventListener('DOMContentLoaded', () => {
  const node = document.getElementById('user_application')
  const data = JSON.parse(node.getAttribute('data'))

  ReactDOM.render(
    <App config={data} />,
    node
  )
})
