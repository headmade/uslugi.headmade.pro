import React, {PureComponent} from 'react'
import {render} from 'react-dom'
import {StickyContainer} from 'react-sticky'

import NavIndex from '../components/test_index/nav_index'
import BreadcrumbIndex from '../components/test_index/breadcramps'
import PopularServices from '../components/test_index/popular_services'
import CatalogServices from '../components/test_index/catalog_services'
import Service from '../components/test_index/service'
import InfoBanner from '../components/test_index/info-banner'
import Thanks from '../components/test_index/thanks'


class General extends PureComponent {
  render() {
    return (
      <div>
        <StickyContainer>
          <NavIndex />
          <hr className="myHr"/>
          <BreadcrumbIndex />
          <hr className="myHr"/>
          <InfoBanner />
          <hr className="myHr"/>
          <PopularServices />
          <hr className="myHr"/>
          <CatalogServices />
          <hr className="myHr"/>
          <Thanks/>
          <hr className="myHr"/>
          <Service />
        </StickyContainer>
      </div>
    )
  }
}

render(<General />, document.getElementById('test_index'))
