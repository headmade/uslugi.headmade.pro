import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import App from '~/servant/app'
import '~/configs'

axios.defaults.baseURL='/api/servant'

axios.interceptors.response.use(function (response) {
    return response;
  }, function (error) {
    if (error.response.status === 403){
      window.location = '/auth/esia_oauth'
    }
    return Promise.reject(error);
  });


document.addEventListener('DOMContentLoaded', () => {
  const node = document.getElementById('servant_application')
  const data = JSON.parse(node.getAttribute('data'))

  ReactDOM.render(
    <App config={data} />,
    node
  )
})
