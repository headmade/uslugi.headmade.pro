import React, {Component} from 'react'

export default class ServiceQuestion extends Component {
  render() {
    return (
      <div className="service-question">
        <div className="service-question__info">
          <h4 className="service-question__info-date">Сроки оказания услуги</h4>
          <p className="service-question__info-text">В день обращения</p>
        </div>
        <div className="service-question__info">
          <h4 className="service-question__info-price">Стоимость услуги</h4>
          <p className="service-question__info-text">Услуга предоставляется бесплатно</p>
        </div>
        <ul className="service-question__list">
          <li className="service-question__list-item_caption">Как получить услугу?</li>
          <li className="service-question__list-item">в электронном виде возможно не только сформировать заявление, но и
            отслеживать место ребенка в очереди;
          </li>
          <li className="service-question__list-item">запись в детский сад возможна с момента рождения ребенка;</li>
          <li className="service-question__list-item">при подаче заявления необходимо указать желательный год
            зачисления, наличие права на льготное зачисление, специфику группы и выбрать до 3 желаемых ДОО по месту
            жительства ребёнка.
          </li>
        </ul>
      </div>
    )
  }
}