import React, {Component} from 'react'
import {Grid, Row, Col} from 'react-bootstrap'
import CatalogServicesItems from './catalog_services_items'
import BaseCaption from './base_caption'

export default class CatalogServices extends Component {
  render() {
    const catalogServices = [
      {
        id: '1',
        svg: 'https://gu-st.ru/content/catalog/pas/13.svg',
        caption: 'Запись на прием к врачу',
        text: 'Выберите поликлинику и запишитесь к специалисту',
        itemsLink: [
          {
            itemNumber: 1,
            item: 'Медико социальная экспертиза'
          },
          {
            itemNumber: 2,
            item: 'Медико социальная экспертиза2'
          },
          {
            itemNumber: 3,
            item: 'Медико социальная экспертиза3'
          }
        ]
      },
      {
        id: '2',
        svg: 'https://gu-st.ru/content/catalog/pas/13.svg',
        caption: 'Запись на прием к врачу',
        text: 'Выберите поликлинику и запишитесь к специалисту',
        itemsLink: [
          {
            itemNumber: 1,
            item: 'Медико социальная экспертиза'
          },
          {
            itemNumber: 2,
            item: 'Медико социальная экспертиза2'
          },
          {
            itemNumber: 3,
            item: 'Медико социальная экспертиза3'
          }
        ]
      },
      {
        id: '3',
        svg: 'https://gu-st.ru/content/catalog/pas/13.svg',
        caption: 'Запись на прием к врачу',
        text: 'Выберите поликлинику и запишитесь к специалисту',
        itemsLink: [
          {
            itemNumber: 1,
            item: 'Медико социальная экспертиза'
          },
          {
            itemNumber: 2,
            item: 'Медико социальная экспертиза2'
          },
          {
            itemNumber: 3,
            item: 'Медико социальная экспертиза3'
          }
        ]
      },
      {
        id: '4',
        svg: 'https://gu-st.ru/content/catalog/pas/13.svg',
        caption: 'Запись на прием к врачу',
        text: 'Выберите поликлинику и запишитесь к специалисту',
        itemsLink: [
          {
            itemNumber: 1,
            item: 'Медико социальная экспертиза'
          },
          {
            itemNumber: 2,
            item: 'Медико социальная экспертиза2'
          },
          {
            itemNumber: 3,
            item: 'Медико социальная экспертиза3'
          }
        ]
      },
      {
        id: '5',
        svg: 'https://gu-st.ru/content/catalog/pas/13.svg',
        caption: 'Запись на прием к врачу',
        text: 'Выберите поликлинику и запишитесь к специалисту',
        itemsLink: [
          {
            itemNumber: 1,
            item: 'Медико социальная экспертиза'
          },
          {
            itemNumber: 2,
            item: 'Медико социальная экспертиза2'
          },
          {
            itemNumber: 3,
            item: 'Медико социальная экспертиза3'
          }
        ]
      }
    ]
    return (
      <div className="catalog-services-wrapper">
        <Grid>
          <Row>
            <Col xs={12}>
              <BaseCaption title={"Каталог услуг Казани"} position={"left"} />
              <CatalogServicesItems catalogServices={catalogServices} />
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}