import React, {Component} from 'react'
import {Grid, Row, Col} from 'react-bootstrap'
import PopularServicesItems from './popular_services_items'
import BaseCaption from './base_caption'

export default class PopularServices extends Component {
  render() {
    const services = [
      {
        id: '1',
        svg: 'https://gu-st.ru/content/catalog/pas/13.svg',
        caption: 'Запись на прием к врачу',
        text: 'Выберите поликлинику и запишитесь к специалисту'
      },
      {
        id: '2',
        svg: 'https://gu-st.ru/content/catalog/pas/12.svg',
        caption: 'Извещение о состоянии лицевого счета в ПФР',
        text: 'Узнайте состояние лицевого счета в системе обязательного пенсионного страхования'
      },
      {
        id: '3',
        svg: 'https://gu-st.ru/content/catalog/pas/11.svg',
        caption: 'Регистрация транспортного средства',
        text: 'Подайте заявление онлайн и запишитесь на прием в ближайшее отделение Госавтоинспекции'
      }
    ]
    return (
      <div className="popular-services-wrapper">
        <Grid>
          <Row>
            <Col xs={12}>
              <BaseCaption title={"Популярные услуги"} position={"center"} />
              <PopularServicesItems services={services}  /> {/*test={require('~/images/list256-21.svg')}*/}
              <div className="myBtn-wrapper">
                <a href="#" className="myBtn arrow-right-btn">Все услуги</a>
              </div>
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}
