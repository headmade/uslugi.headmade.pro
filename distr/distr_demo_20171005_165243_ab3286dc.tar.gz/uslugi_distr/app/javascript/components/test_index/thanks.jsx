import React, { Component } from 'react'
import {Grid, Row, Col} from 'react-bootstrap'

export default class Thanks extends Component {
  render() {
    const thanks = {
      numberStatement: '12',
      emailUser: 'email@email.ru',
      phoneUser: '89123456789'
    }

    return(
      <Grid>
        <Row>
          <Col xs={12}>
            <div className="thanks">
              <div className="thanks__caption-wrapper">
                <div className="thanks__ok" />
                <h3 className="thanks__caption">Ваше заявление №{thanks.numberStatement} принято для передачи в ведомство</h3>
              </div>
              <div className="thanks__info">
                <p className="thanks__info-text">Следите за его статусом в личном кабинете, на портале госуслуг, по элекронной почте или в SMS-сообщениях</p>
                <div className="thanks__info-phone-wrapper">
                  <span className="thanks__info-phone">Мобильный телефон</span>
                  {thanks.phoneUser ? <span className="thanks__info-email-text">{thanks.phoneUser}</span> : <a className="thanks__info-phone-link" href="#">Укажите мобильный телефон</a>}
                </div>
                <div className="thanks__info-email-wrapper">
                  <span className="thanks__info-email">Электронная почта</span>
                  <span className="thanks__info-email-text">{thanks.emailUser}</span>
                </div>
              </div>
              <div className="thanks__btn-wrapper">
                <div className="myBtn arrow-right-btn">Перейти в личный кабинет</div>
                <a className="thanks__link" href="#">Изменить настройки уведомлений</a>
              </div>
            </div>
          </Col>
        </Row>
      </Grid>
    )
  }
}
