import React, {Component} from 'react'
import {Grid, Row, Col} from 'react-bootstrap'

export default class InfoBanner extends Component {
  render() {
    return (
      <div className="info-banner-wrapper info-banner--warning"> {/* 3 темы зависят от класса - 1.info-banner--warning 2.info-banner--success 3.info-banner--danger */}
        <Grid>
          <Row>
            <Col xs={12}>
              <p className="info-banner-text">Откройте доступ к большему количеству услуг - добавте данные паспорта и
                СНИЛС в <a href="#">личном кабинете!</a></p>
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}
