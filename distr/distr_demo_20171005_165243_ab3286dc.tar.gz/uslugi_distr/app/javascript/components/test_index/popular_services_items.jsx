import React, {Component} from 'react'

export default class PopularServicesItems extends Component {
  render() {
    const services = this.props.services
    return (
      <div className="popular-services__items-wrapper">
        {
          services.map((services) => {
            return (
            <a key={services.id} className="popular-services" href="#">
              <div className="popular-services__img-wrapper">
                <img src={services.svg} alt="Services" />
              </div>
              <div className="popular-services__info">
                <h4 className="popular-services__name">{services.caption}</h4>
                <p className="popular-services__act">{services.text}<span> > </span></p>
              </div>
            </a>
            )
          })
        }
      </div>
    )
  }
}