import React, {Component} from 'react'
import BaseCaption from './base_caption'

export default class ServiceCaption extends Component {
  render() {
    return (
      <div className="service-caption">
        <div className="popular-services__img-wrapper">
          <img src={require('~/images/list256-21.svg')} alt="Services" />
        </div>
        <BaseCaption title={"Получение паспорта"} position={"left"} />
      </div>
    )
  }
}
