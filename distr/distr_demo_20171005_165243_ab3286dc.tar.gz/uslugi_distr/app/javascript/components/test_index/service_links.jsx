import React, {Component} from 'react'

export default class ServiceLinks extends Component {
  render() {
    return (
      <div className="service__links">
        <h4 className="service__links-caption">Электронные услуги</h4>
        <ul className="service__links-list">
          <li className="service__links-item"><a href="#">Запись в детский сад</a></li>
          <li className="service__links-item"><a href="#">Отменить или изменить запись</a></li>
          <li className="service__links-item"><a href="#">Проверить очередь</a></li>
        </ul>
      </div>
    )
  }
}