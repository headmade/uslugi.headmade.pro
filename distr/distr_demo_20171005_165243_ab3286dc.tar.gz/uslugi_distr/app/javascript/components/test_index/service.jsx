import React, {Component} from 'react'
import {Grid, Row, Col} from 'react-bootstrap'
import ServiceCaption from './service_caption'
import ServiceCaptionDetail from './service_caption_detail'
import ServiceLinks from './service_links'
import ServiceQuest from './service_quest'
import ServiceQuestion from './service_question'
import ServiceDetail from './service_detail'
import FormsAll from './forms_all'

export default class Service extends Component {
  render() {
    return (
      <div className="service-wrapper">
        <Grid>
          <Row>
            <Col xs={12}>
              <ServiceCaption />
              <ServiceCaptionDetail />
              <ServiceLinks />
              <ServiceQuestion />
              <FormsAll />
              <ServiceQuest />
              <ServiceDetail />
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}
