import React, {Component} from 'react'
import List25621 from '~/images/list256-21.svg'
import List25624 from '~/images/list256-24.svg'
import List25658 from '~/images/list256-58.svg'

export default class CatalogServicesItems extends Component {
  render() {
    const catalogServices = this.props.catalogServices
    return (
      <div className="catalog-services__items-wrapper">
        {
          catalogServices.map((catalogServices) => {
            return (
              <div key={catalogServices.id} className="catalog-services">
                <a className="popular-services" href="#">
                  <div className="popular-services__img-wrapper">
                    <img src={catalogServices.svg} alt="Services" />
                  </div>
                  <h4 className="popular-services__name">{catalogServices.caption}</h4>
                </a>
                <p className="catalog-services__act">{catalogServices.text}</p>
                {
                  catalogServices.itemsLink.map((itemsLink) => {
                    return <a key={itemsLink.itemNumber} className="catalog-services__link-service" href="#">{itemsLink.item}<span> > </span></a>
                  })
                }
                <a href="#" className="myBtn transparent-btn">Все услуги</a>
              </div>
            )})
        }
      </div>
    )
  }
}
