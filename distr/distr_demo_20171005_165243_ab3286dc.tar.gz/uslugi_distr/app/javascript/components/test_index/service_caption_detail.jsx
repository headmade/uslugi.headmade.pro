import React, {Component} from 'react'

export default class ServiceCaptionDetail extends Component {
  render() {
    return (
      <div className="service-caption-detail">
        <h2 className="catalog-services__caption-detail-text">Получение паспорта нового поколения гражданином Российской Федерации, достигшим 18-летнего возраста</h2>
        <a className="catalog-services__caption-detail-link" href="#">Подробная информация ></a>
      </div>
    )
  }
}
