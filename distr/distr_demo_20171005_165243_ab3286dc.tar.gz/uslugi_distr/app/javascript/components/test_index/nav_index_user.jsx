import React, {Component} from 'react'


export default class NavIndexUser extends Component {
  render() {
    return (
      <li className="nav-list__item nav-index-user">
        <span className="nav-index-user__caption-message">5</span>
        <a className="nav-index-user__caption">Иванов И.И.</a>
        <ul className="nav-index-user__dropdown">
          <li className="nav-index-user__dropdown-item"><a href="#">Ссыыыыыыыыыыыыыыыыыылка</a></li>
          <li className="nav-index-user__dropdown-item"><a href="#">Выход</a></li>
        </ul>
      </li>
    )
  }
}
