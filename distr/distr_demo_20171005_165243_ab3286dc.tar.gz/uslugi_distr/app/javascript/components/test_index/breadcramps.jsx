import React, {Component} from 'react'
import {Grid, Row, Col, Breadcrumb} from 'react-bootstrap'
import Home from '~/images/home.svg'

export default class BreadcrumbIndex extends Component {
  render() {
    return (
      <div className="Breadcrumb-wrapper">
        <Grid>
          <Row>
            <Col xs={12}>
              <Breadcrumb>
                <Breadcrumb.Item href="#">
                  <div className="breadcrumb__img-wrapper">
                    <img src={Home} alt="Index" />
                  </div>
                  Главная
                </Breadcrumb.Item>
                <Breadcrumb.Item href="#">
                  link
                </Breadcrumb.Item>
                <Breadcrumb.Item active>
                  Data
                </Breadcrumb.Item>
              </Breadcrumb>
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}
