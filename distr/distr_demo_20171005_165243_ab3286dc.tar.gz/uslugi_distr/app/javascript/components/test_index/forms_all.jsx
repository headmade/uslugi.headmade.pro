import React, {Component} from 'react'

export default class FormsAll extends Component {
  render() {
    return (
      <form className="form" action="">
        <hr/>
        <div className="form__caption">
          <span className="form__caption-number">1</span>
          <span className="form__caption-text">Пожалуйста, выберите регион, в котором хотите записаться к врачу</span>
        </div>
        {/*<AgentAutosuggest />*/}
        <hr/>
        <div className="form__caption">
          <span className="form__caption-number">2</span>
          <span className="form__caption-text">Кому необходимо записаться на прием?</span>
        </div>
        <div className="input-group">
          <div className="input-wrapper">
            <input type="text" id="snils" required/>
            <label htmlFor="snils">Снилс</label>
            <div className="info-tooltip">?</div>
            <div className="info-tooltip-content">
              <img src="https://gu-st.ru/cms/htdocs/0/0/0/0/0/0/0/0/0/snils.png" alt="111"/>
              Lorem ipsum dolor sit amet, consectetur adipisicingelit. Atque laborum repellat tempora. Ipsam unde, ut.
            </div>
            <div className="error-tooltip">!</div>
            <div className="error-tooltip-content">Поле обязательно для заполнения</div>
            <div className="input__under-text">при наличии</div>
          </div>
          <div className="input-wrapper radio-wrapper">
            <div className="option-wrapper">
              <input type="radio" name="radio-mens" id="radio-men" value="1" />
              <label htmlFor="radio-men">
                <svg id="Capa_1" x="0px" y="0px" viewBox="0 0 27.02 27.02"  width="50px" height="50px"
                >
                  <g>
                    <path  d="M3.674,24.876c0,0-0.024,0.604,0.566,0.604c0.734,0,6.811-0.008,6.811-0.008l0.01-5.581   c0,0-0.096-0.92,0.797-0.92h2.826c1.056,0,0.991,0.92,0.991,0.92l-0.012,5.563c0,0,5.762,0,6.667,0   c0.749,0,0.715-0.752,0.715-0.752V14.413l-9.396-8.358l-9.975,8.358C3.674,14.413,3.674,24.876,3.674,24.876z" />
                    <path  d="M0,13.635c0,0,0.847,1.561,2.694,0l11.038-9.338l10.349,9.28c2.138,1.542,2.939,0,2.939,0   L13.732,1.54L0,13.635z" />
                    <polygon points="23.83,4.275 21.168,4.275 21.179,7.503 23.83,9.752"/>
                  </g>
                </svg>
              </label>
            </div>
            <div className="option-wrapper">
              <input type="radio" name="radio-mens" id="radio-women" value="2" />
              <label htmlFor="radio-women">
                <svg id="Capa_1" x="0px" y="0px" viewBox="0 0 27.02 27.02"  width="50px" height="50px" fill="#777777">
                  <g>
                    <path className="test1" d="M3.674,24.876c0,0-0.024,0.604,0.566,0.604c0.734,0,6.811-0.008,6.811-0.008l0.01-5.581   c0,0-0.096-0.92,0.797-0.92h2.826c1.056,0,0.991,0.92,0.991,0.92l-0.012,5.563c0,0,5.762,0,6.667,0   c0.749,0,0.715-0.752,0.715-0.752V14.413l-9.396-8.358l-9.975,8.358C3.674,14.413,3.674,24.876,3.674,24.876z" />
                    <path className="test2" d="M0,13.635c0,0,0.847,1.561,2.694,0l11.038-9.338l10.349,9.28c2.138,1.542,2.939,0,2.939,0   L13.732,1.54L0,13.635z" />
                    <polygon points="23.83,4.275 21.168,4.275 21.179,7.503 23.83,9.752"/>
                  </g>
                </svg>
              </label>
            </div>
            <div className="input__under-text radio-error">Поле обязательно для заполнения</div>
          </div>
          <div className="input-wrapper radio-wrapper">
            <div className="option-wrapper">
              <input type="radio" name="radio-mens2" id="radio-men3" disabled checked />
              <label htmlFor="radio-men3">
                <svg id="Capa_1" x="0px" y="0px" viewBox="0 0 27.02 27.02"  width="50px" height="50px">
                  <g>
                    <path  d="M3.674,24.876c0,0-0.024,0.604,0.566,0.604c0.734,0,6.811-0.008,6.811-0.008l0.01-5.581   c0,0-0.096-0.92,0.797-0.92h2.826c1.056,0,0.991,0.92,0.991,0.92l-0.012,5.563c0,0,5.762,0,6.667,0   c0.749,0,0.715-0.752,0.715-0.752V14.413l-9.396-8.358l-9.975,8.358C3.674,14.413,3.674,24.876,3.674,24.876z" />
                    <path  d="M0,13.635c0,0,0.847,1.561,2.694,0l11.038-9.338l10.349,9.28c2.138,1.542,2.939,0,2.939,0   L13.732,1.54L0,13.635z" />
                    <polygon points="23.83,4.275 21.168,4.275 21.179,7.503 23.83,9.752"/>
                  </g>
                </svg>
              </label>
            </div>
            <div className="option-wrapper">
              <input type="radio" name="radio-mens2" id="radio-women2" disabled  />
              <label htmlFor="radio-women2">
                <svg id="Capa_1" x="0px" y="0px" viewBox="0 0 27.02 27.02"  width="50px" height="50px" fill="#777777">
                  <g>
                    <path className="test1" d="M3.674,24.876c0,0-0.024,0.604,0.566,0.604c0.734,0,6.811-0.008,6.811-0.008l0.01-5.581   c0,0-0.096-0.92,0.797-0.92h2.826c1.056,0,0.991,0.92,0.991,0.92l-0.012,5.563c0,0,5.762,0,6.667,0   c0.749,0,0.715-0.752,0.715-0.752V14.413l-9.396-8.358l-9.975,8.358C3.674,14.413,3.674,24.876,3.674,24.876z" />
                    <path className="test2" d="M0,13.635c0,0,0.847,1.561,2.694,0l11.038-9.338l10.349,9.28c2.138,1.542,2.939,0,2.939,0   L13.732,1.54L0,13.635z" />
                    <polygon points="23.83,4.275 21.168,4.275 21.179,7.503 23.83,9.752"/>
                  </g>
                </svg>
              </label>
              <div className="input__under-text radio-error">Поле обязательно для заполнения</div>
            </div>
          </div>
        </div>
        <div className="input-group radio-dropdown">
          <div className="input-wrapper radio-wrapper">
            <div className="option-wrapper">
              <input type="radio" name="radio-dropdown" id="radio-dropdown1" />
              <label htmlFor="radio-dropdown1">Open</label>
              <div className="content-radio">
                <h4 className="content-radio__caption">
                  Caption
                  <a href="#" className="content-radio__update-info">Изменить данные</a>
                </h4>
                <div className="input-group">
                  <div className="input-wrapper">
                    <input type="text" id="name" required/>
                    <label htmlFor="name">Имя</label>
                    <div className="error-tooltip">!</div>
                    <div className="error-tooltip-content">Поле обязательно для заполнения</div>
                  </div>
                  <div className="input-wrapper input-text-disabled">
                    <input type="text" id="surname" required disabled value={"Ghadfbfa"} />
                    <label htmlFor="surname">Фамилия</label>
                    <div className="error-tooltip">!</div>
                    <div className="error-tooltip-content">Поле обязательно для заполнения</div>
                  </div>
                  <div className="input-wrapper">
                    <input type="text" id="patronymic" required/>
                    <label htmlFor="patronymic">Отчество</label>
                    <div className="error-tooltip">!</div>
                    <div className="error-tooltip-content">Поле обязательно для заполнения</div>
                    <div className="input__under-text">при наличии</div>
                  </div>
                </div>
                <div className="input-group">
                  <div className="input-wrapper">
                    <input type="text" id="name" required/>
                    <label htmlFor="name">Имя</label>
                    <div className="error-tooltip">!</div>
                    <div className="error-tooltip-content">Поле обязательно для заполнения</div>
                  </div>
                  <div className="input-wrapper input-text-disabled">
                    <input type="text" id="surname" required disabled value={"Ghadfbfa"} />
                    <label htmlFor="surname">Фамилия</label>
                    <div className="error-tooltip">!</div>
                    <div className="error-tooltip-content">Поле обязательно для заполнения</div>
                  </div>
                  <div className="input-wrapper">
                    <input type="text" id="patronymic" required/>
                    <label htmlFor="patronymic">Отчество</label>
                    <div className="error-tooltip">!</div>
                    <div className="error-tooltip-content">Поле обязательно для заполнения</div>
                    <div className="input__under-text">при наличии</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="option-wrapper">
              <input type="radio" name="radio-dropdown" id="radio-dropdown2" />
              <label htmlFor="radio-dropdown2">Open</label>
              <div className="content-radio">124123513</div>
            </div>
          </div>
        </div>
        <div className="input-group checkbox-group">
          <div className="input-wrapper checkbox-wrapper">
            <div className="option-wrapper">
              <input type="checkbox" name="checkbox-car" id="checkbox-3" />
              <label htmlFor="checkbox-3">
                <svg id="Capa_1" x="0px" y="0px" viewBox="0 0 27.02 27.02"  width="50px" height="50px" fill="#777777">
                  <g>
                    <path className="test1" d="M3.674,24.876c0,0-0.024,0.604,0.566,0.604c0.734,0,6.811-0.008,6.811-0.008l0.01-5.581   c0,0-0.096-0.92,0.797-0.92h2.826c1.056,0,0.991,0.92,0.991,0.92l-0.012,5.563c0,0,5.762,0,6.667,0   c0.749,0,0.715-0.752,0.715-0.752V14.413l-9.396-8.358l-9.975,8.358C3.674,14.413,3.674,24.876,3.674,24.876z" />
                    <path className="test2" d="M0,13.635c0,0,0.847,1.561,2.694,0l11.038-9.338l10.349,9.28c2.138,1.542,2.939,0,2.939,0   L13.732,1.54L0,13.635z" />
                    <polygon points="23.83,4.275 21.168,4.275 21.179,7.503 23.83,9.752"/>
                  </g>
                </svg>
                <span className="checkbox-text">ghbvth</span>
              </label>
              <div className="input__under-text checkbox-error">Поле обязательно для заполнения</div>
            </div>
          </div>
          <div className="input-wrapper checkbox-wrapper">
            <div className="option-wrapper">
              <input type="checkbox" name="checkbox-car" id="checkbox-2" disabled />
              <label htmlFor="checkbox-2">
                <svg id="Capa_1" x="0px" y="0px" viewBox="0 0 27.02 27.02"  width="50px" height="50px" fill="#777777">
                  <g>
                    <path className="test1" d="M3.674,24.876c0,0-0.024,0.604,0.566,0.604c0.734,0,6.811-0.008,6.811-0.008l0.01-5.581   c0,0-0.096-0.92,0.797-0.92h2.826c1.056,0,0.991,0.92,0.991,0.92l-0.012,5.563c0,0,5.762,0,6.667,0   c0.749,0,0.715-0.752,0.715-0.752V14.413l-9.396-8.358l-9.975,8.358C3.674,14.413,3.674,24.876,3.674,24.876z" />
                    <path className="test2" d="M0,13.635c0,0,0.847,1.561,2.694,0l11.038-9.338l10.349,9.28c2.138,1.542,2.939,0,2.939,0   L13.732,1.54L0,13.635z" />
                    <polygon points="23.83,4.275 21.168,4.275 21.179,7.503 23.83,9.752"/>
                  </g>
                </svg>
                <span className="checkbox-text">ghbvth <br/>SDvSEGEsg</span>
              </label>
              <div className="input__under-text checkbox-error">Поле обязательно для заполнения</div>
            </div>
          </div>
          <div className="input-wrapper checkbox-wrapper">
            <div className="option-wrapper">
              <input type="checkbox" name="checkbox-car" id="checkbox-1" disabled checked />
              <label htmlFor="checkbox-1">
                <svg id="Capa_1" x="0px" y="0px" viewBox="0 0 27.02 27.02"  width="50px" height="50px" fill="#777777">
                  <g>
                    <path className="test1" d="M3.674,24.876c0,0-0.024,0.604,0.566,0.604c0.734,0,6.811-0.008,6.811-0.008l0.01-5.581   c0,0-0.096-0.92,0.797-0.92h2.826c1.056,0,0.991,0.92,0.991,0.92l-0.012,5.563c0,0,5.762,0,6.667,0   c0.749,0,0.715-0.752,0.715-0.752V14.413l-9.396-8.358l-9.975,8.358C3.674,14.413,3.674,24.876,3.674,24.876z" />
                    <path className="test2" d="M0,13.635c0,0,0.847,1.561,2.694,0l11.038-9.338l10.349,9.28c2.138,1.542,2.939,0,2.939,0   L13.732,1.54L0,13.635z" />
                    <polygon points="23.83,4.275 21.168,4.275 21.179,7.503 23.83,9.752"/>
                  </g>
                </svg>
              </label>
              <div className="input__under-text checkbox-error">Поле обязательно для заполнения</div>
            </div>
          </div>
        </div>
        <hr/>
      </form>
  )
  }
  }