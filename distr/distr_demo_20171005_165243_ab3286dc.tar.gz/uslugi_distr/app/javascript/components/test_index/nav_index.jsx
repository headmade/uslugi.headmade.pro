import React, {Component} from 'react'
import {Grid, Row, Col} from 'react-bootstrap'
import {Sticky} from 'react-sticky'
import NavIndexUser from './nav_index_user'


export default class NavIndex extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isToggleOn: true
    }

    this.handleClick = this.handleClick.bind(this)
  }

  handleClick() {
    this.setState(prevState => ({
      isToggleOn: !prevState.isToggleOn
    }))
  }

  render() {
    const {title} = this.config
    return (
      <Sticky>
        {({style}) => {
          return (
            <div className="MySticky" style={{...style, height: 75}}>
              <div className="nav-wrapper">
                <Grid>
                  <Row>
                    <Col xs={12}>
                      <ul className="nav-list">
                        <li className="nav-list__item nav-list__item-logo"><a
                          href="#"
                        ><span className="banner-logo">ИС <span>Услуги</span></span></a></li>
                        <ul className={'nav-list__items ' + (this.state.isToggleOn ? '' : 'nav-list__items_active')}>
                          <li className="nav-list__item nav-list__item_active"><a href="#">Каталог</a></li>
                          <li className="nav-list__item"><a href="#">Вопросы и ответы</a></li>
                          <li className="nav-list__item"><a href="#">Оплата</a></li>
                          <NavIndexUser />
                        </ul>
                        <div className="hamburger-wrapper">
                          <button
                            className={'c-hamburger c-hamburger--htx ' + (this.state.isToggleOn ? '' : 'is-active')}
                            onClick={this.handleClick}
                          ><span>toggle men</span></button>
                        </div>
                      </ul>
                    </Col>
                  </Row>
                </Grid>
              </div>
            </div>
          )
        }
        }
      </Sticky>
    )
  }
}
