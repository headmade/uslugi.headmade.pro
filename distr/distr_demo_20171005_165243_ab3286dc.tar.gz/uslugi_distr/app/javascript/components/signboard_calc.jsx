// Run this example by adding <%= javascript_pack_tag 'hello_react' %> to the head of your layout file,
// like app/views/layouts/application.html.erb. All it does is render <div>Hello React</div> at the bottom
// of the page.

import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import Form from "react-jsonschema-form"
//import { GithubPicker } from 'react-color';
import DaDataSuggestions from "./inputs/dadata_suggestions";
import axios from 'axios'

axios.defaults.headers.post['X-CSRF-Token'] = jQuery('meta[name="csrf-token"]').attr('content');

class SignboardCalc extends React.Component {
  constructor(props) {
    super(props)
    this.state = {formData: {}}
    this.schema = {
      definitions: {
        organization: {
          type: "object",
          properties: {
            name: {type: "string", title: "Название"},
            inn: {type: "string", title: "ИНН"},
            kpp: {type: "string", title: "КПП"},
            ogrn: {type: "string", title: "ОГРН"}
          }
        }
      },
      title: "Паспорт типовой вывески",
      type: "object",
      required: ["address"],
      properties: {
        organization: {"$ref": "#/definitions/organization", title: "Организация"},
        address: {type: "string", title: "Адрес объекта", default: "Казань"},
        photo: {type: "string", format: "data-url", title: "Фотографии исходной ситуации"},
        frieze_geomerty: {type: "number", title: "Форма фриза",
          enum: [1, 2, 3, 4, 5],
          enumNames: ["Полукруг", "Только фронт", "Фронт + боковая часть слева", "Фронт + боковая часть справа", "Фронт + две боковые части"],
          default: 2
        },
        frieze_width:{type: "number", format: "updown", title: "Ширина фронтальной части фриза (мм.)", minimum: 1000},
        frieze_height:{type: "number", format: "updown", title: "Высота фронтальной части фриза (мм.)", minimum: 500},
        color: {type: "string", format: "color", title: "Цвет фриза"},
        type_of_business: {type: "number", title: "Вид деятельности",
          enum: [1, 2, 3, 4],
          enumNames: ["продукты", "булочная", "цветы", "сувениры" ],
        },
        need_logo: {type: "boolean", title: "Признак наличия логотипа"},
        done: {type: "boolean", title: "Подтверждаю правильность данных и даю согласие на их обработку", default: false}
      }
    }

    this.uiSchema = {
      "ui:order": [ "organization", "address", "*"],
      organization: {
        "ui:field": (props) => {
          return (
            <DaDataSuggestions title={props.schema.title} type= "PARTY" value={props.value} onChange={(suggestion) =>{
                props.onChange({
                  name: suggestion.unrestricted_value,
                  inn: suggestion.data.inn,
                  kpp: suggestion.data.kpp,
                  ogrn: suggestion.data.ogrn
                })
              }}/>
          )
        }
      },
      address: {
        "ui:widget": (props) => {
          return (
            <DaDataSuggestions isDebug={false} type= "ADDRESS" value={props.value} onChange={(suggestion) => props.onChange(suggestion.unrestricted_value)}  />
          )
        }
      }
    }

    this.onSubmit = this.onSubmit.bind(this)
    this.onChange = this.onChange.bind(this)
  }

  onChange(event){
    this.setState({"formData": event.formData})
  }

  onSubmit(event) {
    console.log(event, this)
    axios.post("/form", {"form": event.formData})
      .then((response)=>{
        console.log(response)
      })
      .catch((error)=>{
        console.log(error)
      })
  }

  render (){
    return (
      <div className="row">
        <div className="col-xs-8">
          <Form schema={this.schema} uiSchema={this.uiSchema} onChange={this.onChange} onSubmit={this.onSubmit} formData={this.state.formData} />
        </div>
        <div className="col-xs-4">
          { this.state.formData.photo &&
            <img style={{width: "100%"}} src={this.state.formData.photo} />
          }
          <pre>
            {JSON.stringify(this.state.formData, null, '  ')}
          </pre>
        </div>
      </div>
    )
  }
}
export default SignboardCalc
//document.addEventListener('DOMContentLoaded', () => {
  //ReactDOM.render(
    //<SignboardCalc />,
    //document.getElementById('signboard_calc')
  //)
//})
