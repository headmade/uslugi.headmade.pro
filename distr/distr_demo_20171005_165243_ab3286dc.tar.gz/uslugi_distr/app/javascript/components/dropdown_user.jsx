import React from 'react'
import { connect } from 'react-redux'
import { NavItem, Grid, Row, Col } from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap'
import { Link } from 'react-router-dom'

const mapStateToProps = (state) => {
    return {
        registries: state.registries,
        current_user: state.current_user
    }
}

@connect(mapStateToProps)

export default class DropdownUser extends React.Component{
    constructor(props) {
        super(props)
    }
    render (){

        return <Grid>
            <Row className="show-grid">
                <Col xs={4} md={4}>
                    <li className="main-nav__caption">
                        <span>Тестовые ссылки</span>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка</a>
                    </li>
                </Col>
                <Col xs={4} md={4}>
                    <li className="main-nav__caption">
                        <span>Тестовые ссылки</span>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка</a>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка</a>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка</a>
                    </li>
                </Col>
                <Col xs={4} md={4}>
                    <li className="main-nav__itemLink-user">
                        <a key={5.1} href="/session/logout">Настройки</a>
                    </li>
                    <li className="main-nav__itemLink-user">
                        <a key={5.2} href="/session/logout">Выход</a>
                    </li>
                </Col>
            </Row>
        </Grid>
    }
}