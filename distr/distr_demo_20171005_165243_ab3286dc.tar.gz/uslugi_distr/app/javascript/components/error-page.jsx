import React from 'react'
import { Grid, Row, Col} from 'react-bootstrap'


export default class ErrorPage extends React.Component{
  render (){
    return (

      <Grid>
        <Row>
          <Col xs={12}>
            <div className="wrapper-error">
              <div className="error__message">
                <h1 className="base-caption">Что-то пошло не так</h1>
                <p><a className="myBtn transparent-btn" href="/session/new">Перезагрузить страницу</a></p>
              </div>
              <div className="error__img">
                <img src={require("../images/face.gif")} alt="Ошибка" />
              </div>
            </div>
          </Col>
        </Row>
      </Grid>
    )
  }
}
