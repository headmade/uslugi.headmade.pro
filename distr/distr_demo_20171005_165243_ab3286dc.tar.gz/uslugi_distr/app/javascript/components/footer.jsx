import React from 'react'
import { connect } from 'react-redux'
import { Grid, Row, Col, Clearfix, ListGroup, ListGroupItem} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap'
import { Link } from 'react-router-dom'
import LogoFooterImg from '~/images/Zilant_footer.svg'

export class Footer extends React.Component{
  render (){

      return <footer className="footer">
        <Grid>
          <Row className="show-grid">
            <Col xs={6} md={2}>
              <ListGroup className="footer__list">
                <ListGroupItem className="list__caption">О казани</ListGroupItem>
                <ListGroupItem className="list__item" href="https://ru.wikipedia.org/wiki/%CA%E0%E7%E0%ED%FC">О городе</ListGroupItem>
                <ListGroupItem className="list__item" href="http://old.kzn.ru/static_page/genplan">Генплан</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.fmap.ru/kazan/">Маршрутная сеть</ListGroupItem>
                <ListGroupItem className="list__item" href="https://parkingkzn.ru/ru/">Казанский паркинг</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/parking">Где в Казани оставить машину</ListGroupItem>
              </ListGroup>
            </Col>
            <Col xs={6} md={2}>
              <ListGroup className="footer__list">
                <ListGroupItem className="list__caption">Услуги</ListGroupItem>
                <ListGroupItem className="list__item" href="https://uslugi.tatarstan.ru/">Портал услуг РТ</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page15621.htm">Реестр муниципальных услуг</ListGroupItem>
                <ListGroupItem className="list__item" href="http://minjust.tatarstan.ru/rus/info.php?id=526749">Бесплатная юридическая помощь</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/node/41623">Единое окно</ListGroupItem>
                <ListGroupItem className="list__item" href="http://erckzn.ru/">Единый расчетный центр Казани</ListGroupItem>
              </ListGroup>
            </Col>
            <Col xs={6} md={2}>
              <ListGroup className="footer__list">
                <ListGroupItem className="list__caption">Пресс-центр</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/news/%D0%BF%D1%80%D0%B5%D1%81%D1%81-%D1%80%D0%B5%D0%BB%D0%B8%D0%B7">Пресс-релизы</ListGroupItem>
                <ListGroupItem className="list__item" href="http://metshin.ru/galleries">Фото</ListGroupItem>
                <ListGroupItem className="list__item" href="http://metshin.ru/videos">Видео</ListGroupItem>
                <ListGroupItem className="list__item" href="http://metshin.ru/blogs">От первого лица</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page10277.htm">Доклад с "ДП"</ListGroupItem>
              </ListGroup>
            </Col>
            <Col xs={6} md={2}>
              <ListGroup className="footer__list">
                <ListGroupItem className="list__caption">Документы</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page182.htm">Устав Казани</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page8106.htm">Сборник документов</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/node/47542">Публичные слушания</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page18091.htm">Антикоррупционная экспертиза</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page22415.htm">Оценка регвоздействия</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page15535.htm">Найти документ</ListGroupItem>
              </ListGroup>
            </Col>
            <Col xs={6} md={2}>
              <ListGroup className="footer__list">
                <ListGroupItem className="list__caption">Городская власть</ListGroupItem>
                <ListGroupItem className="list__item" href="http://metshin.ru/">Мэр Казани</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/gorduma">Городская дума</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/ispolkom/structure">исполнительный коммитет</ListGroupItem>
                <ListGroupItem className="list__item" href="http://ksp.kzn.ru/">Контрольно счетная плата</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/izbirkom">Избирательная коммисия</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page14427.htm">Администрация Казани</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/node/44524">Межведомственные коммисии</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/whatismayor">Что такое мэрия города Казани?</ListGroupItem>
              </ListGroup>
            </Col>
            <Col xs={6} md={2}>
              <ListGroup className="footer__list">
                <ListGroupItem className="list__caption">Обратная связь</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/irecept">Интернет-приемная</ListGroupItem>
                <ListGroupItem className="list__item" href="http://old.kzn.ru/upload/documents/27263.doc">Личный прием мэра казани</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/node/47538">Прием граждан</ListGroupItem>
                <ListGroupItem className="list__item" href="http://www.kzn.ru/old/page3107.htm">Вакансии</ListGroupItem>
                <ListGroupItem className="list__item" href="http://old.kzn.ru/phone">Справочник контактов</ListGroupItem>
                <ListGroupItem className="list__item" href="http://old.kzn.ru/page22475.htm">Информация об обращениях</ListGroupItem>
              </ListGroup>
            </Col>
          </Row>
          <hr className="footer-hr" />
          <Row className="show-grid bottom-row">
            <Col xs={12} md={5}>
              <Link to="/" className="footer__logo">
                <div className="footer__logo-img">
                  <img src={LogoFooterImg}/>
                </div>
                <span className="footer__logo-text">2007-2017<br/>USLUGI.KZN</span>
              </Link>
            </Col>
            <Col xs={12} md={4}>
              <span className="footer__phone">Телефон: 299-16-31</span>
            </Col>
            <Col xs={12} md={3}>
              <span className="footer__address">Почтовый адрес: 420014, г.Казань, ул.Кремлевская, 1</span>
            </Col>
          </Row>
          <hr className="footer-hr" />
          <Row className="show-grid bottom-row">
            <Col xs={12} md={5}>
              <div className="footer__logo-gosuslugi-wrapper">
                <div className="footer__logo-gosuslugi-icon"> </div>
                <p className="footer__logo-gosuslugi-text">Разработано в соответствии с <a href="http://guides.gosuslugi.ru/">правилами дизайна Единого портала Госуслуг</a></p>
              </div>
            </Col>
          </Row>
        </Grid>
      </footer>

  }
}

export default Footer
