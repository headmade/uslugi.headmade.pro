import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import {Modal, OverlayTrigger, Popover} from 'react-bootstrap'
import ShowForm from '~/form/show_form'
import defaultSchema from '~/form/default_schema'
import prepareSchema from '~/form/prepare_schema'
import connect from 'react-redux-fetch'


const mapStateToProps = ({ registries }) => ({ registries })

@connect([{
  resource: 'descriptions',
  request: (fias_id) =>({
    url: `/api/servant/registry_items?fias_id=${fias_id}`,
    })
}], mapStateToProps)

export default class Address extends React.Component {
  static propTypes = {
    dispatchDescriptionsGet: PropTypes.func.isRequired,
    descriptionsFetch: PropTypes.object
  }
  constructor(props){
    super(props)
    this.state = {showModal:[]}
  }

  componentWillMount() {
    const fias_id = this.props.address && this.props.address.fias_id
    this.props.dispatchDescriptionsGet(fias_id)
  }

  getSchema(registry_id){
   const registry = this.props.registries.find((elm)=>{return elm.id == registry_id})
   return prepareSchema(registry && registry.data && registry.data.schema || defaultSchema)
  }

  close(i){
    return (event)=>{
      var sm = this.state.showModal
      sm[i] = false
      this.setState({showModal: sm})
    }
  }

  open(i){
    return (event)=>{
      var sm = this.state.showModal
      sm[i] = true
      this.setState({showModal: sm})
    }
  }

  render(){
    const { address } = this.props
    return <div>
      { address &&
        <div className="address">
          <h4>Адрес объекта</h4>
          <div className="row">
            <div className="col-md-4">{address.value}</div>
            <div className="col-md-8">{this.props.descriptionsFetch.fulfilled && this.props.descriptionsFetch.value.data.map((description, i)=>
              <div key={i}>
                <span onClick={this.open(i)} className={"label label-info"} style={{display: "inline-block"}}>{description.registry_name}-{description.data.title}</span>
                <Modal show={this.state.showModal[i]} onHide={this.close(i)}>
                  <Modal.Header closeButton>
                    <Modal.Title>Реестр: "{description.registry_name}"</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <ShowForm formData={description.data} schema={this.getSchema(description.registry_id)} short/>
                  </Modal.Body>
                </Modal>
              </div>
              )}
            </div>
         </div>
       </div>
      }
      </div>
  }
}
