import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import axios from 'axios'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import dateFormatter from '../formatters/date'

export class OrganizationDependencies extends React.Component {
  constructor(props){
    super(props)
    this.state = {usluga_requests: null, isLoading: true}
    axios.get("/organization_recipients/"+props.id+"/usluga_requests")
      .then((response)=>{
        this.setState({usluga_requests: response.data.data.filter((value)=>{
          return value.id != props.usluga_request_id
        }), isLoading: false})
      })
      .catch((error)=>{
        console.log(error)
      })
    this.passportFormatter = this.passportFormatter.bind(this)
  }

  passportFormatter(cell, row){
    const passport = this.props.passports.find((elm)=>{return elm.id == cell})
    return passport.name
  }

  linkFormatter(cell, row){
      return <Link to={"/usluga_requests/"+cell}>
        <button type="button" className="btn btn-xs btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true"></span> Посмотреть
        </button>
      </Link>
  }
  render(){
    return <div>{ this.state.isLoading ? (<div className="loader">Loading...</div>):(
      <BootstrapTable data={ this.state.usluga_requests } options={ { noDataText: 'Нет других услуг оказанных данной организации' } }>
        <TableHeaderColumn dataField='id' dataSort isKey hidden >ID</TableHeaderColumn>
        <TableHeaderColumn dataField='passport_id' dataFormat={this.passportFormatter} >Услуга</TableHeaderColumn>
        <TableHeaderColumn dataField='created_at' width="100" dataFormat={dateFormatter} dataSort >Дата посещения</TableHeaderColumn>
        <TableHeaderColumn dataField='id' width="123" dataFormat={this.linkFormatter}>Действия</TableHeaderColumn>
      </BootstrapTable>
    )
    }</div>
  }
}

const mapStateToProps = (state, ownProps) => {
  return {passports: state.servant_passports}
}

const mapDispatchToProps = (dispatch) => {
  return {}
}
export default connect(mapStateToProps, mapDispatchToProps)(OrganizationDependencies)
