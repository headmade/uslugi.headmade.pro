import React from 'react'
import {Panel} from 'react-bootstrap'
import dateFormatter from '~/components/formatters/date'

export default function Servant(props){
  const {object, title} = props
  const {name, patronymic_name, surname} = object
  const fio = [name, patronymic_name, surname].join(' ')
  return <span>{title&&`${title}: `}{fio}</span>
}
