import React from 'react'
import {Panel} from 'react-bootstrap'
import dateFormatter from '~/components/formatters/date'

export default Sign
export class Sign extends React.Component {
  render (){
    const {object} = this.props
    const { sign_certificate } = object
    if (!sign_certificate){
      return <div />
    }
    return <div>
      <h4>Сведения о сертификате ЭП</h4>
      <p >Кому выдан: {sign_certificate.data.subject.CN}</p>
      <p style={{wordBreak: "break-all"}}>Серийный №: {sign_certificate.serial}</p>
      <p>Срок действия: {dateFormatter(sign_certificate.data.not_before)}-{dateFormatter(sign_certificate.data.not_after)}</p>
    </div>
  }
}
