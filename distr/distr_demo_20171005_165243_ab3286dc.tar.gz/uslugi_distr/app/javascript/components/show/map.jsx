import React from 'react'
import 'leaflet/dist/leaflet.css'
import 'leaflet/dist/images/marker-shadow.png'
import 'leaflet/dist/images/marker-icon.png'
import 'leaflet/dist/images/marker-icon-2x.png'
import { Map, CircleMarker, Popup, TileLayer, GeoJSON} from 'react-leaflet'

export default class AdderesWithMap extends React.Component {
  render(){
    const {object}= this.props
    const {address, geoJSON} = object
    const {lat, lon} = address.geo_coordinates
    const center = [parseFloat(lat), parseFloat(lon)]
    if (!object || !lat){
      return <br />
    }

    return (
      <div>
      <div className='form-group field field-string'>
        <label>Адрес</label>
        <p>{address.value}</p>
      </div>
      <Map center={center} onClick={this._onMounted} zoom={18} maxZoom={18} style={{width: '500px', height: '300px', zIndex: 1}}>
        <TileLayer
          url='http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
          url='http://tiles.maps.sputnik.ru/{z}/{x}/{y}.png'
          attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
        />
          <GeoJSON data={geoJSON} ></GeoJSON>
          <CircleMarker center={center} radius={10}>
            <Popup>
              <span>{address.value}</span>
            </Popup>
          </CircleMarker>
      </Map>
    </div>
    )
  }
}
