import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

export class Passport extends React.Component {
  render (){
    return <h3>{this.props.passport && this.props.passport.name}</h3>
  }
}

const mapStateToProps = (state, ownProps) => {
  return {passport: state.servant_passports.find((elm)=>{return elm.id == ownProps.id})}
}

const mapDispatchToProps = (dispatch) => {
  return {}
}
export default connect(mapStateToProps, mapDispatchToProps)(Passport)
