import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import axios from 'axios'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import Moment from 'moment'
import Loader from '~/components/loader'

export class AgentDependencies extends React.Component {
  constructor(props){
    super(props)
    this.state = {usluga_requests: null, isLoading: true}
    axios.get("/agents/"+props.id+"/usluga_requests")
      .then((response)=>{
        this.setState({usluga_requests: response.data.data.filter((value)=>{
          return value.id != props.usluga_request_id
        }), isLoading: false})
      })
      .catch((error)=>{
        console.log(error)
      })
    this.passportFormatter = this.passportFormatter.bind(this)
  }

  passportFormatter(cell, row){
    const passport = this.props.passports.find((elm)=>{return elm.id == cell})
    return passport && passport.name
  }

  linkFormatter(cell, row){
      return <Link to={"/usluga_requests/"+cell}>
        <button type="button" className="btn btn-xs btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true"></span> Посмотреть
        </button>
      </Link>
  }
  dateFormatter(cell, row){
    return Moment(cell).format('DD-MM-YYYY')
  }
  render(){
    return (
      <Loader isLoading={this.state.isLoading}>
        <BootstrapTable data={ this.state.usluga_requests } options={ { noDataText: 'Нет других услуг оказанных данной организации' } }>
          <TableHeaderColumn dataField='id' dataSort isKey hidden >ID</TableHeaderColumn>
          <TableHeaderColumn dataField='passport_id' dataFormat={this.passportFormatter} >Услуга</TableHeaderColumn>
          <TableHeaderColumn dataField='created_at' width="100" dataFormat={this.dateFormatter} dataSort >Дата посещения</TableHeaderColumn>
          <TableHeaderColumn dataField='id' width="123" dataFormat={this.linkFormatter}>Действия</TableHeaderColumn>
        </BootstrapTable>
      </Loader>
    )
  }
}

const mapStateToProps = (state, ownProps) => {
  return {passports: state.servant_passports}
}

const mapDispatchToProps = (dispatch) => {
  return {}
}
export default connect(mapStateToProps, mapDispatchToProps)(AgentDependencies)
