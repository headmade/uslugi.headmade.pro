import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import {Panel} from 'react-bootstrap'

function Row (props){
  return <div className="row">
      <div className="col-md-4">{props.name}</div>
      <div className="col-md-8">{props.value}</div>
    </div>
}

export default class Organization extends React.Component {
  constructor(props){
    super(props)
    const token = "abc920cb25187ef8cf7964359514da7fd27aea7c"
    this.state = {organization:null, isLoading:true}
    var instance = axios.create({
      baseURL: 'https://suggestions.dadata.ru/suggestions/api/4_1/',
      timeout: 1500,
      headers: {'Authorization': 'Token '+token}
    });
    instance.post("/rs/suggest/party", {"query": props.inn, count: 1})
      .then((response)=>{
        var org = response.data.suggestions[0]
        this.setState({organization: org.data, isLoading: false})
      })
      .catch((error)=>{
        this.setState({isLoading: false})
        console.log(error)
      })
  }

  render(){
    const { isLoading, organization }= this.state
    return <div>
      { isLoading ? (<div className="loader">Loading...</div>):(
        organization &&
        <Panel bsStyle="info" className="organization" header={this.props.header || ("Заявитель: " + organization.inn)}>
          <Row name="Название" value={organization.name.full_with_opf} />
          <Row name="ИНН" value={organization.inn} />
          { organization.management && <Row name={organization.management.post} value={organization.management.name} />}
          <Row name="Адрес" value={organization.address.value} />
          <Row name="Статус" value={organization.state.status == "ACTIVE" ? "Активная":"Неактивная"} />
        </Panel>
      )
      }
      </div>
  }
}

Organization.propTypes = {
  inn: PropTypes.string,
}
