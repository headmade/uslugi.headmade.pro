import Base from './base'
import Sign from './sign'
import Reject from './reject'
import Complete from './complete'
import {mapQueryEventToComponent} from './queries'

export const mapEventToComponent = {
  base:{
    base: Base,
    sign: Sign,
    reject: Reject,
    complete: Complete,
    //assign: Complete,
  },
  query: mapQueryEventToComponent
}

export function eventComponent(resource, id){
  const eventMap = mapEventToComponent[resource] || mapEventToComponent['base']
  return eventMap[id] || eventMap['base']
}
