import React from 'react'

const Complete = (props)=>{
  const {isDebug, item} = props
  return <div>
    { item.request_params.data.response_text&&
      <p>Информация для заявителя: {item.request_params.data.response_text}</p>
    }
  </div>
}
export default Complete
