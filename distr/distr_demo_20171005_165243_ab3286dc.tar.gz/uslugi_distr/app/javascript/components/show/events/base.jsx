import React from 'react'

const Base = (props)=>{
  const {isDebug, item} = props
  return null
}
export default Base
