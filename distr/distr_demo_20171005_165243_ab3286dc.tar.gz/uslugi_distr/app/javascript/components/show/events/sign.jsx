import React from 'react'
import { Sign as SignComponent } from '~/components/show/sign'

const Sign = (props)=>{
  const {isDebug, item, object} = props
  return <div>
    <SignComponent object={object} />
    <p><a className='btn btn-info' href={`/api/servant/uslugas/${object.id}.pdf`} target='_blank'>Скачать подписанный документ</a></p>
  </div>
}
export default Sign
