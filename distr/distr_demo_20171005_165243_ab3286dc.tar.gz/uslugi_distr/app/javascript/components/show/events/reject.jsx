import React from 'react'

const Reject = (props)=>{
  const {isDebug, item, object} = props
  return <div>
    <h5>Причина отказа</h5>
    <ul>
      {object.reject_data.reject_reasons.map((reason, index)=>{
        return <li key={index}>{reason}</li>
      })}
    </ul>
    { item.request_params.data.response_text&&
      <p>Информация для заявителя: {item.request_params.data.response_text}</p>
    }
  </div>
}
export default Reject
