import Base from './base'

const Blank = (props)=>{
  return null
}
export const mapQueryEventToComponent = {
  base: Base,
  accept: Blank
}
