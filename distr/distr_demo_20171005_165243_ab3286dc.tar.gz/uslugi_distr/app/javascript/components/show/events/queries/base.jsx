import React from 'react'
import { connect } from 'react-redux'
import {Label, Row, Col} from 'react-bootstrap'
import ShowForm from '~/form/show_form'
import prepareSchema from '~/form/prepare_schema'


const mapStateToProps = (state, ownProps) => {
  return {query_passport: state.query_passports.find((elm)=>{return elm.id == ownProps.object.query_passport_id})}
}

@connect(mapStateToProps)

class Base extends React.Component {
  constructor(props){
    super(props)
    this.state ={open: false}
    this.toggleOpen = this.toggleOpen.bind(this)
  }

  toggleOpen(){
    this.setState({open: !this.state.open})
  }

  getSchema(){
   const passport = this.props.query_passport
   const event = this.props.item.event.key
   return prepareSchema(dig(passport, 'data', 'query', 'events', event, 'schema'))
  }

  render(){
    const {isDebug, item, query_passport} = this.props
    const schema = this.getSchema()
    const query_data = item.request_params.data

    return <div>
        <h4>Полная информация(<a onClick={this.toggleOpen}>{this.state.open?'свернуть':'развернуть'}</a>) </h4>
        {this.state.open && <ShowForm formData={query_data} schema={schema} />}
    </div>
  }
}
export default Base
