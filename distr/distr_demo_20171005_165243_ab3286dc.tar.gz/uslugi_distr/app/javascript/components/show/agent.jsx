import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import {Panel} from 'react-bootstrap'

function Row (props){
  return <div className="row">
      <div className="col-md-4">{props.name}</div>
      <div className="col-md-8">{props.value}</div>
    </div>
}

export default class Agent extends React.Component {
  render(){
    const agent = this.props.agent
    return <div>
      { agent && agent.fio &&
        <Panel className="agent" bsStyle="info" className="organization" header={this.props.header || "Представитель"}>
          <Row name="ФИО" value={[agent.fio.name, agent.fio.patronymic_name, agent.fio.surname].join(' ')} />
          <Row name="Номер паспорта" value={agent.passport_number} />
          <Row name="Телефон" value={agent.mobile} />
          <Row name="Email" value={agent.email} />
        </Panel>
      }
      </div>
  }
}
