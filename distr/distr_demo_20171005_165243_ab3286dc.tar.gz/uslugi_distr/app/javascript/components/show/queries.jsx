import React from 'react'
import { connect } from 'react-redux'

import {queryComponent} from './queries/index'

const mapStateToProps = ({isDebug})=>({isDebug})

@connect(mapStateToProps)
export default class Queries extends React.Component {
  render(){
    const {objects, isDebug} = this.props
    if (!objects){
      return null
    }
    return <div>
      <h4>Запросы</h4>
      {objects.map((item, index)=>{
        const QueryComponent = queryComponent(item.query_passport_id)
        return <QueryComponent key={index} {...{isDebug, item}} />
      })
      }
    </div>
  }
}
