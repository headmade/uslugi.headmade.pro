import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import Agent from './agent'

export class LastUslugaRequest extends React.Component {
  render (){
    if(this.props.usluga_request){
      return <Agent agent={this.props.usluga_request.data.agent} header="Предыдущий посетитель"/>
    }
    return <br/>
  }
}

const mapStateToProps = (state) => {
  return {usluga_request: state.last_usluga_request}
}

const mapDispatchToProps = (dispatch) => {
  return {}
}
export default connect(mapStateToProps, mapDispatchToProps)(LastUslugaRequest)
