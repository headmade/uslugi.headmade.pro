import React from 'react'
import { dateTimeFormatter } from '~/components/formatters/date'
import {Panel} from 'react-bootstrap'
import { connect } from 'react-redux'
import Servant from '~/components/show/servant'
import Queries from '~/components/show/queries'
import Inspector from 'react-inspector'
import { eventComponent } from '~/components/show/events'

const mapStateToProps = ({isDebug})=>({isDebug})

@connect(mapStateToProps)
export default class History extends React.Component {
  render(){
    const {isDebug, object, resource} = this.props
    const histories = object.events
    return <div>
      { histories.map((item)=>{
        const EventComponent = eventComponent(resource, item.event.key)
        return <Panel key={item.id} bsStyle={item.state.style} header={`Действие: ${item.event.name} (${dateTimeFormatter(item.created_at)}) Статус: ${item.state.name}`}>
          { isDebug && <Inspector data={item} /> }
          {item.servant &&
              <Servant title='Исполнитель' object={item.servant}/>
          }
          <EventComponent {...{isDebug, item, object}} />
          {item.request_params.data.comments &&
            <p>Коментарий: {item.request_params.data.comments}</p>
          }
          <Queries objects={item.queries} />
        </Panel>
      })}

    </div>
  }
}
