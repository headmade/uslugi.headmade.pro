import Base from './base'

export const mapQuerieToComponent = {
  base: Base,
  //sign: Sign,
  //reject: Reject,
  //complete: Complete,
  //assign: Complete,
}

export function queryComponent(id){
  return mapQuerieToComponent[id] || mapQuerieToComponent['base']
}
