import React from 'react'
import {Label, Row, Col} from 'react-bootstrap'
import Inspector from 'react-inspector'
import { connect } from 'react-redux'
import ShowForm from '~/form/show_form'
import prepareSchema from '~/form/prepare_schema'

const mapStateToProps = (state, ownProps) => {
  return {query_passport: state.query_passports.find((elm)=>{return elm.id == ownProps.item.query_passport_id})}
}

@connect(mapStateToProps)
class Base extends React.Component {

  constructor(props){
    super(props)
    this.state ={open: false}
    this.toggleOpen = this.toggleOpen.bind(this)
  }

  toggleOpen(){
    this.setState({open: !this.state.open})
  }

  getSchema(){
   const passport = this.props.query_passport
   return prepareSchema(passport && passport.data && passport.data.query && passport.data.query.events['complete'].schema)
  }

  render(){
    const {isDebug, item, query_passport} = this.props
    const schema = this.getSchema()
    const query_data = item.result_data

    return <Row>
      <Col md={1}>{item.id}</Col>
      <Col md={8}>
        {item.title}
        {this.state.open && <ShowForm formData={query_data} schema={schema} className="form-xsmall"/>}
        { isDebug && <Inspector data={item} /> }
      </Col>
      <Col md={1}>
        <a onClick={this.toggleOpen}>{this.state.open?'кратко':'подробно'}</a>
      </Col>
      <Col md={1}>
        <Label bsStyle={item.state.style}>
          {item.state.name}
        </Label>
      </Col>
    </Row>
  }
}
export default Base
