const columnsConfig = {
  1: [{
              Header: 'Адрес',
              id: 'address',
              accessor: d => d.data.address.value
            }, {
              Header: 'Наименование',
              id: 'title',
              accessor: d => d.data.title
            }],
  2: [{
              Header: 'Улица',
              id: 'address',
              accessor: d => d.data.address.value
            }],
  3: [{
              Header: 'Адрес',
              id: 'address',
              accessor: d => d.data.address.value
            }, {
              Header: '№ архива',
              id: 'archive_number',
              accessor: d => d.data.archive_number
            }, {
              Header: 'Описание',
              id: 'description',
              accessor: d => d.data.description
            }],
  4: [{
              Header: 'Адрес',
              id: 'address',
              accessor: d => d.data.address.value
            }, {
              Header: 'Тип объекта',
              id: 'object_type',
              accessor: d => d.data.object_type
            }, {
              Header: 'Целевое назначение',
              id: 'target_use',
              accessor: d => d.data.target_use
            }, {
              Header: 'Тип объекта',
              id: 'object_type',
              accessor: d => d.data.object_type
            }, {
              Header: 'Кадастровый номер',
              id: 'cadastre_number',
              accessor: d => d.data.cadastre_number
            }, {
              Header: 'Площадь',
              id: 'total_area',
              accessor: d => d.data.total_area
            }, {
              Header: 'Период аренды',
              id: 'lease_period',
              accessor: d => d.data.lease_period
            }, {
              Header: 'Ссылка',
              id: 'object_url',
              accessor: d => d.data.object_url
            }, {
              Header: 'Цель аукциона',
              id: 'auction_target',
              accessor: d => d.data.auction_target
            }, {
              Header: 'Начало аукциона',
              id: 'auction_begin',
              accessor: d => d.data.auction_begin
            }, {
              Header: 'Завершение аукциона',
              id: 'auction_end',
              accessor: d => d.data.auction_end
            }],
  5: [{
              Header: 'Адрес',
              id: 'address',
              accessor: d => d.data.address.value
            }, {
              Header: 'Юр.лицо',
              id: 'organization',
              accessor: d => d.data.organization.name
            }, {
              Header: 'Номер паспорта',
              id: 'passport_numbers',
              accessor: d => d.data.passport_numbers
            }],
  6: [{
              Header: 'Юр.лицо',
              id: 'organization',
              accessor: d => d.data.organization.name
            }, {
              Header: 'Комментарий',
              id: 'comment',
              accessor: d => d.data.comment
            }],
}
const getColumnsConfig = (id, column)=>{
  var c = columnsConfig[id] || columnsConfig[1]
  return c.concat(column)
}

export default getColumnsConfig
