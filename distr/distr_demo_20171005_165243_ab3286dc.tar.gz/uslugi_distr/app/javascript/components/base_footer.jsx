import React from 'react'
import { connect } from 'react-redux'
import { Grid, Row, Col, Clearfix, ListGroup, ListGroupItem} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap'
import { Link } from 'react-router-dom'
import LogoFooterImg from '~/images/Zilant_footer.svg'

export default class BaseFooter extends React.Component{
  render (){

      return <footer className="footer">
        <Grid>
          <Row className="show-grid bottom-row">
            <Col xs={12}>
              <div className="session-new-footer footer__logo-gosuslugi-wrapper">
                <div className="footer__logo-gosuslugi-icon"> </div>
                <p className="footer__logo-gosuslugi-text">Разработано в соответствии с <a href="http://guides.gosuslugi.ru/">правилами дизайна Единого портала Госуслуг</a></p>
                <div className="session-new-footer-phone">
                  <span className="banner-logo">ИС <span>Услуги</span></span>
                  <span className="session-new-footer-phone-item">2015-2017</span>
                </div>
                <div className="footer__logo-gosuslugi-icon footer__logo-gosuslugi-icon--right"></div>
              </div>
            </Col>
          </Row>
        </Grid>
      </footer>

  }
}
