import Moment from 'moment'

export default function dateFormatter(cell, row){
  return Moment(cell).format('DD.MM.YYYY')
}
export function dateTimeFormatter(cell){
  return Moment(cell).format('DD.MM.YYYY HH:mm')
}

export function dateToFormatter(cell){
  if (Moment().isBefore(cell)){
    return Moment().to(cell)
  }
  return dateFormatter(cell)
}
