export default function durationFormatter(cell, row){
  const d = new Date(cell/1000000);
  var { minutes, seconds } = {
    minutes: d.getMinutes(),
    seconds: d.getSeconds()
  }
  if (seconds < 10) {seconds = "0"+seconds}
  return minutes + ":" + seconds
}
