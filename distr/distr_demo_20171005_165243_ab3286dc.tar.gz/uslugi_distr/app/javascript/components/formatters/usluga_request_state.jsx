import React from 'react'
import {Label} from 'react-bootstrap'

export default function uslugaRequestStateFormatter(cell, row){
  return(
    <Label bsStyle={cell.style}>
      {cell.name}
    </Label>
  )
}
