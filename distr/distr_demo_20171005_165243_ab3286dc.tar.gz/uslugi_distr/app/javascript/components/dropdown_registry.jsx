import React from 'react'
import { connect } from 'react-redux'
import { NavItem, Grid, Row, Col } from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap'
import { Link } from 'react-router-dom'

const mapStateToProps = (state) => {
    return {
        registries: state.registries,
        current_user: state.current_user
    }
}

@connect(mapStateToProps)

export default class DropdownRegistry extends React.Component{
    constructor(props) {
        super(props)
    }
    render (){

        return <Grid>
            <Row className="show-grid">
                <Col xs={4} md={4}>
                    { this.props.registries.map((registry)=>{
                            return (
                                <LinkContainer className="main-nav__itemLink" key={registry.id} to={"/registries/"+registry.id}>
                                    <NavItem key={"4."+registry.id} >{registry.name}</NavItem>
                                </LinkContainer>
                            )
                        })
                    }
                    <LinkContainer  className="main-nav__itemLink" to="/agents">
                        <NavItem key={4.4}>Заявители</NavItem>
                    </LinkContainer >
                </Col>
                <Col xs={4} md={4}>
                    <li className="main-nav__caption">
                        <span>Тестовые ссылки</span>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка</a>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка ооооооооо           ооооооочень длинннная</a>
                    </li>
                </Col>
                <Col xs={4} md={4}>
                    <li className="main-nav__caption">
                        <span>Тестовые ссылки</span>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка</a>
                    </li>
                    <li className="main-nav__item">
                        <a href="/session/logout">Ссылка</a>
                    </li>
                </Col>
            </Row>
        </Grid>
    }
}
