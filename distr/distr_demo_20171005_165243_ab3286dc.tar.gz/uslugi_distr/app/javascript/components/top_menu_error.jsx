import React from 'react'
import { Grid, Row, Col } from 'react-bootstrap'


import Base from '~/components/base'

export default class TopMenuError extends Base {
  constructor(props, context) {
    super(props, context)
    this.state = {
      isToggleOn: true
    }
    this.handleClick = this.handleClick.bind(this)
  }

  handleClick() {
    this.setState(prevState => ({
      isToggleOn: !prevState.isToggleOn
    }))
  }

  render () {
    const linkPath = '/servant'
    return (
      <Grid>
        <Row>
          <Col xs={12}>
            <ul className="nav-list">
              <li className="nav-list__item nav-list__item-logo">
                <a href={linkPath}>
                  <span className="banner-logo">ИС <span>Услуги</span></span>
                </a>
              </li>
              <ul className={'nav-list__items ' + (this.state.isToggleOn ? '' : 'nav-list__items_active')}>
                <li className="nav-list__item">
                  <a href={linkPath + '/consultations'}>Консультации</a>
                </li>
                <li className="nav-list__item">
                  <a href={linkPath + '/user_requests'}>Заявления</a>
                </li>
                <li className="nav-list__item">
                  <a href={linkPath + '/uslugas'}>Услуги</a>
                </li>
                <li className="nav-list__item">
                  <a href={linkPath + '/queries'}>Запросы</a>
                </li>
                <li className="nav-list__item">
                  <a href={linkPath + '/statistics'}>Статистика</a>
                </li>
                {/*<li className="nav-list__item nav-index__dropdown-item">*/}
                  {/*<a className="nav-index-user__caption">Реестры</a>*/}
                  {/*<ul className="nav-index-user__dropdown">*/}
                    {/*{this.props.registries.map((registry) => {*/}
                      {/*return (*/}
                        {/*<li className="nav-index-user__dropdown-item">*/}
                          {/*<a href={linkPath + "/registries/" + registry.id} key={registry.id}>{registry.name}</a>*/}
                        {/*</li>*/}
                      {/*)*/}
                    {/*})*/}
                    {/*}*/}
                    {/*<li className="nav-index-user__dropdown-item"><a href={linkPath + "/agents"}>Заявители</a></li>*/}
                  {/*</ul>*/}
                {/*</li>*/}
                {/*{current_user.current_servant &&*/}
                {/*<li className="nav-list__item nav-index-user"><a*/}
                  {/*className="nav-index-user__caption">{current_user.current_servant.name + " " + current_user.current_servant.surname}</a>*/}
                  {/*<ul className="nav-index-user__dropdown">*/}
                    {/*<li className="nav-index-user__dropdown-item"><a href="/session/logout">Выход</a></li>*/}
                  {/*</ul>*/}
                {/*</li>*/}
                {/*}*/}
              </ul>
              <div className="hamburger-wrapper">
                <button
                  className={'c-hamburger c-hamburger--htx ' + (this.state.isToggleOn ? '' : 'is-active')}
                  onClick={this.handleClick}><span>toggle men</span></button>
              </div>
            </ul>
          </Col>
        </Row>
      </Grid>
    )
  }
}
