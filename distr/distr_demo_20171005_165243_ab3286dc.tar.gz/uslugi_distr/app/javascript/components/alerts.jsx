import React from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Alert } from 'react-bootstrap';
import Inspector from 'react-inspector'

import {removeNotification} from '~/actions/notification'

const mapStateToProps = ({isDebug, notifications})=>({isDebug, notifications})

const mapDispatchToProps = (dispatch) => {
  return { removeNotification: (id)=>{
    dispatch(removeNotification(id))
  }
  }
}

@connect(mapStateToProps, mapDispatchToProps)

export default class Alerts extends React.Component{

  handleAlertDismiss(id){
    return (e)=>{
      this.props.removeNotification(id)
      this.forceUpdate()
    }
  }

  render(){
    const { notifications, isDebug} = this.props
    return <div>
      { this.props.notifications.map((item, index)=>{
          return <Alert key={index} bsStyle="warning" onDismiss={this.handleAlertDismiss(index)}>
            <strong>{item.title}</strong> {item.text}
            { isDebug && <Inspector data={item} /> }
          </Alert>
        })
      }
  </div>
  }

}
