import React from 'react'
import { connect } from 'react-redux'
import ServantList from '../routing/passports/servant_list'
import Index from '../routing/usluga_requests/list'
import LastUslugaRequest from './show/last_usluga_request'
import {Grid, Row, Col} from 'react-bootstrap'

@connect()
export default class ServantDashbordComponent extends React.Component{
  render() {
    return <Grid>
      <Row><Col xs={12}><LastUslugaRequest/></Col></Row>
      <Row><Col xs={12}><ServantList/></Col></Row>
      <Row><Col xs={12}><Index filter /></Col></Row>
  </Grid>
  }
}
