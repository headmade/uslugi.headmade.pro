import React from 'react'
import { connect } from 'react-redux'
import { Navbar, Nav, NavDropdown, MenuItem, NavItem, Grid, Row, Col, Clearfix } from 'react-bootstrap'
import {LinkContainer} from 'react-router-bootstrap'
import { Link, NavLink } from 'react-router-dom'
import {Sticky} from 'react-sticky'
import { withRouter } from 'react-router-dom'

import LogoImg from '~/images/Zilant.svg'
import DropdownRegistry from '~/components/dropdown_registry'
import DropdownUser from '~/components/dropdown_user'
import Base from '~/components/base'

const mapStateToProps = (state) => {
  return {
    registries: state.registries,
    current_user: state.current_user
  }
}

@connect(mapStateToProps)

class TopMenu extends Base {
  constructor(props, context) {
    super(props, context)
    this.state = {
      isToggleOn: true
    }

    this.handleClick = this.handleClick.bind(this)
  }


  handleClick() {
    this.setState(prevState => ({
      isToggleOn: !prevState.isToggleOn
    }))
  }
  preventClick(e) {
    e.preventDefault()
  }

  render () {
    const {current_user} = this.props
    const {title} = this.config
    return (
      <Sticky>
        {({style}) => {
          return (
            <div className="MySticky" style={{...style, height: 80}}>
              <div className="nav-wrapper">
                <Grid>
                  <Row>
                    <Col xs={12}>
                      <ul className="nav-list">
                        <li className="nav-list__item nav-list__item-logo">
                          <Link to="/">
                            <span className="banner-logo">{title.prefix}<span>{title.suffix}</span></span>
                          </Link>
                        </li>
                        <ul className={'nav-list__items ' + (this.state.isToggleOn ? '' : 'nav-list__items_active')}>
                          <li className="nav-list__item">
                            <NavLink activeClassName="nav-list__item_active" to="/consultations">Консультации</NavLink>
                          </li>
                          <li className="nav-list__item">
                            <NavLink activeClassName="nav-list__item_active" to="/user_requests">Заявления</NavLink>
                          </li>
                          <li className="nav-list__item">
                            <NavLink activeClassName="nav-list__item_active" to="/uslugas">Услуги</NavLink>
                          </li>
                          <li className="nav-list__item">
                            <NavLink activeClassName="nav-list__item_active"  to="/queries">Запросы</NavLink>
                          </li>
                          <li className="nav-list__item">
                            <NavLink activeClassName="nav-list__item_active"  to="/statistics">Статистика</NavLink>
                          </li>
                          <li className="nav-list__item nav-index__dropdown-item">
                            <NavLink activeClassName="nav-list__item_active" className="nav-index-user__caption" to={"/registries"} onClick={this.preventClick}>Реестры</NavLink>
                            <ul className="nav-index-user__dropdown">
                              {this.props.registries.map((registry) => {
                                return (
                                  <li className="nav-index-user__dropdown-item">
                                    <NavLink activeClassName="nav-list__item_active" to={"/registries/" + registry.id} key={registry.id}>{registry.name}</NavLink>
                                  </li>
                                )
                              })
                              }
                              <li className="nav-index-user__dropdown-item"><NavLink activeClassName="nav-list__item_active" to="/agents">Заявители</NavLink></li>
                            </ul>
                          </li>
                          {current_user.current_servant &&
                          <li className="nav-list__item nav-index-user">
                            <a className="nav-index-user__caption">{current_user.current_servant.name + " " + current_user.current_servant.surname}</a>
                            <ul className="nav-index-user__dropdown">
                              <li className="nav-index-user__dropdown-item"><a href="/session/logout">Выход</a></li>
                            </ul>
                          </li>
                          }
                        </ul>
                        <div className="hamburger-wrapper">
                          <button
                            className={'c-hamburger c-hamburger--htx ' + (this.state.isToggleOn ? '' : 'is-active')}
                            onClick={this.handleClick}><span>toggle men</span></button>
                        </div>
                      </ul>
                    </Col>
                  </Row>
                </Grid>
              </div>
            </div>
          )
        }}
      </Sticky>
    )
  }
}

export default withRouter(connect(mapStateToProps)(TopMenu))
