import React from 'react'
import PropTypes from 'prop-types'

export default class Base extends React.Component {

  static contextTypes = {
    config: PropTypes.object.isRequired
  }

  constructor(props, context){
    super(props)
    this.config = context.config
  }

}

