import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'

export default function Countdown(props, context){
  const d = new Date(context.remaining);
  const { minutes, seconds } = {
    minutes: d.getMinutes(),
    seconds: d.getSeconds()
  }
  const total = 15*60000
  const { remaining } = context
  const w = 100 - ((total - remaining) / total) * 100;
  const label = minutes > 2 ? "info" : "warning"
  return (
    <div className="progress">
      { remaining ? (
        <div className={"progress-bar progress-bar-"+label} role="progressbar" aria-valuenow={remaining} aria-valuemin="0" aria-valuemax={total} style={{width: w+"%"}}>
          {minutes}:{seconds}
        </div>
      ):(
        <div className="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style={{width: "100%"}}>
          Время вышло
        </div>
     )}
    </div>
  )
}
Countdown.contextTypes = {
  remaining: PropTypes.number,
};
