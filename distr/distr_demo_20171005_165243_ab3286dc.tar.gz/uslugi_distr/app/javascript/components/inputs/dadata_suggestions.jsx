import React from 'react'
import PropTypes from 'prop-types'
import ReactDOM from 'react-dom'
global.jQuery = require('jquery');
require('suggestions-jquery');
import 'suggestions-jquery/dist/css/suggestions.css'

class DaDataSuggestions extends React.Component {
  constructor(props){
    super(props)
    this.id = Math.random().toString(36).substr(2, 9);
    this.state = {address: props.value, formData: props.formData, value: props.valueFromData&&props.valueFromData(props)}
    this.componentDidMount = this.componentDidMount.bind(this);
  }
  componentWillReceiveProps(nextProps){
    this.props.valueFromData && this.jqc.val(this.props.valueFromData(nextProps))
  }
  componentDidMount () {
     var th = this
     this.jqc = jQuery("#"+th.id).suggestions({
        token: "abc920cb25187ef8cf7964359514da7fd27aea7c",
        type: th.props.type,
        count: 5,
        /* Вызывается, когда пользователь выбирает одну из подсказок */
        onSelect: function(suggestion) {
          th.setState({address: suggestion})
          th.props.onChange(suggestion)
        }
    });
  }
  componentWillUnmount() {
    jQuery(this.jqc).suggestions().dispose()
  }

  render (){
    const { schema, formData}= this.props
    return (
        <input required defaultValue=""  ref={(input) => this.input = input} id={this.id} type="text" size="100" className="form-control form-select"/>
        // {/*{ schema && schema.title &&*/}
        //   {/*<label className="control-label" htmlFor={this.id}>{schema.title}{this.props.required ? "*" : null}</label>*/}
        // {/*}*/}
        // { this.props.isDebug &&
        //   <pre>
        //     {JSON.stringify(this.state.address, null, '  ')}
        //   </pre>
        // }
    )
  }
}
DaDataSuggestions.propTypes = {
  isDebug: PropTypes.bool,
  value: PropTypes.string,
  onChange: PropTypes.func,
}

export default DaDataSuggestions
