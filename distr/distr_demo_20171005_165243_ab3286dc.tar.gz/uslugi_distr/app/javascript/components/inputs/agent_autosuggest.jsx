import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import Autosuggest from 'react-autosuggest'
import axios from 'axios'
import './agent_autosuggest.css'

export default class AgentAutosuggest extends React.Component {

  getSuggestions(value) {
    const inputValue = value.trim().toLowerCase()
    const inputLength = inputValue.length
    if (inputLength < 3){
      this.setState({suggestions: []})
      return
    }
    axios.get("/agents.json?passport_number="+inputValue)
      .then((response)=>{
        this.setState({
          suggestions: response.data.data || []
        })
      })
      .catch((error)=>{
        console.log(error)
        this.setState({suggestions: []})
      })
  }

  getSuggestionValue(suggestion) {
    return suggestion.passport_number
  }

  renderSuggestion(suggestion){
    return (<div>
      <span className="name">
        {[suggestion.name, suggestion.patronymic_name, suggestion.surname].join(" ")}
      </span>
      <br />
      <span className="passport_number">
          Номер паспорта: <span style={{color: "red"}}>{suggestion.passport_number}</span>
      </span>
      <br />
      <span className="contact">
          Телефон: {suggestion.mobile} / email: {suggestion.email}
      </span>
    </div>)

  }
  constructor() {
    super()

    // Autosuggest is a controlled component.
    // This means that you need to provide an input value
    // and an onChange handler that updates this value (see below).
    // Suggestions also need to be provided to the Autosuggest,
    // and they are initially empty because the Autosuggest is closed.
    this.state = {
      suggestions: []
    }
  }
  onChange(event, { newValue }){
    this.props.onChange(newValue)
  }

  onSuggestionSelected(event, { suggestion}){
    event.preventDefault()
    this.props.onSelect(suggestion)
  }

  onSuggestionsFetchRequested({ value }) {
    this.getSuggestions(value)
  }

  onSuggestionsClearRequested (){
    this.setState({
      suggestions: []
    })
  }
  renderInputComponent= (inputProps)=>{
    const { schema, required, id}= this.props
    const {title} = schema
    return (
      <div>
        <input {...inputProps} />
        <label htmlFor={id}>{title}{required ? "*" : null}</label>
      </div>
    )
  }

  render() {
    const { suggestions } = this.state
    const { formData, schema, label, id, required }= this.props
    const value = formData || ''
    // Autosuggest will pass through all these props to the input.
    const inputProps = {
      className: 'form-control',
      //placeholder: 'Type a programming language',
      required: this.props.required,
      value,
      onChange: this.onChange.bind(this)
    }

    // Finally, render it!
    return (
      <Autosuggest
        suggestions={suggestions}
        onSuggestionsFetchRequested={this.onSuggestionsFetchRequested.bind(this)}
        onSuggestionsClearRequested={this.onSuggestionsClearRequested.bind(this)}
        onSuggestionSelected={this.onSuggestionSelected.bind(this)}
        getSuggestionValue={this.getSuggestionValue}
        renderSuggestion={this.renderSuggestion}
        renderInputComponent={this.renderInputComponent}
        inputProps={inputProps}
      />
    )
  }
}
