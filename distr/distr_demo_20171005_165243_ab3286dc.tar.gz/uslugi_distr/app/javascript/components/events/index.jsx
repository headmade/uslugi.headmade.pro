import React from 'react'
import axios from 'axios'
import {ButtonGroup, Button, Alert, FormGroup, ControlLabel, FormControl} from 'react-bootstrap'
import SignButton from './sign_button'
import UIForm from '~/form/ui_form'
import prepareSchema from '~/form/prepare_schema'

export default class EventsComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      formVisible: false,
      formData: {}
    }
    this.handleAlertDismiss = this.handleAlertDismiss.bind(this)
  }

  onSubmit(resource, object_id, name){
    return (data)=>{
      axios.post(`${resource}/${object_id}/event`, {name: name, data: data.formData||data||{}})
        .then((response)=>{
          this.props.onSuccess()
        })
        .catch((error)=>{
          console.log(error)
        })
    }
  }

  handleAlertDismiss() {
    this.setState({formVisible: false});
  }

  handleAlertShow(event) {
    this.setState({formVisible: true, event: event});
  }

  render(){
    const {object, resource, resources, passport} = this.props
    const {formVisible, event, formData} = this.state
    const  api_resources = resources || resource+'s'
    if (formVisible) {
      return (
        <Alert bsStyle={event.style} onDismiss={this.handleAlertDismiss}>
          <h4>Выполняется действие "{event.name}"</h4>
          <UIForm onSubmit={this.onSubmit(api_resources, object.id, event.key)} schema={prepareSchema(passport.data[resource].events[event.key].schema)} formData={formData} >
            <Button bsStyle={event.style} bsSize="large" type="submit">{event.name}</Button>
            <Button onClick={this.handleAlertDismiss} bsSize="xsmall">Отмена</Button>
          </UIForm>
        </Alert>
      )
    }

    return <ButtonGroup>
      {object.permitted_events_config.map((event)=>{
        if (event.require_sign){
          return <SignButton bsStyle={event.style} key={event.key} data={object.data_to_sign} onClick={this.onSubmit(api_resources, object.id, event.key)}>{event.name}</SignButton>
        } else {
          //return <Button bsStyle={event.style} key={event.key} onClick={this.onClick(resource, object.id, event.key)}>{event.name}</Button>
          return <Button bsStyle={event.style} key={event.key} onClick={this.handleAlertShow.bind(this, event)}>{event.name}</Button>
        }
      })}
    </ButtonGroup>
  }
}
