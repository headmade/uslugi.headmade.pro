import React from 'react'
import 'babel-polyfill'
import '../cadesplugin_api.js'
import {Button} from 'react-bootstrap'

    var CAPICOM_CURRENT_USER_STORE = 2;
    var CAPICOM_MY_STORE = "My";
    var CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED = 2;
    var CAPICOM_CERTIFICATE_FIND_SUBJECT_NAME = 1;
    var CADESCOM_XML_SIGNATURE_TYPE_ENVELOPED = 0;
    var CADESCOM_XML_SIGNATURE_TYPE_ENVELOPING = 1;
    var XmlDsigGost3410UrlObsolete = "http://www.w3.org/2001/04/xmldsig-more#gostr34102001-gostr3411";
    var XmlDsigGost3411UrlObsolete = "http://www.w3.org/2001/04/xmldsig-more#gostr3411";
    var XmlDsigGost3410Url = "urn:ietf:params:xml:ns:cpxmlsec:algorithms:gostr34102001-gostr3411";
    var XmlDsigGost3411Url = "urn:ietf:params:xml:ns:cpxmlsec:algorithms:gostr3411";

function certExtract(from, what){
    let certName = ""

    let begin = from.indexOf(what)

    if(begin>=0){
        let end = from.indexOf(', ', begin)
        certName = (end<0) ? from.substr(begin) : from.substr(begin, end - begin)
    }

    return certName
}

export default class SignButton extends React.Component {
  constructor(props){
    super(props)
    this.state = {SubjectName:'', IssuerName: '', ValidToDate: '', install: false, sign: null}
  }
  componentWillMount() {
    let dataToSign = this.props.data
    let th = this
    cadesplugin.then(()=>{
      cadesplugin.async_spawn(function *(args) {
        let oStore =  yield cadesplugin.CreateObjectAsync("CAdESCOM.Store");
        yield oStore.Open(CAPICOM_CURRENT_USER_STORE, CAPICOM_MY_STORE,
              CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED)
        let CertificatesObj = yield oStore.Certificates
        let Count = yield CertificatesObj.Count
        if (Count == 1){
          let oCertificate = yield CertificatesObj.Item(1)
          let IssuerName = yield oCertificate.IssuerName
          let SubjectName = yield oCertificate.SubjectName
          let ValidToDate = yield oCertificate.ValidToDate
          //console.log(oCertificate, SubjectName, IssuerName, ValidToDate)
          let oSigner = yield cadesplugin.CreateObjectAsync("CAdESCOM.CPSigner")
          yield oSigner.propset_Certificate(oCertificate)

          let oSignedXML = yield cadesplugin.CreateObjectAsync("CAdESCOM.SignedXML")
          yield oSignedXML.propset_Content(dataToSign)
          yield oSignedXML.propset_SignatureType(CADESCOM_XML_SIGNATURE_TYPE_ENVELOPED)
          yield oSignedXML.propset_SignatureMethod(XmlDsigGost3410Url)
          yield oSignedXML.propset_DigestMethod(XmlDsigGost3411Url)


          const sign = ()=>{
            let sSignedMessage = oSignedXML.Sign(oSigner)
            sSignedMessage.then((msg)=>{
              console.log(msg)
              th.props.onClick({signed: msg})
            })
            .catch((error)=>{
              console.log(error, sSignedMessage)
            })
          }

          th.setState({SubjectName, IssuerName, ValidToDate, sign, install: true})

        }else{
          for (var i = 1; i <= Count; i++) {
            let oCertificate = yield CertificatesObj.Item(i);
            let SubjectName = yield oCertificate.SubjectName
            console.log(SubjectName)
          }
        }
        //yield oStore.Close()
      })
    })
    .catch((error)=>{
      console.log(error)
    })
  }
  render(){
    const {SubjectName, IssuerName, ValidToDate, sign, install} = this.state
    const {bsStyle, children} = this.props
    if (!install){
      return <div>Плагин не загружен, не возможно подписать</div>
    }
    return <Button bsStyle={bsStyle} onClick={sign}>
        <span className="glyphicon glyphicon-lock" aria-hidden="true" />
        {children}({certExtract(SubjectName, 'CN')})
      </Button>
    return <div onClick={sign}>
        <p>SubjectName: {SubjectName}</p>
        <p>IssuerName: {IssuerName}</p>
        <p>ValidToDate: {ValidToDate}</p>
      </div>
  }
}
