import React from 'react'
import axios from 'axios'
import { connect } from 'react-redux'
import {MenuItem, ButtonGroup, Button, DropdownButton, Alert, FormGroup, ControlLabel, FormControl} from 'react-bootstrap'
import UIForm from '~/form/ui_form'
import prepareSchema from '~/form/prepare_schema'

const mapStateToProps = ({isDebug, query_passports})=>({isDebug, query_passports})

@connect(mapStateToProps)
export default class QueriesComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      formVisible: false,
      defaultFormVisible: false,
      formData: {}
    }
    this.handleAlertDismiss = this.handleAlertDismiss.bind(this)
  }

  onSubmit(resource, object_id, query_passport_id, auto_query=false){
    return (data)=>{
      axios.post(`/uslugas/${object_id}/${resource}`, {auto_query: auto_query, query_passport_id: query_passport_id, data: data.formData||data||{}})
        .then((response)=>{
          this.props.onSuccess()
        })
        .catch((error)=>{
          console.log(error)
        })
    }
  }

  handleAlertDismiss() {
    this.setState({defaultFormVisible: false, formVisible: false});
  }

  handleAlertShow(item) {
    if (!dig(item, 'data', 'query', 'source')){
      this.setState({formVisible: true, item: item})
    } else {
      this.setState({defaultFormVisible: true, item: item})
    }
  }

  render(){
    const {isDebug, query_passports, object} = this.props
    const {formVisible, item, formData, defaultFormVisible} = this.state
    const resource = 'query'
    const  api_resources = 'queries'
    if (object.query_passports.length == 0){
      return null
    }

    const queries = query_passports.filter((item)=>{
      return object.query_passports.includes(item.id)
    })

    if (defaultFormVisible) {
      const data = {}
      return (
        <Alert onDismiss={this.handleAlertDismiss}>
          <h4>Выполняется действие "{item.name}"</h4>
          <p>Данный запрос будет сформирован автоматически на основе данных услуги, вы уверены что хотите продложить?</p>
          <br />
          <Button onClick={this.onSubmit(api_resources, object.id, item.id, true).bind(this, data)} bsSize="large" type="submit">Создать запрос</Button>
          <Button onClick={this.handleAlertDismiss} bsSize="xsmall">Отмена</Button>
        </Alert>
      )
    }

    if (formVisible) {
      return (
        <Alert onDismiss={this.handleAlertDismiss}>
          <h4>Выполняется действие "{item.name}"</h4>
          <UIForm onSubmit={this.onSubmit(api_resources, object.id, item.id)} schema={prepareSchema(item.data[resource].schema)} formData={formData} >
            <Button bsSize="large" type="submit">Создать запрос</Button>
            <Button onClick={this.handleAlertDismiss} bsSize="xsmall">Отмена</Button>
          </UIForm>
        </Alert>
      )
    }


    return <ButtonGroup><DropdownButton bsStyle='primary' title="Создать запрос" id="bg-nested-dropdown">
      {queries.map((item, index)=>{
        return <MenuItem key={index} onClick={this.handleAlertShow.bind(this, item)}>{item.name}</MenuItem>
      })}
    </DropdownButton></ButtonGroup>
  }
}
