import React from 'react'
import PropTypes from 'prop-types'
import { createStore, applyMiddleware } from 'redux'
import { Provider } from 'react-redux'
import thunk from 'redux-thunk'
import logger from 'redux-logger'
import {middleware as fetchMiddleware} from 'react-redux-fetch'
import { BrowserRouter as Router } from 'react-router-dom'
import { StickyContainer } from 'react-sticky'
import ActionCable from 'actioncable'

import reducers from '~/reducers'
import toggleDebug from '~/actions/debug'
import loadSession from '~/actions/user'
import loadPassports, {loadQueryPassports} from '~/actions/passport'
import loadUslugaRequests from '~/actions/usluga_request'
import loadRegistries from '~/actions/registry'
import receivedNotification from '~/actions/notification'


import TopMenu from '~/components/top_menu'
import TopMenuError from '~/components/top_menu_error'
import ServantRoutes from '~/routing/servant'
import BaseFooter from '~/components/base_footer'
import Loader from '~/components/loader'
import ScrollToTop from '~/components/scroll_to_top'
import Alerts from '~/components/alerts'
import ErrorPage from '~/components/error-page'




export default class App extends React.Component {

  static childContextTypes = {
    config: PropTypes.object
  }

  getChildContext() {
    return {
      config: this.config
    }
  }

  constructor(props){
    super(props)
    this.config = this.props.config

    this.store = createStore(reducers, {}, applyMiddleware(thunk, logger, fetchMiddleware))
    if (process.env.NODE_ENV !== "production") {
      this.store.dispatch(toggleDebug())
    }
    window.toggleDebug = ()=>{
      this.store.dispatch(toggleDebug())
    }

    this.store.dispatch(loadSession())
    this.store.dispatch(loadUslugaRequests())
    this.store.dispatch(loadPassports())
    this.store.dispatch(loadQueryPassports())
    this.store.dispatch(loadRegistries())
    const store = this.store

    const cable = ActionCable.createConsumer()
    cable.subscriptions.create("NotificationsChannel",
      {
        received: function(data){
          store.dispatch(receivedNotification(data))
        }
      }
    )


    this.state = { hasError: false }
    console.log(cable)
  }

  componentDidCatch(error, info){
    this.setState({ hasError: true })
    console.log(error, info)
  }

  render(){
    if (this.state.hasError) {
      return (
        <div>
          <TopMenuError/>
          <ErrorPage />
          <BaseFooter/>
        </div>
      )
    }

    return (
      <StickyContainer>
        <Provider className="test" store={this.store}>
          <Router basename="/servant">
            <ScrollToTop>
              <div>
                <TopMenu/>
                <Alerts />
                <ServantRoutes/>
                <BaseFooter/>
              </div>
            </ScrollToTop>
          </Router>
        </Provider>
      </StickyContainer>
    )
  }
}

