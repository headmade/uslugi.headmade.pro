export default function toggleDebug() {
  return (dispatch) => {
    dispatch({type: "SET_DEBUG"})
  }
}
