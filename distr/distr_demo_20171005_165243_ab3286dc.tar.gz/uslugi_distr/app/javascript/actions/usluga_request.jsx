import axios from 'axios'

export default function loadUslugaRequests() {
  return (dispatch) => {
    return axios.get("/usluga_requests.json")
      .then((response)=>{
        let usluga_requests = {}
        response.data.data.forEach((usluga_request)=>{
          usluga_requests[usluga_request.id]=usluga_request
        })
        dispatch({type: "FETCH_USLUGA_REQUESTS", usluga_requests: usluga_requests})
          let usluga_request = usluga_requests[Object.keys(usluga_requests)[Object.keys(usluga_requests).length - 1]]
        if (usluga_request){
          dispatch({type: "SET_LAST_USLUGA_REQUEST", usluga_request: usluga_request})
        }
      })
      .catch((error)=>{
        console.log(error)
      })
  }
}
