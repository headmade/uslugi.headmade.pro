import axios from 'axios'

export default function loadSession() {
  return (dispatch) => {
    return axios.get("/session.json")
      .then((response)=>{
        dispatch({type: "SET_CURRENT_USER", session: response.data})
      })
      .catch((error)=>{
        console.log(error)
      })
  }
}
