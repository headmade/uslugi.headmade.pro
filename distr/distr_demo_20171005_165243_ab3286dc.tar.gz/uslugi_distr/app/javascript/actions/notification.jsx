export default function receivedNotification(data) {
  return (dispatch) => {
    dispatch({type: "ADD_NOTIFICATION", data: data})
  }
}

export function removeNotification(id) {
  return (dispatch) => {
    dispatch({type: "REMOVE_NOTIFICATION", id: id})
  }
}
