import axios from 'axios'

export default function loadPassports(){
  return (dispatch) => {
    return axios.get("/passports.json")
      .then((response)=>{
        dispatch({type: "FETCH_SERVANT_PASSPORTS", servant_passports: response.data.data})
      })
      .catch((error)=>{
        console.log(error)
      })
  }
}

export function loadQueryPassports(){
  return (dispatch) => {
    return axios.get("/query_passports.json")
      .then((response)=>{
        dispatch({type: "FETCH_QUERY_PASSPORTS", passports: response.data.data})
      })
      .catch((error)=>{
        console.log(error)
      })
  }
}
