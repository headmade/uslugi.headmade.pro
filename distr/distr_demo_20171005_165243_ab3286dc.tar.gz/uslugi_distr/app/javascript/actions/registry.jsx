import axios from 'axios'

export default function loadRegistries() {
  return (dispatch) => {
    return axios.get("/registries.json")
      .then((response)=>{
        dispatch({type: "FETCH_REGISTRIES", registries: response.data.data})
      })
      .catch((error)=>{
        console.log(error)
      })
  }
}
