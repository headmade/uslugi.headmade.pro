import React from 'react'
import ReactS3Uploader from 'react-s3-uploader'
import DropzoneS3Uploader from 'react-dropzone-s3-uploader'

export default class FileWidget extends React.Component {
  constructor(props){
    super(props)
    this.state = {files: [], display: []}
  }

  renderFileUpload = (file, i) => {
    return (
      <div onClick={this.stopPropagation} className="drop-zone__content" key={i} >
        <div className="drop-zone__content-img">
          <img src={file.preview} />
        </div>
        <p>
          {file.name}
        </p>
        <a onClick={this.deleteUploadFile(i)}> </a>
      </div>
    )
  }

  stopPropagation(e){
    e.preventDefault()
    e.stopPropagation()
  }

  deleteUploadFile(i){
    return (e) =>{
      let {files, display} = this.state
      files.splice(i,1)
      display.splice(i,1)
      this.setState({files: files, display: display})
      this.props.onChange(files)
      e.preventDefault()
      e.stopPropagation()
    }
  }

  render() {
        //const { multiple, id, readonly, disabled, autofocus, formContext} = props;
        const { multiple, id, formContext, value, required, schema} = this.props
        const {title} = schema
        return (
          <div className="drop-zone-wrapper">
            <label htmlFor={id}>{title}{required ? "*" : null}</label>
            <DropzoneS3Uploader
              s3Url={`https://s3.${window.location.hostname}`}
              className="drop-zone"
              style={{
                display: 'flex',
                alignItems: 'center',
                flexDirection: 'column',
                width: '100%',
                minHeight: '200px',
                border: '2px dashed rgb(205,209,212)',
                borderRadius: '5px',
                position: 'relative',
                cursor: 'pointer',
                overflow: 'visible'
              }}
              upload={{
                signingUrl:"/api/s3/sign",
                signingUrlMethod:"GET",
                signingUrlQueryParams: {
                  'guid': formContext.guid,
                  field: id
                },
                multiple: multiple,
                scrubFilename: (filename) =>{ return encodeURIComponent(filename.replace(/[\s]+/ig, '_').replace(/[^\wа-яА-ЯёЁ\d_\-\.]+/ig, ''))},
                uploadRequestHeaders:{ 'x-amz-acl': 'public-read' }
              }}
              onFinish={(signResult)=>{
                if (multiple){
                  let {files, display} = this.state
                  files.push(signResult.signedUrl.split('?')[0])
                  display.push(signResult.file)
                  this.setState({files: files, display: display})
                  this.props.onChange(files)
                } else {
                  this.setState({files: [signResult.signedUrl.split('?')[0]], display: [signResult.file]})
                  this.props.onChange(signResult.signedUrl.split('?')[0])
                  }
                }
              }
            >
              <p className="drop-zone__text">Перетащите {multiple ? "файлы" : "файл"} сюда или <span>нажмите</span> для выбора вручную</p>
              {this.state.display.map(this.renderFileUpload)}
            </DropzoneS3Uploader>
          </div>
        )
      }
}
