const addresses = {

  address_with_map:{
    type: "object",
    properties: {
      address: {"$ref": "#/definitions/address"},
      geoJSON: {"$ref": "#/definitions/geoJSON"},
    },
  },

  address: {
    type: "object",
    title: 'Адрес',
    properties: {
      value: {type: "string", title: "Адрес одной строкой"},
      fias_id: {type: "string", title: "Код ФИАС"},
      fias_level: {type: "string", title: "fias_level"},
      geo_coordinates: {"$ref": "#/definitions/geo_coordinates", "title": "Координаты"}
    },
    required: ["fias_id", "value"]
  },

}
export default addresses
