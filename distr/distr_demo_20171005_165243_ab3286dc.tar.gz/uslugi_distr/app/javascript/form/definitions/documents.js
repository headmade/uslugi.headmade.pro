const documents = {
  scanned_document: {type: 'object', properties: {files: {'$ref': '#/definitions/files'}}},
  scanned_document_optional: {type: 'object', properties: {files: {'$ref': '#/definitions/files_optional'}}},

  application: {type: 'object', title: 'Заявление', properties: {content: {'$ref': '#/definitions/scanned_document', title: ''}}},

  letter_of_attorney: {type: 'object', title: 'Доверенность', properties: {content: {'$ref': '#/definitions/scanned_document', title: ''}}},
  letter_of_attorney_optional: {type: 'object', title: 'Доверенность', properties: {content: {'$ref': '#/definitions/scanned_document_optional', title: ''}}},

  topography_of_networks: {type: 'object', title: 'Топография сетей', properties: {content: {'$ref': '#/definitions/scanned_document', title: ''}}},
  conclusion_place_of_damage: {type: 'object', title: 'Заключение о месте поломки', properties: {content: {'$ref': '#/definitions/scanned_document', title: ''}}},
  certificate_of_separation: {type: 'object', title: 'Акт о разграничении сетей', properties: {content: {'$ref': '#/definitions/scanned_document', title: ''}}},
  certificate_sro: {type: 'object', title: 'Свидетельство СРО', properties: {content: {'$ref': '#/definitions/scanned_document', title: ''}}},
  warranty_restore: {type: 'object', title: 'Гарантия повторного восстановления (5 лет)', properties: {content: {'$ref': '#/definitions/scanned_document', title: ''}}},

  passport_bti: {
    type: 'object',
    title: 'Паспорт БТИ',
    properties: {
      bti: {type: 'string', title: 'БТИ', enum: ['БТИ МСиЖКХ РТ','БТИ Вахитовского района','АО Росинвентаризация - Федеральное БТИ отделение по РТ','БТИ ООО "Таткадастр"','РГУП БТИ','Зеленодольское подразделение ОКД РГУП БТИ','Филиал ФГУП "Ростехинвентаризация - Федеральное БТИ" по РТ','ОТИ Московского района г.Казани','ОТИ Кировского района г.Казани','другое БТИ - укажите его наименование в комментариях']},
      inventory_number: {type: 'string', title: 'Инвентарный номер'},
      appartment_number: {type: 'string', title: 'Номер помещения'},
      another_location: {type: 'string', title: 'Иное месторасположение'},
      issue_date: {type: 'string', format: 'date', title: 'Дата выдачи'},
      content: {'$ref': '#/definitions/scanned_document', title: ''},
    },
    required: ["bti", "inventory_number", "issue_date"]
  },

  passport_bti_optional: {
    type: 'object',
    title: 'Паспорт БТИ',
    properties: {
      bti: {type: 'string', title: 'БТИ', enum: ['БТИ МСиЖКХ РТ','БТИ Вахитовского района','АО Росинвентаризация - Федеральное БТИ отделение по РТ','БТИ ООО "Таткадастр"','РГУП БТИ','Зеленодольское подразделение ОКД РГУП БТИ','Филиал ФГУП "Ростехинвентаризация - Федеральное БТИ" по РТ','ОТИ Московского района г.Казани','ОТИ Кировского района г.Казани','другое БТИ - укажите его наименование в комментариях']},
      inventory_number: {type: 'string', title: 'Инвентарный номер'},
      appartment_number: {type: 'string', title: 'Номер помещения'},
      another_location: {type: 'string', title: 'Иное месторасположение'},
      issue_date: {type: 'string', format: 'date', title: 'Дата выдачи'},
      content: {'$ref': '#/definitions/scanned_document_optional', title: ''},
    },
  },

  lease_contract: {
    type: 'object',
    title: 'Договор аренды',
    properties: {
      landlord_persons: {type: 'array', items: {'$ref': '#/definitions/person_fio'}, title: 'Арендодатель - физ.лицо(а)'},
      landlord_organizations: {type: 'array', items: {'$ref': '#/definitions/organization_optional'}, title: 'Арендодатель - юр.лицо(а)'},
      tenant: {'$ref': '#/definitions/organization_optional', title: 'Арендатор'}, // пусто, если арендатор == заявитель
      valid_from: {type: 'string', format: 'date', title: 'Действителен от'},
      valid_to: {type: 'string', format: 'date', title: 'Действителен до'},
      valid_forever: {type: 'boolean', title: 'Бессрочный'},
      content: {'$ref': '#/definitions/scanned_document', title: ''},
    },
    required: ['valid_from'],
    //oneOf: [
      //{required: ['valid_from', 'valid_to']},
      //{required: ['valid_from', 'valid_forever']},
    //],
  },

  lease_contracts: {
    type: 'array',
    title: 'Договора аренды',
    minItems: 1,
    items: {'$ref': '#/definitions/lease_contract'}
  },

}
export default documents
