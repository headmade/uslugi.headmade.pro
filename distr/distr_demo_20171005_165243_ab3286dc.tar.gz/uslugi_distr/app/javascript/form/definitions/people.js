const people = {

  person_fio: {
    type: "object",
    properties: {
        raw: {type: "string", title: "фио"},
        name: {type: "string", title: "Имя"},
        surname: {type: "string", title: "Фамилия"},
        patronymic_name: {type: "string", title: "Отчество"}
    },
    required: ["name","surname","patronymic_name"]
  },

  person_fio_optional: {
    type: "object",
    properties: {
        raw: {type: "string", title: "фио"},
        name: {type: "string", title: "Имя"},
        surname: {type: "string", title: "Фамилия"},
        patronymic_name: {type: "string", title: "Отчество"}
    },
  },

  person_mobile: {
    type: "object",
    properties: {
      fio: {"$ref": "#/definitions/person_fio", title: "ФИО"},
      mobile: {type: "string", title: "Мобильный телефон"},
    },
    required: ["fio", "mobile"]
  },

  person_mobile_optional: {
    type: "object",
    properties: {
      fio: {"$ref": "#/definitions/person_fio_optional", title: "ФИО"},
      mobile: {type: "string", title: "Мобильный телефон"},
    },
  },

  agent: {
    type: "object",
    properties: {
      passport_number: {type: "string",  "pattern": "^[0-9]{6}$", title: "Номер паспорта"},
      fio: {"$ref": "#/definitions/person_fio", title: "ФИО"},
      mobile: {type: "string", title: "Мобильный телефон"},
      email: {type: "string", format: "email", title: "E-mail"}
    },
    required: ["fio", "passport_number", "mobile"]
  },

}
export default people
