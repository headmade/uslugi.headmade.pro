import geojson from './geojson'
import general from './general'
import addresses from './addresses'
import people from './people'
import documents from './documents'

const definitions = {
  ...addresses,
  ...general,
  ...people,
  ...documents,

geo_coordinates: {
  type: "object",
  properties: {
    lat: {type: "number", title: "Широта"},
    lon: {type: "number", title: "Долгота"}
  }
  //required: ["lat", "lon"],
},

geoJSON: geojson,
coordinates: {
  "title": "Coordinates",
  "type": "array",
  "items": {
    "oneOf": [
      { "type": "array" },
      { "type": "number" }
    ]
  }
},

geometry: {
  "title": "Geometry",
  "description": "A geometry is a GeoJSON object where the type member's value is one of the following strings: `Point`, `MultiPoint`, `LineString`, `MultiLineString`, `Polygon`, `MultiPolygon`, or `GeometryCollection`.",
  "properties": {
    "type": {
      "enum": [
        "Point",
        "MultiPoint",
        "LineString",
        "MultiLineString",
        "Polygon",
        "MultiPolygon",
        "GeometryCollection"
      ]
    }
  }
},

feature: {
  "title": "Feature",
  "description": "A GeoJSON object with the type `Feature` is a feature object.\n\n* A feature object must have a member with the name `geometry`. The value of the geometry member is a geometry object as defined above or a JSON null value.\n\n* A feature object must have a member with the name `properties`. The value of the properties member is an object (any JSON object or a JSON null value).\n\n* If a feature has a commonly used identifier, that identifier should be included as a member of the feature object with the name `id`.",
  "required": ["geometry", "properties"],

  "properties": {

    "type": { "enum": ["Feature"] },

    "geometry": {
      "title": "Geometry",
      "oneOf": [
        { "$ref": "#/definitions/geometry" },
        { "type": "null" }
      ]
    },

    "properties": {
      "title": "Properties",
      "oneOf": [
        { "type": "object" },
        { "type": "null" }
      ]
    },

    "id": {}

  }
},

linearRingCoordinates: {
  "title": "Linear Ring Coordinates",
  "description": "A LinearRing is closed LineString with 4 or more positions. The first and last positions are equivalent (they represent equivalent points). Though a LinearRing is not explicitly represented as a GeoJSON geometry type, it is referred to in the Polygon geometry type definition.",
  "allOf": [
    { "$ref": "#/definitions/lineStringCoordinates" },
    {
      "minItems": 4
    }
  ]
},

lineStringCoordinates: {
  "title": "Line String Coordinates",
  "description": "For type `LineString`, the `coordinates` member must be an array of two or more positions.",
  "allOf": [
    { "$ref": "#/definitions/coordinates" },
    {
      "minLength": 2,
      "items": { "$ref": "#/definitions/position" }
    }
  ]
},

polygonCoordinates: {
  "title": "Polygon Coordinates",
  "description": "For type `Polygon`, the `coordinates` member must be an array of LinearRing coordinate arrays. For Polygons with multiple rings, the first must be the exterior ring and any others must be interior rings or holes.",
  "allOf": [
    { "$ref": "#/definitions/coordinates" },
    {
      "items": { "$ref": "#/definitions/linearRingCoordinates" }
    }
  ]
},

position: {
  "title": "Position",
  "type": "array",
  "description": "A position is the fundamental geometry construct. The `coordinates` member of a geometry object is composed of one position (in the case of a Point geometry), an array of positions (LineString or MultiPoint geometries), an array of arrays of positions (Polygons, MultiLineStrings), or a multidimensional array of positions (MultiPolygon).\n\nA position is represented by an array of numbers. There must be at least two elements, and may be more. The order of elements must follow x, y, z order (easting, northing, altitude for coordinates in a projected coordinate reference system, or longitude, latitude, altitude for coordinates in a geographic coordinate reference system). Any number of additional elements are allowed -- interpretation and meaning of additional elements is beyond the scope of this specification.",
  "minItems": 2,
  "additionalItems": true,
  "items": {
    "type": "number"
  }
}

}

export default definitions
