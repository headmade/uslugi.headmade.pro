const general = {
  cadastre_number: {type: 'string', title: 'Кадастровый номер'},
  planeta_number: {type: 'string', title: '№ в Планета задач'},
  comments: {type: 'string', title: 'Комментарий'},
  response_text: {type: 'string', title: 'Информация для заявителя'},
  query_text: {type: 'string', title: 'Текст запроса'},
  attachments: {type: 'array', 'items': {'$ref': '#/definitions/files_with_description'}, title: 'Доп. приложения'},

  organization: {
    type: "object",
    title: 'Организация',
    properties: {
      name: {type: "string", title: "Название"},
      inn: {type: "string", title: "ИНН"},
      kpp: {type: "string", title: "КПП"},
      ogrn: {type: "string", title: "ОГРН"}
    },
    required: ["inn"]
  },

  organization_optional: {
    type: "object",
    title: 'Организация',
    properties: {
      name: {type: "string", title: "Название"},
      inn: {type: "string", title: "ИНН"},
      kpp: {type: "string", title: "КПП"},
      ogrn: {type: "string", title: "ОГРН"}
    }
  },

  department: {
    type: "object",
    title: 'Подразделение',
    required: ['name'],
    properties: {
      organization_id: {type: 'integer'},
      department_id: {type: 'integer'},
      value: {type: 'string', title: 'Название'},
    }
  },

  servant: {
    type: "object",
    title: 'Сотрудник',
    properties: {
      servant_id: {type: 'integer'},
      department_id: {type: 'integer'},
      organization_id: {type: 'integer'},
      value: {type: 'string', title: 'ФИО'},
    }
  },

  recipient: {
    type: "object",
    title: 'Получатель',
    properties: {
      id: {type: 'integer'},
      type: {type: 'string'},
      title: {type: 'string'},
    }
  },

  file: {
    type: "object",
    properties: {
      description: {type: "string", title:"Описание"},
      object: {type: "string", format: "data-url", title: "Файл"}
    }
  },

  files: {
    type: "array",
    title: 'Файлы',
    minItems: 1,
    items:{
      //type: "object", properties: {file: {type: "string", format: "data-url", title: "Файл"}}, required: ['file'], // так показывается с "+"
      type: "string", format: "data-url", // - так показывает без "+"
    }
  },

  files_optional: {
    type: "array",
    title: 'Файлы',
    items:{
      //type: "object", properties: {file: {type: "string", format: "data-url", title: "Файл"}}, required: ['file'], // так показывается с "+"
      type: "string", format: "data-url", // - так показывает без "+"
    }
  },

  files_with_description: {type: 'object', properties: {description: {type: 'string', title: 'Описание'}, files: {'$ref': '#/definitions/files', title: 'Файлы'}}},

  image: {type: "string", format: "data-url", title: "Изображение"},
  images: {type: 'object', properties: {files: {'$ref': '#/definitions/files'}}},

  //image_with_description: {type: 'object', properties: {description: {type: 'string', title: 'Описание'}, file: {'$ref': '#/definitions/file', title: ''}}, required: ['file']},
  image_with_description: {type: 'object', properties: {file: {'$ref': '#/definitions/file', title: ''}}, required: ['file']},
  images_with_description: {'$ref': '#/definitions/files_with_description'},

}
export default general
