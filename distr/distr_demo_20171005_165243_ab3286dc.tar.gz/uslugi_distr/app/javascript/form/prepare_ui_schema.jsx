export default function prepareUiSchema(schema){
  return schema
}
