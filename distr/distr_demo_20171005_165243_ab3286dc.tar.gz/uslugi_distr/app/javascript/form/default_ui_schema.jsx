const defaultUiSchema = {
  agent:{ "ui:field": "agent" },
  organization: {"ui:field": "organization"},
  regulator_organization: {"ui:field": "organization"},
  customer_organization: {"ui:field": "organization"},
  address: { "ui:field": "address"},
  lease_contracts:{
    items: {
      landlord: {"ui:field": "organization"},
      tenant: {"ui:field": "organization"}
    }
  },
  comments: {
    "ui:widget": "textarea"
  }
}
export default defaultUiSchema
