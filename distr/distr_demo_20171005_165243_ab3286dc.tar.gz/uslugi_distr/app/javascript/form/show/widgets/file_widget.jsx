import React from 'react'
import {Col, Row, Thumbnail} from 'react-bootstrap'
import LazyLoad from 'react-lazy-load'

import Loader from '../../../components/loader'

export default class FileWidget extends React.Component {

  constructor(props){
    super(props)
    this.state = { file:'', open: false}
    const host = window.location.hostname == 'localhost' ? 'uslugi.kzn.ru' : window.location.hostname
    this.imageproxyUrl = `https://imageproxy.s3.${host}`
  }

  toggleOpen = (file) => {
    this.setState({file, open: true})
  }

  toggleClose = () => {
    this.setState({file:'', open: false})
  }


  render(){
    const props = this.props
        if (Array.isArray(props.value)){
          return (
            <Row>{props.value.map((file, key)=>{
              if (!file){
                return ''
              }
              if (file.toLowerCase().match(/(.jpg|.jpeg|.png|.gif|.tif|.tiff)\?/)){
                return <Col key={key} md={2}>
                  <div onClick={this.toggleOpen.bind(this, file)} className="thumbnail-wrapper">
                    <LazyLoad>
                      <Thumbnail src={`${this.imageproxyUrl}/150x,q60/${file}`} />
                    </LazyLoad>
                  </div>
                  { this.state.open &&
                    <div onClick={this.toggleClose} className="thumbnailX2-wrapper thumbnailX2-wrapper-on" >
                      <img src={`${this.imageproxyUrl}/1500x,q60/${this.state.file}`} onLoad={this.onLoadImage}/>
                      <Loader />
                    </div>
                  }
                </Col>
              }
              return <Col key={key} md={2}><a className="show-form__download" href={file}>Скачать<br />{file && file.split('?').shift().split('/').pop()}</a></Col>
              })}
            </Row>
          )
        }
        if (!props.value){
          return <br />
        }

        if ( props.value.toLowerCase().match(/(.jpg|.jpeg|.png|.gif|.tif|.tiff)\?/)){
          return <Row>
            <Col md={12}>
              <div onClick={this.toggleOpen.bind(this, props.value)} className="thumbnail-wrapper">
                <LazyLoad>
                  <Thumbnail src={`${this.imageproxyUrl}/150x,q60/${props.value}`} />
                </LazyLoad>
              </div>
              { this.state.open &&
                <div onClick={this.toggleClose} className="thumbnailX2-wrapper thumbnailX2-wrapper-on" >
                  <img src={`${this.imageproxyUrl}/1500x,q60/${this.state.file}`} onLoad={this.onLoadImage}/>
                  <Loader />
                </div>
              }
            </Col>
          </Row>
        }
        return <Row><Col md={2}><a href={props.value}>Скачать {props.value && props.value.split('?').shift().split('/').pop()}</a></Col></Row>
  }

}
