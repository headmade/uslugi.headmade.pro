import React from 'react'
import SchemaField from "react-jsonschema-form/lib/components/fields/SchemaField"
import update from 'immutability-helper';


export default class AnyOfField extends React.Component {
  render(){
    console.log(this.props)
    return null
  }
}
