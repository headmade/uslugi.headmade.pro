export const defaultSchema = {
  definitions: {},
  //title: "Регистрация консультации",
  type: "object",
  required: ["organization"],
  properties: {
    organization: {"$ref": "#/definitions/organization", title: "Организация"},
    agent: {"$ref": "#/definitions/agent", title: "Представитель"},
    address: {"$ref": "#/definitions/address", title: "Адрес объекта"},
    comments: {type: "string", title: "Комментарий"}
  }
}

export const defaultUslugaResultSchema = {
  definitions: {},
  type: "object",
	properties: {
		response: {'$ref': '#/definitions/textarea', title: 'Ответ'},
		attachments: {'$ref': '#/definitions/attachments'},
		comments: {'$ref': '#/definitions/comments'},
	},
}

export const defaultUslugaRejectSchema = {
  definitions: {},
  type: "object",
	properties: {
		reason: {
			title: 'Причина отказа',
			type: 'array',
			items: {
				type: 'string',
				enum: ['Причина-1', 'Причина-2',]
			},
			uniqueItems: true,
		},
		comments: {'$ref': '#/definitions/comments'},
	},
}

export default defaultSchema
