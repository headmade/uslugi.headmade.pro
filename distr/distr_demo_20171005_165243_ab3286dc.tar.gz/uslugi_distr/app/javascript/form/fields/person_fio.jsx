import React from 'react'
import ReactDOM from 'react-dom'
import DaDataSuggestions from "~/components/inputs/dadata_suggestions";

const personFioField = (props) => {
  return (
    <DaDataSuggestions {...props} type= "NAME" valueFromData={(nextProps)=>{
      return [nextProps.formData.name, nextProps.formData.patronymic_name, nextProps.formData.surname].join(" ")
    }} onChange = {(suggestion) =>{
        props.onChange({
          name: suggestion.data.name,
          surname: suggestion.data.surname,
          patronymic_name: suggestion.data.patronymic,
        })
      }}/>
  )
}
export default personFioField
