import React from 'react'
import ReactDOM from 'react-dom'
import DaDataSuggestions from "~/components/inputs/dadata_suggestions";

const addressField = (props) => {
  return (
    <DaDataSuggestions {...props} type= "ADDRESS"
      valueFromData={(nextProps)=>{
            return nextProps.formData.value
          }}
      onChange={(suggestion) =>{
        props.onChange({
          value: suggestion.value,
          fias_id: suggestion.data.fias_id,
          fias_level: suggestion.data.fias_level,
          geo_coordinates:{
            lat: parseFloat(suggestion.data.geo_lat),
            lon: parseFloat(suggestion.data.geo_lon)
          }
        })
      }}/>
  )
}
export default addressField
