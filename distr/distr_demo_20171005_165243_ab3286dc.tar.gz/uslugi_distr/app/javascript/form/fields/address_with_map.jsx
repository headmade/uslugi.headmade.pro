import React from 'react'
import addressField from '~/form/fields/address'
import MapField from '~/form/fields/map'
import SchemaField from "react-jsonschema-form/lib/components/fields/SchemaField"
import update from 'immutability-helper';

export default class addressWithMapField extends React.Component{
  constructor(props){
    super(props)
    console.log(props)
    this.state = props.formData
    this.uiSchema = {
      address:{"ui:field": addressField},
      //geoJSON:{"ui:field": mapField}
    }
    //this.newProps = Object.assign({}, props, {"uiSchema": uiSchema})
    this.onChangeAddress = this.onChangeAddress.bind(this)
    this.onChangeMap = this.onChangeMap.bind(this)
  }
  onChangeMap(formData){
    this.setState({geoJSON: formData}, ()=>{
      this.props.onChange(this.state)
      console.log(this.state)
    })
  }
  onChangeAddress(formData){
    this.setState({address: formData}, ()=>{
      this.props.onChange(this.state)
      console.log(this.state)
    })
  }

  render(){
    const {
      uiSchema,
      formData,
      errorSchema,
      idSchema,
      required,
      disabled,
      readonly,
      onBlur,
      registry
    } = this.props;
    const { definitions, fields, formContext } = registry;
    const { SchemaField, TitleField, DescriptionField } = fields;
    const schema = this.props.schema
    var name = 'address'

    return  <fieldset>
            <SchemaField
              name={name}
              schema={schema.properties[name]}
              uiSchema={this.uiSchema[name]}
              errorSchema={errorSchema[name]}
              idSchema={idSchema[name]}
              formData={this.state[name]}
              onChange={this.onChangeAddress}
              onBlur={onBlur}
              registry={registry}
              disabled={disabled}
              readonly={readonly}
            />
            {this.state.address.fias_id && <MapField address={this.state.address} onChange={this.onChangeMap} />}
    </fieldset>
  }
}
