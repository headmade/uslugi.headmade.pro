import React from 'react'
import ReactDOM from 'react-dom'
import DaDataSuggestions from "~/components/inputs/dadata_suggestions";

const organizationField = (props) => {
  return (
    <DaDataSuggestions {...props} type= "PARTY"
      valueFromData={(nextProps)=>{
            return nextProps.formData.value
          }}
      onChange={(suggestion) =>{
        props.onChange({
          value: suggestion.data.inn + ', ' + suggestion.value,
          name: suggestion.unrestricted_value,
          inn: suggestion.data.inn,
          kpp: suggestion.data.kpp,
          ogrn: suggestion.data.ogrn
        })
      }}/>
  )
}
export default organizationField
