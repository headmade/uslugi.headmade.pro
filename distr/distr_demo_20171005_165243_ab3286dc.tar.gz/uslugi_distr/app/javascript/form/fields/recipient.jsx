import React from 'react'
import ReactDOM from 'react-dom'
import update from 'immutability-helper';
import Autosuggest from 'react-autosuggest'
import axios from 'axios'
import '~/components/inputs/agent_autosuggest.css'


class recipientField extends React.Component {

  getSuggestions(value) {
    const inputValue = value.trim().toLowerCase()
    const inputLength = inputValue.length
    if (inputLength < 3){
      this.setState({suggestions: []})
      return
    }
    axios.get("/queries/recipients?q="+inputValue)
      .then((response)=>{
        this.setState({
          suggestions: response.data.data
        })
      })
      .catch((error)=>{
        console.log(error)
        this.setState({suggestions: []})
      })
  }

  getSuggestionValue(suggestion) {
    return suggestion.title
  }

  renderSuggestion(suggestion){
    return (<div>
      <span className="name">
        {suggestion.title}
      </span>
    </div>)

  }
  constructor() {
    super()

    // Autosuggest is a controlled component.
    // This means that you need to provide an input value
    // and an onChange handler that updates this value (see below).
    // Suggestions also need to be provided to the Autosuggest,
    // and they are initially empty because the Autosuggest is closed.
    this.state = {
      suggestions: [],
      value: '',
      item: {}
    }
  }

  onChange(event, { newValue }){
    this.setState({value: newValue})
  }

  onSuggestionSelected(event, { suggestion}){
    event.preventDefault()
    this.setState({item: suggestion, value: ''})
    this.props.onChange(suggestion)
  }

  onSuggestionsFetchRequested({ value }) {
    this.getSuggestions(value)
  }

  onSuggestionsClearRequested (){
    this.setState({
      suggestions: []
    })
  }

  renderInputComponent= (inputProps)=>{
    const { schema, required, id}= this.props
    const {title} = schema
    const {item} = this.state
    return (
      <div>
        <input {...inputProps} />
        <label htmlFor={id}>{title}{required ? "*" : null}</label>
        { item.title &&
          <div>
            <br />
            <h4>Получатель:</h4>
            <p> {item.id} {item.type} {item.title} </p>
          </div>
        }
      </div>
    )
  }

  render() {
    const { suggestions, value} = this.state
    const { formData, schema, label, id, required }= this.props
    // Autosuggest will pass through all these props to the input.
    const inputProps = {
      className: 'form-control',
      //placeholder: 'Type a programming language',
      required: this.props.required,
      value,
      onChange: this.onChange.bind(this)
    }

    // Finally, render it!
    return (
      <Autosuggest
        suggestions={suggestions}
        onSuggestionsFetchRequested={this.onSuggestionsFetchRequested.bind(this)}
        onSuggestionsClearRequested={this.onSuggestionsClearRequested.bind(this)}
        onSuggestionSelected={this.onSuggestionSelected.bind(this)}
        getSuggestionValue={this.getSuggestionValue}
        renderSuggestion={this.renderSuggestion}
        renderInputComponent={this.renderInputComponent}
        inputProps={inputProps}
      />
    )
  }
}

     //<pre>
      //{JSON.stringify(props, null, '  ')}
     //</pre>
export default recipientField
