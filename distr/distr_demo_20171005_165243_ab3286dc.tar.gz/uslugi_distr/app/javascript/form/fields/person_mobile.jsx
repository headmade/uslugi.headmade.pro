import React from 'react'
import ReactDOM from 'react-dom'
import SchemaField from "react-jsonschema-form/lib/components/fields/SchemaField"
import AgentAutosuggest from "~/components/inputs/agent_autosuggest"
import personFioField from '~/form/fields/person_fio'
import update from 'immutability-helper';


class personMobileField extends React.Component {
  constructor(props) {
    super(props)

    this.state = props.formData
    var uiSchema = { passport_number:{
                "ui:field": (props) => {
                  return <AgentAutosuggest {...props} onSelect={(suggestion) =>{
                    props.onChange(suggestion.passport_number)
                    this.setState(update(this.state,
                      {$merge: {
                        fio:{
                          name: suggestion.name,
                          surname: suggestion.surname,
                          patronymic_name: suggestion.patronymic_name,
                        },
                        mobile: suggestion.mobile,
                    }}))
                  }
                  }
                  />
                }
              },
              fio: { "ui:field": personFioField},
    }
    this.newProps = Object.assign({}, props, {"uiSchema": uiSchema})
    this.onChange = this.onChange.bind(this)
  }

  onChange(formData){
    this.setState(formData, ()=>{
      this.props.onChange(this.state)
    })
  }

  render() {
    return <SchemaField {...this.newProps} formData={this.state} onChange={this.onChange}/>
  }
}

export default personMobileField
