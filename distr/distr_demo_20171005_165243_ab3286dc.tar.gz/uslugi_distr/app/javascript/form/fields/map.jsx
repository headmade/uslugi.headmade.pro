import React from 'react'
import 'leaflet/dist/leaflet.css'
import 'leaflet-draw/dist/leaflet.draw.css'

import { Map, CircleMarker, Popup, TileLayer, FeatureGroup, Circle} from 'react-leaflet'
import { EditControl } from "react-leaflet-draw"

class MyFeatureGroup extends FeatureGroup {
  componentDidMount() {
    super.componentDidMount()
    this.props.setFG(this.leafletElement)
  }
}

export default class MapField extends React.Component{

  constructor(props) {
    super(props)
    //console.log(props)
  }

  _onCreate(e) {
    console.log('Path create !', this.el.toGeoJSON(), e.layer.toGeoJSON());
    this.props.onChange(this.el.toGeoJSON())
  }

  componentWillReceiveProps(nextProps){
    //console.log('componentWillReceiveProps', nextProps)
  }

  render(){
    const {address}= this.props
    const {lat, lon} = address.geo_coordinates
    const center = [parseFloat(lat), parseFloat(lon)]
    return (
      <div className="wrapper-map">
        <Map center={center} onClick={this._onMounted} zoom={18} maxZoom={18} style={{width: '500px', height: '300px'}}>
          <TileLayer
            url='http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
            url='http://tiles.maps.sputnik.ru/{z}/{x}/{y}.png'
            attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          />
          <MyFeatureGroup setFG={(el)=>{ this.el = el }}>
            <EditControl
              position='topright'
              onCreated={this._onCreate.bind(this)}
              draw={{
                rectangle: false,
                circle: false,
                circlemarker: false
              }}
            />
          </MyFeatureGroup>
          <CircleMarker center={center} radius={10}>
            <Popup>
              <span>{address.value}</span>
            </Popup>
          </CircleMarker>
        </Map>
        <div className="map-manual">
          <div className="leaflet-touch">
            <div className="leaflet-draw-toolbar">
              <p>Выделите нужную зону на карте с помощью линий - <a className="map-icon leaflet-draw-draw-polyline"></a>, полигона - <a className="map-icon leaflet-draw-draw-polygon"></a>, или поставьте маркер -  <a className="map-icon leaflet-draw-draw-marker"></a>.</p>
              <p>Для редактирования линий и полигона нажмите на - <a className="map-icon leaflet-draw-edit-edit"></a>.</p>
              <p>Для удаления ошибочных данных нажмите на - <a className="map-icon leaflet-draw-edit-remove"></a>.</p>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
