import React from 'react'
import organizationField from '~/form/fields/organization'
import addressField from '~/form/fields/address'
import personFioField from '~/form/fields/person_fio'
import personMobileField from '~/form/fields/person_mobile'
import agentField from '~/form/fields/agent'
import recipientField from '~/form/fields/recipient'
import addressWithMapField from '~/form/fields/address_with_map'
import Form from "react-jsonschema-form"
import FileWidget from '~/form/widgets/file_widget'

import '~/components/Math.uuid'

const ERROR_TYPE = {
  base: title => `в поле ${title} ошибка`,
  required: title => `поле ${title} не может быть пустым`,
  format: title => `поле ${title} имеет некорректный формат`,
  type: title => `поле ${title} имеет некорректный тип`,
  oneOf: title => `поле ${title} имеет некорректный тип (oneOf)`,
}

export default class UIForm extends React.Component {
  constructor(props){
    super(props)
    this.state = {formData: props.formData }
    this.formContext = {guid: Math.uuid()}
    this.uiSchema = {
      agent: {"ui:field": "agent"},
      recipient: {"ui:field": "recipient"},
      organization: {"ui:field": "organization"},
      customer_responsible: {"ui:field": "person_fio" },
      contractor_organization: {"ui:field": "organization"},
      contractor_responsible: {"ui:field": "person_mobile"},
      subcontractor_organization: {"ui:field": "organization"},
      subcontractor_responsible: {"ui:field": "person_mobile"},
      regulator_organization: {"ui:field": "organization"},
      related_organizations:{items: {"ui:field": "organization"}},
      address: {"ui:field": "address"},
      address_with_map: {"ui:field": "address_with_map"},
      lease_contracts: {
        items: {
          landlord_persons: {items: {"ui:field": "person_fio"}},
          landlord_organizations: {items: {"ui:field": "organization"}},
          tenant: {"ui:field": "organization"}
        },
      },
      address_comments: {"ui:widget": "textarea"},
      comments: {"ui:widget": "textarea"},
      response_text: {"ui:widget": "textarea"},
      query_text: {"ui:widget": "textarea"},

      objects_of_work: {
        items: {
          types_of_work: {"ui:widget": "checkboxes"},
        }
      },
      objects_of_work_comments: {"ui:widget": "textarea"},

      work_directions_road: {"ui:widget": "checkboxes"},
      work_directions_road_sidewalk: {"ui:widget": "checkboxes"},
      work_directions_road_green: {"ui:widget": "checkboxes"},
      work_directions_local_road: {"ui:widget": "checkboxes"},
      work_directions_local_road_green: {"ui:widget": "checkboxes"},
      work_directions_green: {"ui:widget": "checkboxes"},
      work_directions_sidewalk: {"ui:widget": "checkboxes"},
      work_directions_sidewalk_green: {"ui:widget": "checkboxes"},
      work_directions_gnb: {"ui:widget": "checkboxes"},
      work_directions_comments: {"ui:widget": "textarea"},
      external_system_request_types: {"ui:widget": "checkboxes"},
      reject_reasons: {"ui:widget": "checkboxes"},
      cadastre_number: {"ui:description": "Кадастровый номер в виде число:число:число..."},
    }

    // TODO: move to some config?
    this.fields = {
      "person_fio": personFioField,
      "person_mobile": personMobileField,
      "agent": agentField,
      "recipient": recipientField,
      "organization": organizationField,
      "address": addressField,
      "address_with_map": addressWithMapField
    }

    this.widgets = {
      FileWidget: FileWidget
    }
    this.onChange = this.onChange.bind(this)
  }
  onChange(event){
    this.setState({"formData": event.formData}, ()=>{
      this.props.onChange && this.props.onChange(this.state.formData)
    })
  }

  errorMessage(name, title) {
    console.log(name, title)
    const errorType = typeof ERROR_TYPE[name] === 'function' ? ERROR_TYPE[name] : ERROR_TYPE['base']
    return errorType(title)
  }


  transformErrors = (errors)=>{
    return errors.map((error) => {
      const name = error.name
      const title = error.schema.title
      return {
        ...error,
        stack: this.errorMessage(name, title),
        message: this.errorMessage(name, title),
      }
    })
  }

  customFieldTemplate(props) {
    const {id, classNames, label, help, required, description, errors, children} = props
    let description_text = description.props.description
    // let errors_text = errors.props.errors
    return (
      <div className={classNames + " input-wrapper"}>
        {children}
        <label htmlFor={id}>{label}{required ? "*" : null}</label>
        {description_text &&
          <div>
            <div className={"info-tooltip"}>?</div>
            <div className={"info-tooltip-content"}>{description_text}</div>
          </div>
        }
        {errors}
        {help}
      </div>
    )
  }

  onKeyPress(event){
    if(event.key == 'Enter'){
      event.preventDefault()
      event.stopPropagation()
      const form = event.target.form
      let i = Array.prototype.indexOf.call(form, event.target)
      for(let el = form.elements[++i]; el; el=form.elements[++i]) {
        if (el.tagName == 'INPUT' || el.tagName == 'TEXTAREA') {
          el.focus()
          return
        }
      }
    }
  }

  render(){
    return (
      <div onKeyPress={this.onKeyPress}>
      <Form
        {...this.props}
        noHtml5Validate={true}
        showErrorList={false}
        transformErrors={this.transformErrors}
        onSubmit={this.props.onSubmit}
        widgets={this.widgets}
        fields={this.fields}
        schema={this.props.schema}
        uiSchema={this.uiSchema}
        onChange={this.onChange}
        formData={this.state.formData}
        formContext={this.formContext}
        FieldTemplate={this.customFieldTemplate}
      />
    </div>
    )
  }
}
