import React from 'react'
import Form from "react-jsonschema-form"
import Agent from '~/components/show/agent'
import Organization from '~/components/show/organization'
import Address from '~/components/show/address'
import AdderesWithMap from '~/components/show/map'
import OriginalArrayField from 'react-jsonschema-form/lib/components/fields/ArrayField'
import {Col, Row, Thumbnail} from 'react-bootstrap'
import AnyOfField from './show/fields/any_of'
import FileWidget from './show/widgets/file_widget'

export default class ShowForm extends React.Component {
  constructor(props){
    super(props)
    if (props.short){
      this.fields = {
        "address": (props)=>{
          return (
            <div className='form-group field field-string'>
              <label>{props.schema.title}</label>
              <p>{props.formData.value}</p>
            </div>
          )
        }
      }
    }else{
      this.fields = {
        "agent": (props)=>{
          return <Agent agent={props.formData} />
        },
        "organization": (props)=>{
          return <Organization inn={props.formData.inn} />
        },
        "address": (props)=>{
          return <Address address={props.formData} />
        }
      }
    }
    this.fields = {
      ...this.fields,
      ArrayField: (props)=>{
        var {uiSchema} = props
        uiSchema['ui:options'] = {addable: false, removable: false, orderable: false}
        return <OriginalArrayField {...props} uiSchema={uiSchema} />
      },
      "address_with_map": (props)=>{
        return <AdderesWithMap object={props.formData} />
      },
      "any_of": AnyOfField
    }
    this.uiSchema = {
      anyOf:{ "ui:field": "any_of" },
      agent:{ "ui:field": "agent" },
      organization: {"ui:field": "organization"},
      address: { "ui:field": "address"},
      address_with_map:{ "ui:field": "address_with_map"}
    }

    this.widgets = {
      TextWidget: (props)=>{
        return <p>{props.value}</p>
      },
      EmailWidget: (props)=>{
        return <a href={"email:"+props.value}>{props.value}</a>
      },
      FileWidget: FileWidget,
      DateWidget: (props)=>{
        return <p>{props.value}</p>
      },
      SelectWidget: (props) =>{
        return <p>{props.value}</p>
      },
      CheckboxWidget: (props) =>{
        return <p className="checkbox-caption-show">{props.label}: <span>{props.value ? 'да':'нет'}</span></p>
      }
    }
  }


  render(){
    return (
      <Form
        className="show-form"
        {...this.props}
        fields={this.fields}
        widgets={this.widgets}
        uiSchema={this.uiSchema}
      >
        <br />
      </Form>
    )
  }
}
//const mapStateToProps = (state, ownProps) => {
    //const passport = state.servant_passports.find((elm)=>{return elm.id == ownProps.passport_id})
  //return {
    //passport: passport,
    //schema: prepareSchema(passport && passport.data && passport.data.usluga && passport.data.usluga.schema || defaultSchema)
  //}
//}

//const mapDispatchToProps = (dispatch) => {
  //return {}
//}

//export default connect(mapStateToProps, mapDispatchToProps)(ShowForm)
