import definitions from './definitions'

export default function prepareSchema(schema){
  return Object.assign({}, schema, {definitions: definitions})

  // TODO: search recursively for definitions
  //var defs = {}
  //for(var key in schema.properties){
    //var property = schema.properties[key]
    //if(property["$ref"]){
      //var arr = property["$ref"].split("/")
      //var def_key = arr[arr.length-1]
      //defs[def_key] = definitions[def_key]
    //}
  //}
  //schema['definitions'] = defs
  //return schema
}
