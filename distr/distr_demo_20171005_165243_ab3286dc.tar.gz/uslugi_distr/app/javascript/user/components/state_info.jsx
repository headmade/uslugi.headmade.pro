import React from 'react'
import { dateTimeFormatter } from '~/components/formatters/date'
import {Panel} from 'react-bootstrap'
import { connect } from 'react-redux'
import { Sign as SignComponent } from '~/components/show/sign'
import Inspector from 'react-inspector'

const Base = (props)=>{
  const {isDebug, object} = props
}

const Reject = (props)=>{
  const {isDebug, object, children} = props
  return <div>
    <h5>Причина отказа</h5>
    <ul>
      {object.reject_data.reject_reasons.map((reason, i)=>{
        return <li key={i}>{reason}</li>
      })}
    </ul>
    { object.reject_data.response_text&&
      <p>Информация для заявителя: {object.reject_data.response_text}</p>
    }
    {children}
  </div>
}

const RejectSigned = (props)=>{
  const {isDebug, object} = props
  return <Reject {...props}>
    <SignComponent object={object} />
    <p><a className='btn btn-info' href={`/api/user/uslugas/${object.id}.pdf`} target='_blank'>Скачать подписанный документ</a></p>
  </Reject>
}

const mapStateToComponent = {
  base: Base,
  rejected_signed: RejectSigned,
  rejected: Reject
  //complete: Complete,
  //assign: Complete,
}

const mapStateToProps = ({isDebug})=>({isDebug})
@connect(mapStateToProps)
export default class StateInfo extends React.Component {
  render(){
    const {isDebug, object} = this.props
    return <Panel bsStyle={object.state.style} header={`${object.state.name}`}>
      { isDebug && <Inspector data={object} /> }
      {mapStateToComponent[object.state.key] ?
          mapStateToComponent[object.state.key]({isDebug, object}):
          mapStateToComponent['base']({isDebug, object})
      }
    </Panel>
  }
}
