import React, {Component} from 'react'

export default class BaseCaption extends Component {

  render() {
    return (
      <h2 className={`base-caption base-caption--${this.props.position}`} >{this.props.title}</h2>
    )
  }
}
