import React from 'react'
import {connect} from 'react-redux'
import UserList from '~/routing/passports/user_list'
import PopularServices from './popular_services'

class UserDashbord extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return <div>
      <PopularServices/>
    </div>
  }
}

//<Row><Col xs={12}><UserList/></Col></Row>
export default UserDashbord
