import React, {Component} from 'react'
import {Link} from 'react-router-dom'
import {Row, Col} from 'react-bootstrap'
import ServiceCaption from './service/caption'
import ServiceCaptionDetail from './service/caption_detail'
import ServiceLinks from './service/links'
import ServiceQuest from './service/quest'
import ServiceQuestion from './service/question'
import ServiceDetail from './service/detail'

export default class Service extends Component {
  render() {
    const {passport} = this.props
    return (
      <div className="service-wrapper">
        <Row>
          <Col xs={12}>
            <ServiceCaption name={passport.name}/>
            <Link className="myBtn arrow-right-btn" to={`/passports/${passport.id}/usluga_requests/new`}>
              Получить услугу
            </Link>
            {
              //<ServiceLinks/>
              //<ServiceCaptionDetail/>
              //<ServiceQuest/>
            }
            <ServiceQuestion/>
            <ServiceDetail/>
          </Col>
        </Row>
      </div>
    )
  }
}
