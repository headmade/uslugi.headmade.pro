import React, {Component} from 'react'
import {Row, Col} from 'react-bootstrap'
import {connect} from 'react-redux'
import {Link} from 'react-router-dom'
import chunks from 'array.chunk'
import BaseCaption from './base_caption'

//import List25621 from '~/images/list256-21.svg'
import List25624 from '~/images/list256-24.svg'
// import InlineSVG from 'svg-inline-react'
//import List25658 from '~/images/list256-58.svg'

const mapStateToProps = ({servant_passports}) => ({servant_passports})

@connect(mapStateToProps)
export default class PopularServices extends Component {
  render() {
    return (
      <div className="popular-services-wrapper">
        <Row>
          <Col xs={12}>
            <BaseCaption title="Популярные услуги" position="center" />
            {chunks(this.props.servant_passports, 3).map((chunk, index) => {
                return (// eslint-disable-next-line
                  <div key={index} className="popular-services__items-wrapper">
                    {chunk.map((passport) => (
                      <Link key={passport.id} className="popular-services" to={`/passports/${passport.id}`}>
                        <div className="popular-services__img-wrapper">
                          {/*<img src={require("svg-inline-loader!images/list256-24.svg")} />*/}
                          <img src={List25624} alt="Services"/>
                        </div>
                        <div className="popular-services__info">
                          <h4 className="popular-services__name">{passport.name}</h4>
                          <p className="popular-services__act">Подайте заявление онлайн<span>&gt;</span></p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )
              }
            )}
            <div className="myBtn-wrapper">
              <a className="myBtn arrow-right-btn">Все услуги</a>
            </div>
          </Col>
        </Row>
      </div>
    )
  }
}
