import React from 'react'
import {connect} from 'react-redux'
import {Navbar, Nav, NavDropdown, MenuItem, Grid, Row, Col, Clearfix, NavItem} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap'
import {Link} from 'react-router-dom'
import LogoImg from '~/images/Zilant.svg'
import DropdownUser from '~/components/dropdown_user'
import NavIndexUser from './nav_index_user'

import {Sticky} from 'react-sticky'

export class UserTopMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isToggleOn: true
    };

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    this.setState(prevState => ({
      isToggleOn: !prevState.isToggleOn
    }));
  }

  render() {
    const {current_user, title} = this.props
    return (
      <Sticky>
        {({style}) => {
          return (
            <div className="MySticky" style={{...style, height: 80}}>
              <div className="nav-wrapper">
                <Grid>
                  <Row>
                    <Col xs={12}>
                      <ul className="nav-list">
                        <li className="nav-list__item nav-list__item-logo">
                          <Link to="/">
                            <span className="banner-logo">{title.prefix}<span>{title.suffix}</span></span>
                          </Link>
                        </li>
                          <ul className={'nav-list__items ' + (this.state.isToggleOn ? '' : 'nav-list__items_active')}>
                            <li className="nav-list__item">
                              <Link to="/usluga_requests">Мои заявления</Link>
                            </li>
                            <li className="nav-list__item">
                              <Link to="/uslugas">Мои услуги</Link>
                            </li>
                            <NavIndexUser/>
                          </ul>
                          <div className="hamburger-wrapper">
                            <button className={'c-hamburger c-hamburger--htx ' + (this.state.isToggleOn ? '' : 'is-active')} onClick={this.handleClick}><span>toggle men</span></button>
                         </div>
                      </ul>
                    </Col>
                  </Row>
                </Grid>
              </div>
            </div>
          )
        }
        }
      </Sticky>
    )
    return <Navbar className="main-nav">
      <Navbar.Header>
        <Navbar.Brand>
          <Link to="/" className="brand-img">
            <img src={LogoImg} style={{height: "30px"}}/>
          </Link>
        </Navbar.Brand>
        <Navbar.Brand>
          <Link to="/">
            ИС УСЛУГИ
          </Link>
        </Navbar.Brand>
      </Navbar.Header>
      <Nav>
        <LinkContainer to="/uslugas">
          <NavItem eventKey={2}>Оказанные услуги</NavItem>
        </LinkContainer>
      </Nav>
      {current_user && current_user.current_user &&
      <Nav pullRight>
        <NavDropdown className="main-nav" eventKey={5} title={current_user.current_user.phone} id="basic-nav-dropdown">
          <DropdownUser/>
        </NavDropdown>
      </Nav>
      }
    </Navbar>
  }
}

const mapStateToProps = (state) => {
  return {
    registries: state.registries,
    current_user: state.current_user
  }
}

const mapDispatchToProps = (dispatch) => {
  return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(UserTopMenu)
