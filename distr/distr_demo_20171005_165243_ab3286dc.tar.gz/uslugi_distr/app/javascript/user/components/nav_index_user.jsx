import React, { Component } from 'react'

import { connect } from 'react-redux'

const mapStateToProps = ({current_user}) => ({current_user})

@connect(mapStateToProps)
export default class NavIndexUser extends Component {
    render() {
        return(
            <li className="nav-list__item nav-index-user"><a className="nav-index-user__caption">{this.props.current_user.current_user.title}</a>
                <ul className="nav-index-user__dropdown">
                  <li className="nav-index-user__dropdown-item"><a href="/session/logout">Выход</a></li>
                </ul>
            </li>
        )
    }
}
