import React, { Component } from 'react'
import List25624 from '~/images/list256-24.svg'
import BaseCaption from '../base_caption'

export default class ServiceCaption extends Component {
    render() {
        const { name } = this.props
        return(
            <div className="service-caption">
                <div className="popular-services__img-wrapper">
                    <img src={List25624} alt="Services"/>
                </div>
                <BaseCaption title={name} position="center" />
            </div>
        )
    }
}
