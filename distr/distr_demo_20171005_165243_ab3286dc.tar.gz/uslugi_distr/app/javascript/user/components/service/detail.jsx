import React, { Component } from 'react'
import {Accordion, Panel } from 'react-bootstrap'


export default class ServiceDetail extends Component {
    render() {
        function handleClick(e) {
            e.preventDefault();
            const openAll = document.querySelectorAll('.panel-title a');
            const openAll2 = document.querySelectorAll('.panel-collapse');
            const openAllBtn = document.querySelector('.service-detail__open-all');
            openAllBtn.textContent = openAllBtn.textContent === 'Открыть все' ? 'Скрыть все' : 'Открыть все';
            for (let i = 0; i < openAll.length; i++) {
                openAll[i].classList.toggle('collapsed');
            }
            for (let i = 0; i < openAll2.length; i++) {
                openAll2[i].classList.toggle('in');
            }
        }
        return(
            <div className="service-detail">
                <button className="service-detail__open-all" onClick={handleClick}>Открыть все</button>
                <h2 className="catalog-services__caption">Описание услуги</h2>
                <hr/>
                <div className="service-detail__block">
                    <Accordion>
                        <Panel className="serv" header="Как получить услугу" eventKey="1" >
                            {/*<h4 className="service-detail-block-caption">Как получить услугу</h4>*/}
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Способы подачи заявки</p>
                                <span className="service-detail__group-text">Лично</span>
                            </div>
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Способы получения результата</p>
                                <span className="service-detail__group-text">Лично</span>
                            </div>
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Адрес предоставления в электроннов виде</p>
                                <a href="#" className="service-detail__group-text-link">https://guvm.mvd.ru/gosuslugi/item/12891/</a>
                            </div>

                        </Panel>
                        <Panel header="Как получить услугу" eventKey="2">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                        <Panel header="Как получить услугу" eventKey="3">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                    </Accordion>
                    <hr/>
                </div>
                <h2 className="catalog-services__caption">Документы</h2>
                <hr/>
                <div className="service-detail__block">
                    <Accordion>
                        <Panel header="Как получить услугу" eventKey="1" >
                            {/*<h4 className="service-detail-block-caption">Как получить услугу</h4>*/}
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Способы подачи заявки</p>
                                <span className="service-detail__group-text">Лично</span>
                            </div>
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Способы получения результата</p>
                                <span className="service-detail__group-text">Лично</span>
                            </div>
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Адрес предоставления в электроннов виде</p>
                                <a href="#" className="service-detail__group-text-link">https://guvm.mvd.ru/gosuslugi/item/12891/</a>
                            </div>
                        </Panel>
                        <Panel header="Как получить услугу" eventKey="3">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                        <Panel header="Как получить услугу" eventKey="4">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                        <Panel header="Как получить услугу" eventKey="5">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                    </Accordion>
                    <hr/>
                </div>
                <h2 className="catalog-services__caption">Дополнительная информация</h2>
                <hr/>
                <div className="service-detail__block">
                    <Accordion>
                        <Panel header="Как получить услугу" eventKey="1" >
                            {/*<h4 className="service-detail-block-caption">Как получить услугу</h4>*/}
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Способы подачи заявки</p>
                                <span className="service-detail__group-text">Лично</span>
                            </div>
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Способы получения результата</p>
                                <span className="service-detail__group-text">Лично</span>
                            </div>
                            <div className="service-detail__group">
                                <p className="service-detail__group-caption">Адрес предоставления в электроннов виде</p>
                                <a href="#" className="service-detail__group-text-link">https://guvm.mvd.ru/gosuslugi/item/12891/</a>
                            </div>
                        </Panel>
                        <Panel header="Как получить услугу" eventKey="2">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                        <Panel header="Как получить услугу" eventKey="3">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                        <Panel header="Как получить услугу" eventKey="5">
                            <h4 className="service-detail-block-caption">Как получить услугу</h4>
                            <p className="service-detail-block-caption">Как получить услугу</p>
                            <span>212</span>
                        </Panel>
                    </Accordion>
                    <hr/>
                </div>
            </div>
        )
    }
}
