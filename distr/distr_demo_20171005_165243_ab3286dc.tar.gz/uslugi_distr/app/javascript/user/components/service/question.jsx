import React, { Component } from 'react'

export default class ServiceQuestion extends Component {
    render() {
        return(
            <div className="service-question">
                <div className="service-question__info">
                    <h4 className="service-question__info-date">Сроки оказания услуги</h4>
                    <p className="service-question__info-text">В соответствии с регламентом</p>
                </div>
                <div className="service-question__info">
                    <h4 className="service-question__info-price">Стоимость услуги</h4>
                    <p className="service-question__info-text">Услуга предоставляется бесплатно</p>
                </div>
                <ul className="service-question__list">
                    <li className="service-question__list-item_caption">Как получить услугу?</li>
                    <li className="service-question__list-item">в электронном виде</li>
                    <li className="service-question__list-item">сдать документы лично</li>
                </ul>
            </div>
        )
    }
}
