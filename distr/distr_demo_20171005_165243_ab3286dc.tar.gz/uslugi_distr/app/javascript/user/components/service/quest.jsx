import React, { Component } from 'react'

export default class ServiceQuest extends Component {
    render() {
        return(
            <div className="service-quest">
                <ul className="service-quest__list-tip">
                    <li className="service-quest__list-tip-item_caption"><span> </span>Выберите тип получения услуги?</li>
                    <li className="service-quest__list-tip-item">
                        <input className="service-quest__list-tip-input" type="radio" id="service-quest__radio-internet" name="service-quest__radio" defaultChecked={true}/>
                        <label className="service-quest__list-tip-label" htmlFor="service-quest__radio-internet">Электронная услуга</label>
                    </li>
                    <li className="service-quest__list-tip-item">
                        <input className="service-quest__list-tip-input" type="radio" id="service-quest__radio-onFoot" name="service-quest__radio"/>
                        <label className="service-quest__list-tip-label" htmlFor="service-quest__radio-onFoot">Личное посещение</label>
                    </li>
                </ul>
                <ul className="service-quest__list">
                    <li className="service-quest__list-item_caption"><span>1</span><a href="#">Заполните личные данные</a> и дождитесь автоматической проверки</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                </ul>
                <ul className="service-quest__list">
                    <li className="service-quest__list-item_caption"><span>2</span><a href="#">Заполните личные данные</a> и дождитесь автоматической проверки</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                </ul>
                <ul className="service-quest__list service-quest__list-action">
                    <li className="service-quest__list-item_caption service-quest__list-item_caption-action"><span>3</span><a href="#">Заполните личные данные</a> и дождитесь автоматической проверки</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                    <li className="service-quest__list-item">Обычно это занимает несколько минут</li>
                </ul>
                <ul className="service-quest__list-last">
                    <li className="service-quest__list-item_caption-last"><span> </span>Получите уведомление о постановке ребенка в очередь на зачисление</li>
                    <li className="service-quest__list-item">уведомление вы получите по контактным данным, указанным вами в заявление</li>
                </ul>
            </div>
        )
    }
}