import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import BigCalendar from 'react-big-calendar';
import moment from 'moment';
BigCalendar.setLocalizer(
  BigCalendar.momentLocalizer(moment)
);

export default class Subscribe extends React.Component {
  constructor(props) {
    super(props)
    this.events = [{
                  'title': 'Запись#1',
                  'start': new Date(2017, 5, 23, 9, 30, 0),
                  'end': new Date(2017, 5, 23, 10, 0, 0)},
      ]

    this.state = {
      passport: {},
      events: this.events}
    axios.get("/passports/"+props.match.params.id+".json")
      .then((response)=>{
        console.log(response)
        this.setState({passport: response.data})
      })
      .catch((error)=>{
        console.log(error)
      })
    this.onSelectSlot = this.onSelectSlot.bind(this)
  }
  onSelectSlot(slotInfo){
    this.setState({events: this.events.concat([{title: "Ваша запись", start: slotInfo.start, end: slotInfo.end}])})
  }

  render (){
    console.log(this.state)
    return (
      <div className="row">
        <div className="col-xs-12">
          <div className="row">
            <div className="col-xs-12">
              <h1>{this.state.passport.name}</h1>
              <Link to={"/services/"+this.state.passport.id}>
                К услуге
              </Link>
            </div>
          </div>
          <div className="row">
            <div className="col-xs-12">
              <hr />
              <BigCalendar
                {...this.props}
                selectable
                views={['week']}
                defaultView='week'
                culture='ru'
                events={this.state.events}
                min={new Date(2017, 1, 1, 9, 0, 0, 0)}
                max={new Date(2017, 1, 1, 18, 0, 0, 0)}
                step={15}
                defaultDate={new Date(Date.now())}
                onSelectSlot={this.onSelectSlot}
                onSelecting ={()=> false}
              />
            </div>
          </div>
        </div>
      </div>
    )
  }

}
