import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'

export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {passports: []}
    this.get_passports()
  }
  get_passports() {
    axios.get("/api/passports.json")
      .then((response)=>{
        console.log(response)
        this.setState({passports: response.data.data})
      })
      .catch((error)=>{
        console.log(error)
      })
  }
  render (){
    return <ul>{this.state.passports.map((passport)=>
      <li key={passport.id}>
        <Link to={"/services/"+passport.id}>{passport.name}</Link>
      </li>
    )}</ul>
  }

}
