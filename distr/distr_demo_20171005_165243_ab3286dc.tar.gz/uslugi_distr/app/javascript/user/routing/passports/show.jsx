import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom'
import Service from '../../components/service'

export class Show extends React.Component {
  static propTypes = {
    passport: PropTypes.shape({
      name: PropTypes.string,
      id: PropTypes.number,
      description: PropTypes.string,
      documents: PropTypes.string,
    })
  }

  componentWillMount(props){
     if (!this.props.passport) {
       this.props.history.push('/')
     }
   }

  render (){
    const {passport} = this.props
    return (
      <Service passport={passport}/>
    )
    return (
      <div className="row">
      { passport &&
        <div className="col-xs-12">
          <div className="row">
            <div className="col-xs-12">
              <h1>{passport.name}</h1>
              <Link to={"/services/"+passport.id+"/new"}>
                <button type="button" className="btn btn-primary">
                  <span className="glyphicon glyphicon-pencil" aria-hidden="true"></span> Начать прием
                </button>
              </Link>
            </div>
          </div>
          <div className="row">
            <div className="col-xs-12">
              <hr />
              <p dangerouslySetInnerHTML={{__html:passport.description}} />
              <hr />
              <p dangerouslySetInnerHTML={{__html:passport.documents}} />
            </div>
          </div>
        </div>
      }
      </div>
    )
  }

}


const mapStateToProps = (state, ownProps) => {
  return {passport: state.servant_passports.find((elm)=>{return elm.id == ownProps.match.params.id})}
}

const mapDispatchToProps = (dispatch) => {
  return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(Show)
