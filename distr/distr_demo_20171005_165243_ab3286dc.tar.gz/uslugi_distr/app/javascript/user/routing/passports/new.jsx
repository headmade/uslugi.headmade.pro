import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import axios from 'axios'
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from 'react-router-dom'
import { Button } from 'react-bootstrap'
import defaultSchema from '~/form/default_schema'
import prepareSchema from '~/form/prepare_schema'
import UIForm from '~/form/ui_form'

export class New extends React.Component {
  componentWillMount(props){
    this.props.passport && this.setState({formData: {passport_id: this.props.passport.id}})
    this.props.last_usluga_request && this.setState({formData: {agent: this.props.last_usluga_request.data.agent}})
  }
  //componentWillReceiveProps(props){
    //props.last_usluga_request && this.setState({formData: {agent: props.last_usluga_request.data.agent}})
  //}
  constructor(props) {
      super(props)
      this.state = {created_at: Date.now(), estimated_to_complete_at: Date.now() + 15*60000.0}
      this.onSubmit = this.onSubmit.bind(this)
  }

  onSubmit(event) {
    var formData = event.formData
    formData["passport_id"] =  this.props.passport.id
    formData["created_at"] =  this.state.created_at
    formData["estimated_to_complete_at"] =  this.state.estimated_to_complete_at
    axios.post("/usluga_requests.json", {"usluga_request": {data: formData}})
      .then((response)=>{
        this.props.addUslugaRequest(response.data)
        this.props.setLastUslugaRequest(response.data)
        this.props.history.push('/usluga_requests/'+response.data.id)
      })
      .catch((error)=>{
        console.log(error)
      })
  }

  render (){
    const {formData} = this.state;
    const {passport, schema} = this.props
    return (
      <div className="row">
        { passport && schema &&
        <div className="col-xs-12">
          <h3>{passport.name}</h3>
          <div className="row">
            <div className="col-xs-12">
              <UIForm onSubmit={this.onSubmit} schema={schema} formData={formData} >
                <Button bsStyle="success" bsSize="large" type="submit">Зарегистрировать</Button>
              </UIForm>
            </div>
          </div>
        </div>
        }
      </div>
    )
  }

}

const mapStateToProps = (state, ownProps) => {
  var passport = state.servant_passports.find((elm)=>{return elm.id == ownProps.match.params.id})
  return {
    "passport": passport,
    schema: prepareSchema(passport && passport.data && passport.data.usluga_request && passport.data.usluga_request.schema || defaultSchema),
    last_usluga_request: ownProps.match.params.last ? state.last_usluga_request : null
  }
}

const mapDispatchToProps = (dispatch) => {
  return { addUslugaRequest: (request)=>{
    dispatch({type: "SAVE_USLUGA_REQUEST", usluga_request: request})
  },
    setLastUslugaRequest: (request)=>{
      dispatch({type: "SET_LAST_USLUGA_REQUEST", usluga_request: request})
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(New)
