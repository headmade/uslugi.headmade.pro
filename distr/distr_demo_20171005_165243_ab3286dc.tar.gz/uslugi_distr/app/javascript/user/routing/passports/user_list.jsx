import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import axios from 'axios'
import ServantList from './servant_list'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import durationFormatter from '~/components/formatters/duration'

export class UserList extends ServantList {

  linkFormatter(cell, row){
    return <div>
      <Link to={"/services/"+cell}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Описание услуги
        </button>
      </Link>
      &nbsp;
      <Link to={"/passports/"+cell+"/uslugas/new"}>
        <button type="button" className="btn btn-warning">
          <span className="glyphicon glyphicon-folder-open" aria-hidden="true"></span> Приём документов
        </button>
      </Link>
    </div>
  }

  render (){
    return <BootstrapTable data={ this.props.servant_passports } options={ { noDataText: 'This is custom text for empty data' } }>
          <TableHeaderColumn dataField='id' dataSort isKey hidden >ID</TableHeaderColumn>
          <TableHeaderColumn dataField='name' dataSort >Услуга</TableHeaderColumn>
          <TableHeaderColumn dataField='id' dataFormat={this.linkFormatter}>Действия</TableHeaderColumn>
      </BootstrapTable>
  }
}

const mapStateToProps = (state) => {
  return {servant_passports: state.servant_passports}
}

const mapDispatchToProps = (dispatch) => {
  return {}
}
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserList)

