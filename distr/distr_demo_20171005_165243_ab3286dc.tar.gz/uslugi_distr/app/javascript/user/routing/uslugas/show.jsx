import React from 'react'
import PropTypes from 'prop-types'
//import { connect } from 'react-redux'
import axios from 'axios'
import Passport from '~/components/show/passport'
import defaultSchema from '~/form/default_schema'
import prepareSchema from '~/form/prepare_schema'
import ShowForm from '~/form/show_form'
import {Well, Tabs, Tab, Row, Col} from 'react-bootstrap'
import connect from 'react-redux-fetch'
import Inspector from 'react-inspector'
import StateInfo from '~/user/components/state_info'
import Loader from '~/components/loader'

const mapStateToProps = ({servant_passports, isDebug})=>({servant_passports, isDebug})

@connect([{
  resource: 'usluga',
  request: (id) =>({
    url: `/api/user/uslugas/${id}`,
    })
}],mapStateToProps)

export default class Show extends React.Component {
  static propTypes = {
    dispatchUslugaGet: PropTypes.func.isRequired,
    uslugaFetch: PropTypes.object
  }

  componentWillMount() {
    this.dispatchUslugaGet()
  }

  dispatchUslugaGet = ()=>{
    this.props.dispatchUslugaGet(this.props.match.params.id)
  }

  getSchema(passport_id){
   const passport = this.props.servant_passports.find((elm)=>{return elm.id == passport_id})
   return prepareSchema(passport && passport.data && passport.data.usluga && passport.data.usluga.schema || defaultSchema)
  }

  render (){
    const {uslugaFetch, isDebug} = this.props
    const usluga = uslugaFetch.value
    if (!uslugaFetch.fulfilled) {
      return <Loader />
    }
    return (<div>
      <Well>
        <Row>
          <Col md={12}>
            <StateInfo object={usluga}/>
          </Col>
        </Row>
        <Row>
          <Col md={12}>
            <Passport id={usluga.passport_id} />
            <ShowForm formData={usluga.request_data} schema={this.getSchema(usluga.passport_id)} />
          </Col>
        </Row>
        { isDebug && <Inspector data={usluga} /> }
      </Well>
      <br />
    </div>)
  }
}

