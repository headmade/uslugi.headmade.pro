import React from 'react'
import { Route } from 'react-router-dom'

import * as Passports from './passports'
import * as UslugaRequests from './usluga_requests'
import * as Uslugas from './uslugas'
import * as Agents from '~/routing/agents'
import * as CultureObjects from '~/routing/registries/culture_objects'
import * as Registries from '~/routing/registries'
import Dashbord from '../components/dashbord'

export default class Routes extends React.Component{
  render(){
    return (
      <div className="container">
        <Route exact path="/" component={Dashbord}/>
        <Route exact path="/passports/:id" component={Passports.Show}/>
        <Route exact path="/passports" component={Passports.Index}/>
        <Route path="/services/:id/subscribe" component={Passports.Subscribe}/>
        <Route exact path="/services/:id/new" component={Passports.New}/>
        <Route path="/services/:id/new/:last" component={Passports.New}/>
        <Route exact path="/usluga_requests/:id" component={UslugaRequests.Show}/>
        <Route exact path="/usluga_requests" component={UslugaRequests.Index}/>
        <Route exact path="/uslugas" component={Uslugas.Index}/>
        <Route exact path="/uslugas/:id" component={Uslugas.Show}/>
        <Route exact path="/passports/:passport_id/usluga_requests/new" component={UslugaRequests.New}/>
      </div>
    )
  }
}
