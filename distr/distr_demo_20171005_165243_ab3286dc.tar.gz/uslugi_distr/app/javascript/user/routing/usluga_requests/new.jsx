import React from 'react'
import PropTypes from 'prop-types'
import axios from 'axios'
import { Grid, Row, Col } from 'react-bootstrap'
import ServiceCaption from '~/user/components/service/caption'
import {defaultSchema} from '~/form/default_schema'
import defaultUiSchema from '~/form/default_ui_schema'
import prepareSchema from '~/form/prepare_schema'
import prepareUiSchema from '~/form/prepare_ui_schema'
import UIForm from '~/form/ui_form'
import connect from 'react-redux-fetch'
import Loader from '~/components/loader'

@connect([{
  resource: 'passport',
  request: (id) =>({
    url: `/api/user/passports/${id}`
    })
}])

export default class New extends React.Component {
  static propTypes = {
    dispatchPassportGet: PropTypes.func.isRequired,
    passportFetch: PropTypes.object
  }

  static defaultProps = {
    passportFetch: {value:{data:[], meta:{}}}
  }

  constructor(props) {
    super(props)
    this.state = {formData:{}}
    this.onSubmit = this.onSubmit.bind(this)
  }

  componentWillMount() {
    this.props.dispatchPassportGet(this.props.match.params.passport_id)
  }

  onSubmit(event) {
    var formData = event.formData
    axios.post("/usluga_requests.json", {"usluga_request": {passport_id: this.props.passportFetch.value.id, data: formData}})
      .then((response)=>{
        this.props.history.push('/usluga_requests/'+response.data.id)
      })
      .catch((error)=>{
        console.log(error)
      })
  }

  render (){
    if (!this.props.passportFetch.fulfilled) {
      return <Loader />
    }
    const {formData} = this.state
    const passport = this.props.passportFetch.value
    const usluga = passport && passport.data && passport.data.usluga
    const schema = prepareSchema(usluga && usluga.schema || defaultSchema)
    const uiSchema = prepareUiSchema(usluga && usluga.ui_schema || defaultUiSchema)
    return(
      <div className="service-wrapper">
        <Grid>
          <Row>
            <Col xs={12}>
              <ServiceCaption name={passport.name} />
              <UIForm onSubmit={this.onSubmit} schema={schema} formData={formData} uiSchema={uiSchema}>
                <div className="myBtn-wrapper">
                  <button className="myBtn arrow-right-btn" type="submit">Подать заявление</button>
                </div>
              </UIForm>
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}

