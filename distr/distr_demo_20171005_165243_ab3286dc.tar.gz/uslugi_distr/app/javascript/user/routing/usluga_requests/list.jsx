import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import {dateTimeFormatter} from '~/components/formatters/date'
import connect from 'react-redux-fetch'
import ReactTable from 'react-table'
import 'react-table/react-table.css'
import {Label} from 'react-bootstrap'
import {stringify} from 'query-string'

const mapStateToProps = (state) => {
  return {passports: state.servant_passports}
}
@connect([{
  resource: 'uslugaRequests',
  request: (state)=>{
    const sorted = state.sorted && state.sorted[0]
    var sorted_params = {}
    if (sorted){
      sorted_params = {
        sort_id: sorted.id,
        sort_desc: sorted.desc
      }
    }
    const params = {
      page:(state.page+1),
      per:state.pageSize,
      ...sorted_params
    }
    return {
      url: `/api/user/usluga_requests/?${stringify(params,{arrayFormat: 'index'})}`,
    }
  }
}], mapStateToProps)

export default class Index extends React.Component {
  static propTypes = {
    dispatchUslugaRequestsGet: PropTypes.func.isRequired,
    uslugaRequestsFetch: PropTypes.object
  }
  static defaultProps = {
    uslugaRequestsFetch: {value:{data:[], meta:{}}}
  }
  constructor(props){
    super(props)
    this.columns = [
      {
        Header: '№№',
        id: 'id',
        width: 50,
        accessor: d => d.id
      },
      {
        Header: 'Услуга',
        id: 'passport_id',
        accessor: d => this.passportFormatter(d.passport_id)
      },
      {
        Header: 'Организация',
        id: 'organization_recipient_id',
        accessor: (d)=>{
          return d.data.organization && d.data.organization.name
        }
      },
      {
        Header: 'Дата создания',
        id: 'created_at',
        width: 150,
        accessor: d => {
          return(
            <p>
              {dateTimeFormatter(d.created_at)}
              <br />
              <Label bsStyle={d.state.style}>
                {d.state.name}
              </Label>
            </p>
          )
        }
      },
      {
        Header: 'Действия',
        id: 'links',
        width: 150,
        accessor: d => this.linkFormatter(d.id)
      }
    ]
  }

  linkFormatter(cell){
    return (
      <Link to={"/usluga_requests/"+cell}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true" />Посмотреть
        </button>
      </Link>
    )
  }

  passportFormatter = (cell) => {
    var passport = this.props.passports.find((elm)=>{return elm.id == cell})
    return passport && passport.name
  }

  render (){
    const {uslugaRequestsFetch, dispatchUslugaRequestsGet} = this.props
    return (
      <div>
        <h1>Мои заявления</h1>
        <ReactTable
          className='-striped -highlight'
          columns={this.columns}
          manual
          defaultPageSize={10}
          //filterable
          data={uslugaRequestsFetch.value&&uslugaRequestsFetch.value.data}
          pages={uslugaRequestsFetch.value&&uslugaRequestsFetch.value.meta.total_pages}
          loading={!uslugaRequestsFetch.fulfilled}
          onFetchData={dispatchUslugaRequestsGet}
        />
      </div>
    )
  }

}
