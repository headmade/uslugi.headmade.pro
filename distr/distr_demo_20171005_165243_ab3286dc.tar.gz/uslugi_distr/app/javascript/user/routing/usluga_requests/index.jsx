import Index from './list'
import New from './new'
import Show from './show'
//import Subscribe from './subscribe'
//import ServantList from './servant_list'

export {
  Index,
  New,
  Show,
  //Subscribe,
  //ServantList
}
