import React from 'react'
import { createStore, applyMiddleware } from 'redux'
import { Provider } from 'react-redux'
import thunk from 'redux-thunk'
import logger from 'redux-logger'
import {middleware as fetchMiddleware} from 'react-redux-fetch'
import { BrowserRouter as Router } from 'react-router-dom'
import { StickyContainer } from 'react-sticky'

import reducers from '~/reducers'
import toggleDebug from '~/actions/debug'
import loadSession from '~/actions/user'
import loadPassports from '~/actions/passport'

import BaseFooter from '~/components/base_footer'
import ScrollToTop from '~/components/scroll_to_top'

import Routes from './routing'
import TopMenu from './components/top_menu'



export default class App extends React.Component {
  constructor(props){
    super(props)
    this.store = createStore(reducers, {}, applyMiddleware(thunk, logger, fetchMiddleware))
    if (process.env.NODE_ENV !== "production") {
      this.store.dispatch(toggleDebug())
    }
    window.toggleDebug = ()=>{
      this.store.dispatch(toggleDebug())
    }

    this.store.dispatch(loadSession())
    this.store.dispatch(loadPassports())
  }
  render(){
    const {config} = this.props
    return (
      <StickyContainer>
        <Provider className="test" store={this.store}>
          <Router basename="/user">
            <ScrollToTop>
              <div>
                <TopMenu title={config.title}/>
                <Routes />
                <BaseFooter />
              </div>
            </ScrollToTop>
          </Router>
        </Provider>
      </StickyContainer>
)
}
}

