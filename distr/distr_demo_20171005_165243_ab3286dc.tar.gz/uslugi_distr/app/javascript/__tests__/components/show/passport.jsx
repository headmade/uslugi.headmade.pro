import React from 'react'
import renderer from 'react-test-renderer'
import {Passport} from '~/components/show/passport'

test('Passport render', () => {
  let passport = {name: "Test"}
  const component = renderer.create(
    <Passport passport={passport}/>
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})
