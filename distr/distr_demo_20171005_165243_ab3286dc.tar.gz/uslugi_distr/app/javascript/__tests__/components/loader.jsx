import React from 'react'
import renderer from 'react-test-renderer'
import Loader from '~/components/loader'

test('Loader', () => {
   const component = renderer.create(
     <Loader />
   )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})

test('Loader with children elements', () => {
   const component = renderer.create(
     <Loader><br /></Loader>
   )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})

test('Loader with children elements off', () => {
   const component = renderer.create(
     <Loader isLoading={false}><br /></Loader>
   )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})
