import React from 'react'
import renderer from 'react-test-renderer'
import Footer from '~/components/footer'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'

test('Link changes the class when hovered', () => {
   const component = renderer.create(
    <Router>
     <Footer />
    </Router>
   )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})
