import prepareSchema from '~/form/prepare_schema'
import defaultSchema from '~/form/default_schema'

test('Link changes the class when hovered', () => {
  const schema = prepareSchema(defaultSchema)
  expect(schema).toBeDefined()
  expect(schema).toHaveProperty('definitions.organization.type', 'object')
  expect(schema).toHaveProperty('definitions.agent.type', 'object')
  expect(schema).toHaveProperty('definitions.address.type', 'object')
})
