import Moment from 'moment'

Moment.locale('ru')
