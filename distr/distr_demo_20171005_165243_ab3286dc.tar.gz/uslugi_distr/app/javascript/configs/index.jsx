import axios from 'axios'
import dig from 'object-dig'
import isObject from 'lodash/isObject'
import isFunction from 'lodash/isFunction'
import { container } from 'react-redux-fetch'
import './leaflet'
import './moment'

window.dig = dig

const requestBuilder = (
  url,
  { body, method = 'get', headers = container.getDefinition('requestHeaders').getArguments() } = {},
) => {
  const finalHeaders = isFunction(headers)
    ? headers(container.getDefinition('requestHeaders').getArguments())
    : headers;

  return new Request(url, {
    method,
    headers: finalHeaders,
    credentials: 'same-origin',
    body: isObject(body) && !(body instanceof FormData) ? JSON.stringify(body) : body,
  });
};

container.getDefinition('requestBuilder').replaceArgument('build', requestBuilder);

axios.defaults.headers['X-CSRF-Token'] = document.querySelector('meta[name="csrf-token"]').getAttribute('content')
