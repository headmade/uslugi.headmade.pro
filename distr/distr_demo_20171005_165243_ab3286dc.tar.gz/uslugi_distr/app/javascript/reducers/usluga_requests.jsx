import { handleActions } from 'redux-actions'

const defaultState = {}

export default handleActions({
  "FETCH_USLUGA_REQUESTS": (state, {usluga_requests}) => {
    return usluga_requests
  },
  "SAVE_USLUGA_REQUEST": (state, {usluga_request}) => {
    return Object.assign({}, state, Object.assign({}, state.usluga_requests, {[usluga_request.id]: usluga_request}))
  },
}, defaultState)
