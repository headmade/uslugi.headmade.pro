import { handleActions } from 'redux-actions'

const defaultState = []

export default handleActions({
  "FETCH_QUERY_PASSPORTS": (state, {passports}) => {
    return passports
  },
}, defaultState)
