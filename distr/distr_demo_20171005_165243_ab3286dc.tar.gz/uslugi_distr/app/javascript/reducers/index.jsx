import { combineReducers } from 'redux'
import isDebug from './is_debug'
import current_user from './current_user'
import servant_passports from './servant_passports'
import query_passports from './query_passports'
import registries from './registries'
import usluga_requests from './usluga_requests'
import notifications from './notifications'
import last_usluga_request from './last_usluga_request'
import {reducer as fetchReducer} from 'react-redux-fetch';


const reducers = combineReducers({
  isDebug,
  current_user,
  servant_passports,
  query_passports,
  registries,
  usluga_requests,
  last_usluga_request,
  notifications,
  repository: fetchReducer
})

export default reducers
