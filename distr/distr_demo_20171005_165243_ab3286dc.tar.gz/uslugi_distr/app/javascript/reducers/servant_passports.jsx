import { handleActions } from 'redux-actions'

const defaultState = []

export default handleActions({
  "FETCH_SERVANT_PASSPORTS": (state, {servant_passports}) => {
    return servant_passports
  },
}, defaultState)
