import { handleActions } from 'redux-actions'

const defaultState = []

export default handleActions({
  "ADD_NOTIFICATION": (state, {data}) => {
    return state.concat([data])
  },
  "REMOVE_NOTIFICATION": (state, {id}) =>{
    state.splice(id, 1)
    return state
  }
}, defaultState)
