import { handleActions } from 'redux-actions'

const defaultState = null

export default handleActions({
  "SET_LAST_USLUGA_REQUEST": (state, {usluga_request}) => {
    return usluga_request
  }
}, defaultState)
