import { handleActions } from 'redux-actions'

const defaultState = {
  current_user: {},
}

export default handleActions({
  "SET_CURRENT_USER": (state, {session}) => {
    return {
      ...state,
      ...session
    }
  }
}, defaultState)
