import { handleActions } from 'redux-actions'

const defaultState = false
export default handleActions({
  "SET_DEBUG": (state) => {
    return !state
  }
}, defaultState)
