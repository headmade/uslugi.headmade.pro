import { handleActions } from 'redux-actions'

const defaultState = []

export default handleActions({
  "FETCH_REGISTRIES": (state, {registries}) => {
    return registries
  },
}, defaultState)
