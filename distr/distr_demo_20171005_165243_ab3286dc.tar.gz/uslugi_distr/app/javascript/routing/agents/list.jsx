import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'

export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {agents: [], isLoading: true}
    axios.get("/agents.json")
      .then((response)=>{
        this.setState({agents: response.data.data, isLoading:false})
      })
      .catch((error)=>{
        console.log(error)
      })
  }
  render (){
    const { isLoading, agents }= this.state
    return <div>
      <h3>Заявители</h3>
      { isLoading ? (<div className="loader">Loading...</div>):(
        <BootstrapTable data={agents} options={ { noDataText: 'Нет данных' } }>
          <TableHeaderColumn dataField='id' dataSort isKey hidden >ID</TableHeaderColumn>
          <TableHeaderColumn dataField='surname'>Фамилия</TableHeaderColumn>
          <TableHeaderColumn dataField='name'>Имя</TableHeaderColumn>
          <TableHeaderColumn dataField='patronymic_name'>Отчество</TableHeaderColumn>
          <TableHeaderColumn dataField='email'>Email</TableHeaderColumn>
          <TableHeaderColumn dataField='mobile'>Телефон</TableHeaderColumn>
        </BootstrapTable>
      )
      }
    </div>
  }
}
