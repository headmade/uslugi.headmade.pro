import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import axios from 'axios'
import Index from './list'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import durationFormatter from '~/components/formatters/duration'

const mapStateToProps = ({ servant_passports }) => ({ servant_passports })

@connect(mapStateToProps)
export default class ServantList extends Index {
  get_passports (){
  }
  nameFormatter(cell, row){
    return <Link to={"/services/"+row.id}>
      {row.name}
    </Link>
  }
  actionsFormatter(cell, row){
    return <div>
      {/*
      <Link to={"/services/"+cell}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Описание услуги
        </button>
      </Link>
      &nbsp;
      */}
      <Link to={"/passports/"+cell+"/uslugas/new"}>
        <button type="button" className="btn btn-warning">
          <span className="glyphicon glyphicon-folder-open" aria-hidden="true"></span> Приём документов
        </button>
      </Link>
      &nbsp;<br/>
      <Link to={"/services/"+cell+"/new"}>
        <button type="button" className="btn btn-primary">
          <span className="glyphicon glyphicon-question-sign" aria-hidden="true"></span> Консультация
        </button>
      </Link>
      &nbsp;
      <Link to={"/services/"+cell+"/new/last"}>
        <button type="button" className="btn btn-primary">
          <span className="glyphicon glyphicon-question-sign" aria-hidden="true"></span> Консультация предыдущего
        </button>
      </Link>
    </div>
  }
  render (){
    return <BootstrapTable data={ this.props.servant_passports } options={ { noDataText: 'This is custom text for empty data' } }>
          <TableHeaderColumn dataField='id' dataSort isKey hidden >ID</TableHeaderColumn>
          <TableHeaderColumn dataField='name' dataSort dataFormat={this.nameFormatter}>Услуга</TableHeaderColumn>
          <TableHeaderColumn dataField='duration' dataFormat={durationFormatter} width="100">Время на прием</TableHeaderColumn>
          <TableHeaderColumn dataField='id' dataFormat={this.actionsFormatter}>Действия</TableHeaderColumn>
      </BootstrapTable>
    //return <ul>{this.props.servant_passports.map((passport)=>
      //<li key={passport.id}>
        //<Link to={"/services/"+passport.id}>{passport.name}</Link>
      //</li>
    //)}</ul>
  }
}
