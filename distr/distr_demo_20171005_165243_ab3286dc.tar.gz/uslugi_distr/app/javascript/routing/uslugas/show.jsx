import React from 'react'
import PropTypes from 'prop-types'
//import { connect } from 'react-redux'
import axios from 'axios'
import Passport from '~/components/show/passport'
import Sign from '~/components/show/sign'
import History from '~/components/show/history'
import OrganizationDependencies from '~/components/show/organization_dependencies'
import AgentDependencies from '~/components/show/agent_dependencies'
import defaultSchema from '~/form/default_schema'
import prepareSchema from '~/form/prepare_schema'
import ShowForm from '~/form/show_form'
import {Well, Tabs, Tab, Row, Col} from 'react-bootstrap'
import connect from 'react-redux-fetch'
import EventsComponent from '~/components/events'
import QueriesComponent from '~/components/queries'
import Loader from '~/components/loader'


const mapStateToProps = ({servant_passports, isDebug})=>({servant_passports, isDebug})

@connect([{
  resource: 'usluga',
  request: (id) =>({
    url: `/api/servant/uslugas/${id}`,
    })
}],mapStateToProps)

export default class Show extends React.Component {
  static propTypes = {
    dispatchUslugaGet: PropTypes.func.isRequired,
    uslugaFetch: PropTypes.object
  }

  componentWillMount() {
    this.dispatchUslugaGet()
  }

  dispatchUslugaGet = ()=>{
    this.props.dispatchUslugaGet(this.props.match.params.id)
  }

  getPassport(passport_id){
    return this.props.servant_passports.find((elm)=>{return elm.id == passport_id})
  }
  getSchema(passport_id){
   const passport = this.getPassport(passport_id)
   return prepareSchema(passport && passport.data && passport.data.usluga && passport.data.usluga.schema || defaultSchema)
  }

  render (){
    const {uslugaFetch, isDebug} = this.props
    const usluga = uslugaFetch.value
    if (!uslugaFetch.fulfilled) {
      return <Loader />
    }
    return (<div>
      <Well>
        <Row>
          <Col md={6}>
            <EventsComponent resource='usluga' object={usluga} passport={this.getPassport(usluga.passport_id)}onSuccess={this.dispatchUslugaGet}/>
          </Col>
          <Col md={6}>
            <QueriesComponent resource='query' object={usluga} passport={this.getPassport(usluga.passport_id)} onSuccess={this.dispatchUslugaGet}/>
          </Col>
        </Row>
        <Row>
          <Col md={12}>
            <History object={usluga}/>
          </Col>
        </Row>
        <div className="row">
          <Col md={12}>
            {/*<Passport id={usluga.passport_id} />*/}
            <ShowForm formData={usluga.request_data} schema={this.getSchema(usluga.passport_id)} />
          </Col>
        </div>
        { isDebug &&
          <pre>
            {JSON.stringify(usluga, null, '  ')}
          </pre>
        }
      </Well>
      <Tabs defaultActiveKey={2} id="DependenciesTab">
        { usluga.organization_recipient_id &&
        <Tab eventKey={1} title="Посещения по этой организации">
          <OrganizationDependencies id={usluga.organization_recipient_id} usluga_request_id={usluga.id} />
        </Tab>}
        <Tab eventKey={2} title="Посещения этого заявителя">
          <AgentDependencies id={usluga.agent_id} usluga_request_id={usluga.id} />
        </Tab>
      </Tabs>
      <br />
    </div>)
  }
}

