import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import {dateToFormatter, dateTimeFormatter} from '~/components/formatters/date'
import connect from 'react-redux-fetch'
import ReactTable from 'react-table'
import 'react-table/react-table.css'
import {Label, Nav, NavItem} from 'react-bootstrap'
import {LinkContainer} from 'react-router-bootstrap'
import {stringify} from 'query-string'
import Loader from '~/components/loader'

const mapStateToProps = (state) => {
  return {passports: state.servant_passports}
}
@connect([{
  resource: 'uslugas',
  request: (state)=>{
    const sorted = state.sorted && state.sorted[0]
    var sorted_params = {}
    if (sorted){
      sorted_params = {
        sort_id: sorted.id,
        sort_desc: sorted.desc
      }
    }
    const params = {
      filter: state.filtered,
      page:(state.page+1),
      per:state.pageSize,
      ...sorted_params
    }
    return {
      url: `/api/servant/uslugas/?${stringify(params,{arrayFormat: 'index'})}`,
    }
  }
}], mapStateToProps)

export default class Index extends React.Component {
  static propTypes = {
    dispatchUslugasGet: PropTypes.func.isRequired,
    uslugasFetch: PropTypes.object
  }
  static defaultProps = {
    uslugasFetch: {value:{data:[], meta:{}}}
  }

  constructor(props){
    super(props)
    this.state = {filter: null}

    this.columns = [
      {
        Header: '№№',
        id: 'id',
        width: 50,
        accessor: d => d.id
      },
      {
        Header: 'Услуга',
        id: 'passport_id',
        accessor: d => {
          if (d.servant){
            var { name, patronymic_name, surname } = d.servant
            var fio = [name, patronymic_name, surname].join(' ')
          }
          return <div>
              {this.passportFormatter(d)}
              { d.servant && (!['created', 'started'].includes(d.state.key)) &&
                <span><br />
                  Исполнитель: <b>{fio}</b>
                </span>
              }
            </div>
        }
      },
      {
        Header: 'Организация',
        id: 'organization_recipient_id',
        accessor: d =>d.request_data.organization.name
      },
      {
        Header: 'Срок',
        id: 'expires_at',
        width: 150,
        accessor: d => {
          return(
            <p>
              {dateToFormatter(d.expires_at)}
              <br />
              <Label bsStyle={d.state.style}>
                {d.state.name}
              </Label>
            </p>
          )
        }
      },
      {
        Header: 'Действия',
        id: 'links',
        width: 150,
        accessor: d => this.linkFormatter(d.id)
      }
    ]
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.match.params){
      this.setState({filter: nextProps.match.params.key})
    }
  }

  linkFormatter(cell){
    return (
      <Link to={"/uslugas/"+cell}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true" />Посмотреть
        </button>
      </Link>
    )
  }
  passportData(object, passport){
    const text = object.request_data.passport && object.request_data.passport.text && ('"' + object.request_data.passport.text + '" - ')
    return <span>{text}{dig(object, 'request_data', 'address_with_map', 'address', 'value')}</span>
  }

  passportFormatter = (cell) => {
    const passport_id = cell.passport_id
    const passport = this.props.passports.find((elm)=>{return elm.id == passport_id})
    const passport_tag = dig(passport, 'name')
    return <div>{passport_tag}<br />{this.passportData(cell, passport)}</div>
  }

  render (){
    const {uslugasFetch, dispatchUslugasGet, match} = this.props
    return (
      <div>
        <h1>Услуги</h1>
        {!uslugasFetch.fulfilled &&
            <Loader />
        }

        <Nav
          style={ uslugasFetch.fulfilled ? {} : { display: 'none' }}
          bsStyle="pills" activeKey={1}>
          {uslugasFetch.value&&uslugasFetch.value.meta.filter_config.map((filter)=>{
          return <LinkContainer key={filter.key} to={"/uslugas/filter/"+filter.key}>
            <NavItem eventKey={filter.key}>{filter.name}</NavItem>
          </LinkContainer>

          })
          }
        </Nav>
        <ReactTable
          style={ uslugasFetch.fulfilled ? {} : { display: 'none' }}
          className='-striped -highlight'
          columns={this.columns}
          manual
          defaultPageSize={10}
          filtered={this.state.filter}
          //filterable
          data={uslugasFetch.value&&uslugasFetch.value.data}
          pages={uslugasFetch.value&&uslugasFetch.value.meta.total_pages}
          loading={!uslugasFetch.fulfilled}
          onFetchData={dispatchUslugasGet}
        />
      </div>
    )
  }

}
