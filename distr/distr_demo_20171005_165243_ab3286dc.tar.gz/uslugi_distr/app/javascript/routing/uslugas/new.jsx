import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import update from 'immutability-helper';
import { connect } from 'react-redux'
import axios from 'axios'
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from 'react-router-dom'
import { Button } from 'react-bootstrap'
import {defaultSchema, defaultUslugaResultSchema, defaultUslugaRejectSchema} from '~/form/default_schema'
import defaultUiSchema from '~/form/default_ui_schema'
import prepareSchema from '~/form/prepare_schema'
import prepareUiSchema from '~/form/prepare_ui_schema'
import UIForm from '~/form/ui_form'

export class New extends React.Component {
  constructor(props) {
    super(props)
    this.state = {formData:{}, isLoading: false}
    this.onSubmit = this.onSubmit.bind(this)
  }

  onSubmit(event) {
    this.setState({isLoading: true})
    var formData = event.formData
    console.log(formData)
    formData["passport_id"] =  this.props.passport.id
    axios.post("/uslugas.json", {"usluga": {request_data: formData}})
      .then((response)=>{
        this.props.history.push('/uslugas/'+response.data.id)
      })
      .catch((error)=>{
        console.log(error)
        this.setState({isLoading: false})
      })
  }

  render (){
    const {formData, isLoading} = this.state;
    const {passport, schema, uiSchema} = this.props

    return (
      <div className="row">
        { passport &&
            <div className="col-md-12">
              <b className="ui-form__caption">
                  {passport.name}
              </b>
              <UIForm onSubmit={this.onSubmit} schema={schema} formData={formData} uiSchema={uiSchema}>
                <Button bsStyle="success" bsSize="large" type="submit" disabled={isLoading}>Зарегистрировать</Button>
              </UIForm>
            </div>
        }
      </div>
    )
  }

}

const mapStateToProps = (state, ownProps) => {
  var passport = state.servant_passports.find((elm)=>{return elm.id == ownProps.match.params.passport_id})
  var usluga = passport && passport.data && passport.data.usluga
  return {
    passport: passport,
    schema: prepareSchema(usluga && usluga.schema || defaultSchema),
    uiSchema: prepareUiSchema(usluga && usluga.ui_schema || defaultUiSchema),
  }
}

const mapDispatchToProps = (dispatch) => {
  return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(New)
