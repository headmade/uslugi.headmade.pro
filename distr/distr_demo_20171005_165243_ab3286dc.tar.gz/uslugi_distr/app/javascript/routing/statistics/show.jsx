import React from 'react'
import ReactDOM from 'react-dom'
import {Grid, Row, Col, Tabs, Tab} from 'react-bootstrap'
import Loader from '~/components/loader'
import axios from 'axios'
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis} from 'recharts'

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']//, '#8884d8', '#82ca9d', '#FF8042', '#8884d8', '#82ca9d', '#ffc658'];

export default class Show extends React.Component {
  constructor(props){
    super(props)
    this.state = {statistics: {}, isLoading: true}
    axios.get("/statistics")
      .then((response)=>{
        this.setState({statistics: response.data, isLoading:false})
      })
      .catch((error)=>{
        console.log(error)
      })

  }
  render (){
    if (this.state.isLoading){
      return <Loader />
    }
    let height=300
    return (
      <Grid>
        <Row>
          <Col xs={12}>
            <Tabs defaultActiveKey={3} id="uncontrolled-tab-example">
              <Tab eventKey={1} title="Заявления">
                <Row>
                  <Col xs={12} sm={6}>
                    <Row>
                      <Col xs={12}>
                        <h2>Распределение заявлений по времени суток</h2>
                      </Col>
                    </Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <RadarChart data={this.state.statistics.count_per_hour_usluga_requests}>
                          <Radar name="Создана" dataKey="created" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6}/>
                          <Radar name="Обработана" dataKey="updated" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6}/>
                          <PolarGrid />
                          <Legend />
                          <PolarAngleAxis dataKey="name" />
                          {/*<PolarRadiusAxis angle={30} domain={[0, 150]}/>*/}
                        </RadarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
              </Tab>
              <Tab eventKey={2} title="Консультации">
                <Row>
                  <Col xs={12} sm={6}>
                    <Row>
                      <Col xs={12}>
                        <h2>Самые активные ходоки (консультации)</h2>
                      </Col>
                    </Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <BarChart data={this.state.statistics.top_agents_usluga_requests} >
                          <XAxis dataKey="object.surname"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Bar dataKey="value" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                  <Col xs={12} sm={6}>
                    <Row><Col xs={12}><h2>Самые активные организации (консультации)</h2></Col></Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <BarChart data={this.state.statistics.top_organizations_usluga_requests} >
                          <XAxis dataKey="key"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Bar dataKey="value" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
                <Row>
                  <Col xs={12} sm={6}>
                    <Row><Col xs={12}><h2>Популярность инструментов (по числу консультаций)</h2></Col></Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <PieChart>
                          <Tooltip/>
                          <Legend />
                          <Pie nameKey='name' dataKey='value' data={this.state.statistics.share_per_external_system_request_type_usluga_requests} label >
                            {this.state.statistics.share_per_external_system_request_type_usluga_requests.map((entry, index) =>{
                              return <Cell key={index} fill={COLORS[index % COLORS.length]}/>
                            })
                            }
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                  <Col xs={12} sm={6}>
                    <Row><Col xs={12}><h2>Популярность услуг (по числу консультаций)</h2></Col></Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <PieChart>
                          <Tooltip/>
                          <Legend />
                          <Pie nameKey='passport_name' dataKey='count' data={this.state.statistics.share_per_passport_usluga_requests} label >
                            {this.state.statistics.share_per_passport_usluga_requests.map((entry, index) =>{
                              return <Cell key={index} fill={COLORS[index % COLORS.length]}/>
                            })
                            }
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
                <Row>
                  <Col xs={12} sm={6}>
                    <Row><Col xs={12}><h2>90% консультаций оказаны за время</h2></Col></Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <BarChart data={this.state.statistics.percental_usluga_requests} >
                          <XAxis dataKey="name"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Bar dataKey="minutes" >
                            {
                              this.state.statistics.percental_usluga_requests.map((entry, index) => (
                                <Cell fill={entry.minutes < 10 ? '#82ca9d' : entry.minutes < 15 ? '#ffc658' : '#ffa0a0'}/>
                              ))
                            }
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                  <Col xs={12} sm={6}>
                    <Row><Col xs={12}><h2>Распределение длительности консультаций</h2></Col></Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <BarChart data={this.state.statistics.distribution_time_usluga_requests} >
                          <XAxis dataKey="passport_name"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Bar stackId="a" dataKey="0..5"  fill="#82ca9d" />
                          <Bar stackId="a" dataKey="5..10" fill="#8884d8" />
                          <Bar stackId="a" dataKey="10..15" fill='#ffc658' />
                          <Bar stackId="a" dataKey="15..20" fill='#ffa0a0' />
                          <Bar stackId="a" dataKey="20+" fill='#ff0000' />
                        </BarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
                <Row>
                  <Col xs={12} sm={6}>
                    <Row><Col xs={12}><h2>Консультации по дням</h2></Col></Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <LineChart data={this.state.statistics.count_per_date_usluga_requests} >
                          <XAxis dataKey="date"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Line dataKey="count" fill="#8884d8" type="monotone" />
                        </LineChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
              </Tab>
              <Tab eventKey={3} title="Услуги">
                <Row>
                  <Col xs={12} sm={6}>
                    <Row>
                      <Col xs={12}>
                        <h2>Услуги по дням</h2>
                      </Col>
                    </Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <LineChart data={this.state.statistics.count_per_date_uslugas} >
                          <XAxis dataKey="date"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Line dataKey="count" fill="#8884d8" type="monotone" />
                        </LineChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                  <Col xs={12} sm={6}>
                    <Row>
                      <Col xs={12}>
                        <h2>Популярность услуг</h2>
                      </Col>
                    </Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <PieChart>
                          <Tooltip/>
                          <Legend />
                          <Pie nameKey='passport_name' dataKey='count' data={this.state.statistics.share_per_passport_uslugas} label >
                            {this.state.statistics.share_per_passport_uslugas.map((entry, index) =>{
                              return <Cell key={index} fill={COLORS[index % COLORS.length]}/>
                            })
                            }
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
                <Row>
                  <Col xs={12} sm={6}>
                    <Row>
                      <Col xs={12}>
                        <h2>90% услуг оказаны за время</h2>
                      </Col>
                    </Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <BarChart data={this.state.statistics.percental_uslugas} >
                          <XAxis dataKey="name"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Bar dataKey="days" >
                            {
                              this.state.statistics.percental_uslugas.map((entry, index) => (
                                <Cell fill={entry.days < 3 ? '#82ca9d' : entry.days < 15 ? '#ffc658' : '#ffa0a0'}/>
                              ))
                            }
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                  <Col xs={12} sm={6}>
                    <Row>
                      <Col xs={12}>
                        <h2>Распределение скрока предоставления услуги</h2>
                      </Col>
                    </Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <BarChart data={this.state.statistics.distribution_time_uslugas} >
                          <XAxis dataKey="passport_name"/>
                          <YAxis/>
                          <Tooltip/>
                          <Legend />
                          <Bar stackId="a" dataKey="0..5" fill="#82ca9d" />
                          <Bar stackId="a" dataKey="5..10" fill="#8884d8" />
                          <Bar stackId="a" dataKey="10..15" fill='#ffc658' />
                          <Bar stackId="a" dataKey="15..18" fill='#ffa0a0' />
                          <Bar stackId="a" dataKey="18+" fill='#ff0000' />
                        </BarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
                <Row>
                  <Col xs={12} sm={6}>
                    <Row><Col xs={12}><h2>Распределение услуг по времени суток</h2></Col></Row>
                    <Row>
                      <ResponsiveContainer height={height}>
                        <RadarChart data={this.state.statistics.count_per_hour_uslugas}>
                          <Radar name="Создана" dataKey="created" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6}/>
                          <Radar name="Обработана" dataKey="updated" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6}/>
                          <PolarGrid />
                          <Legend />
                          <PolarAngleAxis dataKey="name" />
                          {/*<PolarRadiusAxis angle={30} domain={[0, 150]}/>*/}
                        </RadarChart>
                      </ResponsiveContainer>
                    </Row>
                  </Col>
                </Row>
              </Tab>
            </Tabs>
          </Col>
        </Row>
      </Grid>
    )
  }
}
