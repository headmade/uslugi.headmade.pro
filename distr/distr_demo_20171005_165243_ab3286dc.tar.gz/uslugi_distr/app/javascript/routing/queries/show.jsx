import React from 'react'
import PropTypes from 'prop-types'
//import { connect } from 'react-redux'
import axios from 'axios'
import Passport from '~/components/show/passport'
import Sign from '~/components/show/sign'
import History from '~/components/show/history'
import OrganizationDependencies from '~/components/show/organization_dependencies'
import AgentDependencies from '~/components/show/agent_dependencies'
import defaultSchema from '~/form/default_schema'
import prepareSchema from '~/form/prepare_schema'
import ShowForm from '~/form/show_form'
import {Well, Tabs, Tab, Row, Col} from 'react-bootstrap'
import connect from 'react-redux-fetch'
import EventsComponent from '~/components/events'
import Loader from '~/components/loader'
import Inspector from 'react-inspector'


const mapStateToProps = ({query_passports, isDebug})=>({query_passports, isDebug})

@connect([{
  resource: 'object',
  request: (id) =>({
    url: `/api/servant/queries/${id}`,
    })
}],mapStateToProps)

export default class Show extends React.Component {
  static propTypes = {
    dispatchObjectGet: PropTypes.func.isRequired,
    objectFetch: PropTypes.object
  }

  componentWillMount() {
    this.dispatchObjectGet()
  }

  dispatchObjectGet = ()=>{
    this.props.dispatchObjectGet(this.props.match.params.id)
  }

  getPassport(passport_id){
    return this.props.query_passports.find((elm)=>{return elm.id == passport_id})
  }

  getSchema(passport_id){
   const passport = this.getPassport(passport_id)
   return prepareSchema(passport && passport.data && passport.data.query && passport.data.query.schema)
  }

  render (){
    const {objectFetch, isDebug} = this.props
    const object = objectFetch.value
    if (!objectFetch.fulfilled) {
      return <Loader />
    }
    const schema = this.getSchema(object.query_passport_id)
    const query_data = object.query_data
    return (<div>
      <Well>
        <Row>
          <Col md={12}>
            <EventsComponent resource='query' resources='queries' object={object} passport={this.getPassport(object.query_passport_id)} onSuccess={this.dispatchObjectGet}/>
            <History resource='query' object={object}/>
          </Col>
        </Row>
        <div className="row">
          <Col md={12}>
            <h2>{object.title}</h2>
            <ShowForm formData={query_data} schema={schema} />
            { isDebug && <Inspector data={object} /> }
            {/*<Passport id={object.passport_id} />*/}
          </Col>
        </div>
      </Well>
      <br />
    </div>)
  }
}

