import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import {dateToFormatter, dateTimeFormatter} from '~/components/formatters/date'
import connect from 'react-redux-fetch'
import ReactTable from 'react-table'
import 'react-table/react-table.css'
import {Label, Nav, NavItem} from 'react-bootstrap'
import {LinkContainer} from 'react-router-bootstrap'
import {stringify} from 'query-string'

const object = 'queries'
const uri = `/api/servant/${object}/`
@connect([{
  resource: 'objects',
  request: (state)=>{
    const sorted = state.sorted && state.sorted[0]
    var sorted_params = {}
    if (sorted){
      sorted_params = {
        sort_id: sorted.id,
        sort_desc: sorted.desc
      }
    }
    const params = {
      filter: state.filtered,
      page:(state.page+1),
      per:state.pageSize,
      ...sorted_params
    }
    return {
      url: `${uri}?${stringify(params,{arrayFormat: 'index'})}`,
    }
  }
}])

export default class Index extends React.Component {
  static propTypes = {
    dispatchObjectsGet: PropTypes.func.isRequired,
    objectsFetch: PropTypes.object
  }
  static defaultProps = {
    objectsFetch: {value:{data:[], meta:{}}}
  }

  constructor(props){
    super(props)
    this.state = {filter: null}

    this.columns = [
      {
        Header: '№№',
        id: 'id',
        width: 50,
        accessor: d => d.id
      },
      {
        Header: 'Запрос',
        id: 'passport_id',
        accessor: d => d.title
      },
      {
        Header: 'Срок',
        id: 'expires_at',
        width: 150,
        accessor: d => {
          return(
            <p>
              {dateToFormatter(d.expires_at)}
              <br />
              <Label bsStyle={d.state.style}>
                {d.state.name}
              </Label>
            </p>
          )
        }
      },
      {
        Header: 'Действия',
        id: 'links',
        width: 150,
        accessor: d => this.linkFormatter(d.id)
      }
    ]
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.match.params){
      this.setState({filter: nextProps.match.params.key})
    }
  }

  linkFormatter(cell){
    return (
      <Link to={`/${object}/${cell}`}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true" />Посмотреть
        </button>
      </Link>
    )
  }

  render (){
    const {objectsFetch, dispatchObjectsGet, match} = this.props
    return (
      <div>
        <h1>Запросы</h1>
        <Nav bsStyle="pills" activeKey={1}>
          {objectsFetch.value&&objectsFetch.value.meta.filter_config.map((filter)=>{
          return <LinkContainer key={filter.key} to={`/${object}/filter/`+filter.key}>
            <NavItem eventKey={filter.key}>{filter.name}</NavItem>
          </LinkContainer>

          })
          }
        </Nav>
        <ReactTable
          className='-striped -highlight'
          columns={this.columns}
          manual
          defaultPageSize={10}
          filtered={this.state.filter}
          //filterable
          data={objectsFetch.value&&objectsFetch.value.data}
          pages={objectsFetch.value&&objectsFetch.value.meta.total_pages}
          loading={!objectsFetch.fulfilled}
          onFetchData={dispatchObjectsGet}
        />
      </div>
    )
  }

}
