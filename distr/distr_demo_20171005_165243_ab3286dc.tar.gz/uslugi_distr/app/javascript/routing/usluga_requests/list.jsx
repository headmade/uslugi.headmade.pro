import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import 'react-bootstrap-table/css/react-bootstrap-table.css'
import dateFormatter from '~/components/formatters/date'
import uslugaRequestStateFormatter from '~/components/formatters/usluga_request_state'

export class Index extends React.Component {
  constructor(props) {
    super(props)
    this.passportFormatter = this.passportFormatter.bind(this)
  }
  linkFormatter(cell, row){
    return <Link to={"/usluga_requests/"+cell}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true"></span> Посмотреть
        </button>
      </Link>
  }

  passportFormatter(cell, row){
    var passport = this.props.passports.find((elm)=>{return elm.id == cell})
    return passport && passport.name
  }

  render (){
    return <div>
      {this.props.passports && <BootstrapTable data={ this.props.usluga_requests } options={ { noDataText: 'Нет данных' } }>
          <TableHeaderColumn dataField='id' dataSort isKey width='50' >№№</TableHeaderColumn>
          <TableHeaderColumn dataField='passport_id' dataFormat={this.passportFormatter}>Услуга</TableHeaderColumn>
          <TableHeaderColumn dataField='state' dataFormat={uslugaRequestStateFormatter} >Состояние</TableHeaderColumn>
          <TableHeaderColumn dataField='created_at' dataFormat={dateFormatter} dataSort >Дата создания</TableHeaderColumn>
          <TableHeaderColumn dataField='id' dataFormat={this.linkFormatter}>Действия</TableHeaderColumn>
      </BootstrapTable>}
    </div>
  }

}
const mapStateToProps = (state, ownProps) => {
  let usluga_requests = []
  for (var i in state.usluga_requests) {
    usluga_requests.push(state.usluga_requests[i])
  }
  if (ownProps.filter){
    usluga_requests = usluga_requests.filter((u)=>{
      return u.state.key == 'consulted' || u.state.key == 'consultation'
    })
  }

  return {usluga_requests: usluga_requests, passports: state.servant_passports}
}

const mapDispatchToProps = (dispatch) => {
  return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(Index)
