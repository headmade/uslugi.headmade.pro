import React from 'react'
import PropTypes from 'prop-types'
//import { connect } from 'react-redux'
import axios from 'axios'
import Passport from '~/components/show/passport'
import OrganizationDependencies from '~/components/show/organization_dependencies'
import AgentDependencies from '~/components/show/agent_dependencies'
import defaultSchema from '~/form/default_schema'
import prepareSchema from '~/form/prepare_schema'
import ShowForm from '~/form/show_form'
import {Well, Tabs, Tab, Row, Col} from 'react-bootstrap'
import connect from 'react-redux-fetch'
import EventsComponent from '~/components/events'
import Countdown from '~/components/countdown'
import Timer from '~/components/timer'


const mapStateToProps = ({servant_passports, isDebug})=>({servant_passports, isDebug})

@connect([{
  resource: 'uslugaRequest',
  request: (id) =>({
    url: `/api/servant/usluga_requests/${id}`,
    })
}],mapStateToProps)

export default class Show extends React.Component {
  static propTypes = {
    dispatchUslugaRequestGet: PropTypes.func.isRequired,
    uslugaRequestFetch: PropTypes.object
  }

  componentWillMount() {
    this.dispatchUslugaRequestGet()
  }

  dispatchUslugaRequestGet = ()=>{
    this.props.dispatchUslugaRequestGet(this.props.match.params.id)
  }

  getPassport(passport_id){
    return this.props.servant_passports.find((elm)=>{return elm.id == passport_id})
  }

  getSchema(passport_id){
   const passport = this.getPassport(passport_id)
   const type = this.props.match.path == '/user_requests/:id' ? 'usluga' : 'usluga_requests'
   return prepareSchema(passport && passport.data && passport.data[type] && passport.data[type].schema || defaultSchema)
  }

  remaining(data){
    var r = data.estimated_to_complete_at - Date.now()
    return r > 0 ? r : 0
  }

  render (){
    const {uslugaRequestFetch, isDebug} = this.props
    const usluga = uslugaRequestFetch.value
    if (!uslugaRequestFetch.fulfilled) {
      return <div className="loader">Loading...</div>
    }
    return (<div>
      <Well>
        <Row>
          <Col md={7}>
            <EventsComponent resource='usluga_request' object={usluga} passport={this.getPassport(usluga.passport_id)} onSuccess={this.dispatchUslugaRequestGet}/>
          </Col>
          <Col md={5}>
          { usluga.state.key == 'consultation' &&
            <Timer remaining={this.remaining(usluga.data)}>
              <Countdown/>
            </Timer>
          }
          </Col>
        </Row>
        <div className="row">
          <Passport id={usluga.passport_id} />
          <ShowForm formData={usluga.data} schema={this.getSchema(usluga.passport_id)} />
        </div>
        { isDebug &&
          <pre>
            {JSON.stringify(usluga, null, '  ')}
          </pre>
        }
      </Well>
      <Tabs defaultActiveKey={2} id="DependenciesTab">
        { usluga.organization_recipient_id &&
        <Tab eventKey={1} title="Посещения по этой организации">
          <OrganizationDependencies id={usluga.organization_recipient_id} usluga_request_id={usluga.id} />
        </Tab>}
        <Tab eventKey={2} title="Посещения этого заявителя">
          <AgentDependencies id={usluga.agent_id} usluga_request_id={usluga.id} />
        </Tab>
      </Tabs>
      <br />
    </div>)
  }
}

