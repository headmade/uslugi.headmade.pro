import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import {dateTimeFormatter} from '~/components/formatters/date'
import connect from 'react-redux-fetch'
import ReactTable from 'react-table'
import 'react-table/react-table.css'
import {Label, Nav, NavItem} from 'react-bootstrap'
import {LinkContainer} from 'react-router-bootstrap'
import {stringify} from 'query-string'

const mapStateToProps = (state) => {
  return {passports: state.servant_passports}
}
@connect([{
  resource: 'userRequests',
  request: (state)=>{
    const sorted = state.sorted && state.sorted[0]
    var sorted_params = {}
    if (sorted){
      sorted_params = {
        sort_id: sorted.id,
        sort_desc: sorted.desc
      }
    }
    const params = {
      filter: state.filtered,
      page:(state.page+1),
      per:state.pageSize,
      ...sorted_params
    }
    return {
      url: `/api/servant/usluga_requests/user_requests/?${stringify(params,{arrayFormat: 'index'})}`,
    }
  }
}], mapStateToProps)

export default class UserRequests extends React.Component {
  static propTypes = {
    dispatchUserRequestsGet: PropTypes.func.isRequired,
    userRequestsFetch: PropTypes.object
  }
  static defaultProps = {
    userRequestsFetch: {value:{data:[], meta:{}}}
  }
  constructor(props){
    super(props)
    this.state = {filter: null}
    this.columns = [
      {
        Header: '№№',
        id: 'id',
        width: 50,
        accessor: d => d.id
      },
      {
        Header: 'Услуга',
        id: 'passport_id',
        accessor: d => {
          //const { name, patronymic_name, surname } = d.servant
          //const fio = [name, patronymic_name, surname].join(' ')
          return <div>
              {this.passportFormatter(d)}
            </div>
        }
      },
      {
        Header: 'Организация',
        id: 'organization_recipient_id',
        accessor: (d)=>{
          return d.data.organization && d.data.organization.name
        }
      },
      {
        Header: 'Дата создания',
        id: 'created_at',
        width: 150,
        accessor: d => {
          return(
            <p>
              {dateTimeFormatter(d.created_at)}
              <br />
              <Label bsStyle={d.state.style}>
                {d.state.name}
              </Label>
            </p>
          )
        }
      },
      {
        Header: 'Действия',
        id: 'links',
        width: 150,
        accessor: d => this.linkFormatter(d.id)
      }
    ]
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.match.params){
      this.setState({filter: nextProps.match.params.key})
    }
  }

  linkFormatter(cell){
    return (
      <Link to={"/user_requests/"+cell}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true" />Посмотреть
        </button>
      </Link>
    )
  }

  passportData(object, passport){
    return <span>{object.data.address_with_map && object.data.address_with_map.address.value}</span>
  }

  passportFormatter = (cell) => {
    const passport_id = cell.passport_id
    const passport = this.props.passports.find((elm)=>{return elm.id == passport_id})
    const passport_tag = passport && passport.name
    return <div>{passport_tag}<br />{this.passportData(cell, passport)}</div>
  }

  render (){
    const {userRequestsFetch, dispatchUserRequestsGet} = this.props
    return (
      <div>
        <h1>Электронные заявления</h1>
        <Nav bsStyle="pills" activeKey={1}>
          {userRequestsFetch.value&&userRequestsFetch.value.meta.filter_config.map((filter)=>{
          return <LinkContainer key={filter.key} to={"/user_requests/filter/"+filter.key}>
            <NavItem eventKey={filter.key}>{filter.name}</NavItem>
          </LinkContainer>

          })
          }
        </Nav>
        <ReactTable
          className='-striped -highlight'
          columns={this.columns}
          manual
          defaultPageSize={10}
          filtered={this.state.filter}
          //filterable
          data={userRequestsFetch.value&&userRequestsFetch.value.data}
          pages={userRequestsFetch.value&&userRequestsFetch.value.meta.total_pages}
          loading={!userRequestsFetch.fulfilled}
          onFetchData={dispatchUserRequestsGet}
        />
      </div>
    )
  }

}
