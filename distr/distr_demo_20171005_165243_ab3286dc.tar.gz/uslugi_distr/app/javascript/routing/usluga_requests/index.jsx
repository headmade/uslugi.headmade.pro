import Index from './list'
import UserRequests from './user_requests'
//import New from './new'
import Show from './show'
import Consultations from './consultations'
//import Subscribe from './subscribe'
//import ServantList from './servant_list'

export {
  Index,
  UserRequests,
  Consultations,
  //New,
  Show,
  //Subscribe,
  //ServantList
}
