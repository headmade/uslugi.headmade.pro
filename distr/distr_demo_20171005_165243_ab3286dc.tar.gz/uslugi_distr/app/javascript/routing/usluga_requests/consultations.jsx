import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import {dateTimeFormatter} from '~/components/formatters/date'
import connect from 'react-redux-fetch'
import ReactTable from 'react-table'
import 'react-table/react-table.css'
import {Label} from 'react-bootstrap'
import {stringify} from 'query-string'

const mapStateToProps = (state) => {
  return {passports: state.servant_passports}
}
@connect([{
  resource: 'userRequests',
  request: (state)=>{
    const sorted = state.sorted && state.sorted[0]
    var sorted_params = {}
    if (sorted){
      sorted_params = {
        sort_id: sorted.id,
        sort_desc: sorted.desc
      }
    }
    const params = {
      page:(state.page+1),
      per:state.pageSize,
      ...sorted_params
    }
    return {
      url: `/api/servant/usluga_requests/consultations/?${stringify(params,{arrayFormat: 'index'})}`,
    }
  }
}], mapStateToProps)

export default class Consultations extends React.Component {
  static propTypes = {
    dispatchUserRequestsGet: PropTypes.func.isRequired,
    userRequestsFetch: PropTypes.object
  }
  static defaultProps = {
    userRequestsFetch: {value:{data:[], meta:{}}}
  }
  constructor(props){
    super(props)
    this.columns = [
      {
        Header: '№№',
        id: 'id',
        width: 50,
        accessor: d => d.id
      },
      {
        Header: 'Услуга',
        id: 'passport_id',
        accessor: d => {
          //const { name, patronymic_name, surname } = d.servant
          //const fio = [name, patronymic_name, surname].join(' ')
          return <p>
              {this.passportFormatter(d.passport_id)}
            </p>
        }
      },
      {
        Header: 'Организация',
        id: 'organization_recipient_id',
        accessor: (d)=>{
          return d.data.organization && d.data.organization.name
        }
      },
      {
        Header: 'Дата создания',
        id: 'created_at',
        width: 150,
        accessor: d => {
          return(
            <p>
              {dateTimeFormatter(d.created_at)}
              <br />
              <Label bsStyle={d.state.style}>
                {d.state.name}
              </Label>
            </p>
          )
        }
      },
      {
        Header: 'Действия',
        id: 'links',
        width: 150,
        accessor: d => this.linkFormatter(d.id)
      }
    ]
  }

  linkFormatter(cell){
    return (
      <Link to={"/usluga_requests/"+cell}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true" />Посмотреть
        </button>
      </Link>
    )
  }

  passportFormatter = (cell) => {
    var passport = this.props.passports.find((elm)=>{return elm.id == cell})
    return passport && passport.name
  }

  render (){
    const {userRequestsFetch, dispatchUserRequestsGet} = this.props
    return (
      <div>
        <h1>Консультации</h1>
        <ReactTable
          className='-striped -highlight'
          columns={this.columns}
          manual
          defaultPageSize={10}
          //filterable
          data={userRequestsFetch.value&&userRequestsFetch.value.data}
          pages={userRequestsFetch.value&&userRequestsFetch.value.meta.total_pages}
          loading={!userRequestsFetch.fulfilled}
          onFetchData={dispatchUserRequestsGet}
        />
      </div>
    )
  }

}
