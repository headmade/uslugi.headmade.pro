import React from 'react'
import { connect } from 'react-redux'
import axios from 'axios'
import { Button } from 'react-bootstrap'
import prepareSchema from '~/form/prepare_schema'
import UIForm from '~/form/ui_form'
import Loader from '~/components/loader'


const mapStateToProps = (state, ownProps) => {
  var registry = state.registries.find((elm)=>{return elm.id == ownProps.match.params.registry_id})
  var schema = registry && registry.data && registry.data.schema || {}
  return {
    registry: registry,
    schema: prepareSchema(schema)
  }
}

@connect(mapStateToProps)
export default class Edit extends React.Component {
  constructor(props) {
    super(props)
    this.state = {formData:{}, isLoading: true}
    this.id = props.match.params.id
    axios.get("/registry_items/"+this.id)
      .then((response)=>{
        this.setState({formData: response.data.data, isLoading:false})
      })
      .catch((error)=>{
        console.log(error)
      })
    this.onSubmit = this.onSubmit.bind(this)
  }

  onSubmit(event) {
    var formData = event.formData
    formData["registry_id"] =  this.props.registry.id
    axios.patch("/registry_items/"+this.id, {"registry_item": {data: formData}})
      .then(()=>{
        this.props.history.push('/registries/'+this.props.registry.id)
      })
      .catch((error)=>{
        console.log(error)
      })
  }

  render (){
    const {formData} = this.state
    const {registry, schema} = this.props
    return (
      <div className="row">
        <div className="col-md-12">
          <Loader isLoading={this.state.isLoading}>
            <b className="ui-form__caption">
              {registry.name}
            </b>
            <UIForm onSubmit={this.onSubmit} schema={schema} formData={formData}>
              <Button bsStyle="success" bsSize="large" type="submit">Зарегистрировать</Button>
            </UIForm>
          </Loader>
        </div>
      </div>
    )
  }
}

