import React from 'react'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import axios from 'axios'
import {
  Link
} from 'react-router-dom'

import ReactTable from 'react-table'
import 'react-table/react-table.css'
//import Lightbox from 'react-images'

export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {culture_objects: [], isLoading: true, registry_id: props.match.params.registry_id, totalPages: 0}
    this.fetchData = this.fetchData.bind(this)
    this.linkFormatter = this.linkFormatter.bind(this)
  }

  fetchData(state, instance){
    //console.log(state, instance)
    this.setState({isLoading: true})
    const page_params = "?page="+(state.page+1)+"&per="+state.pageSize
    axios.get("/registries/"+this.state.registry_id+"/registry_items" + page_params)
      .then((response)=>{
        this.setState({culture_objects: response.data.data, isLoading:false, totalPages: response.data.meta.total_pages})
      })
      .catch((error)=>{
        console.log(error)
      })
  }

  componentWillReceiveProps(nextProps) {
    const defaultState = {page:0, pageSize: 10}
    const registry_id = nextProps.match.params.registry_id
    if (registry_id != this.state.registry_id){
      this.setState({registry_id: registry_id}, ()=>{
        this.fetchData(defaultState)
        this.forceUpdate()
      })
    }
  }

  dataFormatter(data, cell) {
    let is_string = typeof(cell[data]) === 'string'
    let is_image = cell[data] && !is_string && typeof(cell[data].object) !== 'undefined' && cell[data].object.substring(0, 11) == 'data:image/'

    //return is_image ? <Lightbox images={[{src: cell[data].object, widths: 100}]} onClose={this.closeLightbox} /> : `<p>${cell[data] ? (is_string ? cell[data] : cell[data].value) : '---'}</p>`;
    return is_image ?
      <img src={cell[data].object} width='200' /> :
      <p>{cell[data] ? (is_string ? cell[data] : cell[data].value) : ''}</p>
  }

  linkFormatter(row){
    return <Link to={"/registries/"+this.state.registry_id+"/registry_items/"+row.value}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true"></span> Редактировать
        </button>
      </Link>
  }

  render (){
    const { isLoading, culture_objects, registry_id }= this.state
    return <div>
      <h3>Объекты культурного наследия (ОКН)</h3>
      <Link to={"/registries/"+registry_id+"/new"}>
        <button type="button" className="btn btn-primary">
          <span className="glyphicon glyphicon-plus" aria-hidden="true"></span>Добавить
        </button>
      </Link>
      <ReactTable
            className='-striped -highlight'
            columns={[{
              Header: 'Наименование',
              id: 'title',
              accessor: d => d.data.title
            }, {
              Header: 'Адрес',
              id: 'address',
              accessor: d => d.data.address.value
            }, {
              Header: 'Документ',
              id: 'protection_document',
              accessor: d => d.data.protection_document
            },{
              Header: 'Действия',
              accessor: 'id',
              Cell: this.linkFormatter
            }]}
            manual
            defaultPageSize={10}
            //filterable
            data={culture_objects} // Set the rows to be displayed
            pages={this.state.totalPages} // Display the total number of pages
            loading={isLoading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
          />
    </div>
  }
}
