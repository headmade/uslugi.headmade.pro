import React from 'react'
import { connect } from 'react-redux'
import axios from 'axios'
import { Button } from 'react-bootstrap'
import prepareSchema from '~/form/prepare_schema'
import UIForm from '~/form/ui_form'

const mapStateToProps = (state, ownProps) => {
  var registry = state.registries.find((elm)=>{return elm.id == ownProps.match.params.registry_id})
  var schema = registry && registry.data && registry.data.schema || {}
  return {
    registry: registry,
    schema: prepareSchema(schema)
  }
}

@connect(mapStateToProps)
export default class New extends React.Component {
  constructor(props) {
    super(props)
    this.state = {formData:{}}
    this.onSubmit = this.onSubmit.bind(this)
  }

  onSubmit(event) {
    var formData = event.formData
    formData["registry_id"] =  this.props.registry.id
    axios.post("/registry_items.json", {"registry_item": {data: formData}})
      .then(()=>{
        this.props.history.push('/registries/'+this.props.registry.id)
      })
      .catch((error)=>{
        console.log(error)
      })
  }

  render (){
    const {formData} = this.state
    const {registry, schema} = this.props
    return (
      <div className="row">
        { registry &&
          <div className="col-md-12">
            <b className="ui-form__caption">
              {registry.name}
            </b>
            <UIForm onSubmit={this.onSubmit} schema={schema} formData={formData}>
              <Button bsStyle="success" bsSize="large" type="submit">Зарегистрировать</Button>
            </UIForm>
          </div>
        }
      </div>
    )
  }

}

