import React from 'react'
import { connect } from 'react-redux'
import axios from 'axios'
import {
  Link
} from 'react-router-dom'

import ReactTable from 'react-table'
import 'react-table/react-table.css'
import getColumnsConfig from '~/components/table/columns_config'


const mapStateToProps = ({registries}) => ({registries})
@connect(mapStateToProps)
export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {registry_items: [], isLoading: true, registry_id: props.match.params.registry_id, registry: this.registry(props.match.params.registry_id), totalPages: 0}
    this.fetchData = this.fetchData.bind(this)
    this.linkFormatter = this.linkFormatter.bind(this)
    this.registry = this.registry.bind(this)
    this.getColumns(props.match.params.registry_id)
  }

  componentWillReceiveProps(nextProps) {
    const defaultState = {page:0, pageSize: 10}
    const registry_id = nextProps.match.params.registry_id
    if (registry_id != this.state.registry_id){
      this.setState({registry_id: registry_id, registry: this.registry(registry_id)}, ()=>{
        this.getColumns(registry_id)
        this.fetchData(defaultState)
        this.forceUpdate()
      })
    }
  }


  getColumns(registry_id){
    this.columns = getColumnsConfig(registry_id,
      {
        Header: 'Действия',
        accessor: 'id',
        width: 200,
        Cell: this.linkFormatter
      }
    )
  }

  fetchData(state){
    this.setState({isLoading: true})
    const page_params = "?page="+(state.page+1)+"&per="+state.pageSize
    axios.get("/registries/"+this.state.registry_id+"/registry_items" + page_params)
      .then((response)=>{
        this.setState({registry_items: response.data.data, isLoading:false, totalPages: response.data.meta.total_pages})
      })
      .catch((error)=>{
        console.log(error)
      })
  }

  dataFormatter(data, cell) {
    let is_string = typeof(cell[data]) === 'string'
    let is_image = cell[data] && !is_string && typeof(cell[data].object) !== 'undefined' && cell[data].object.substring(0, 11) == 'data:image/'

    //return is_image ? <Lightbox images={[{src: cell[data].object, widths: 100}]} onClose={this.closeLightbox} /> : `<p>${cell[data] ? (is_string ? cell[data] : cell[data].value) : '---'}</p>`;
    return is_image ?
      <img src={cell[data].object} width='200' alt='' /> :
      <p>{cell[data] ? (is_string ? cell[data] : cell[data].value) : ''}</p>
  }

  linkFormatter(row){
    return (
      <Link to={"/registries/"+this.state.registry_id+"/registry_items/"+row.value}>
        <button type="button" className="btn btn-success">
          <span className="glyphicon glyphicon-eye-open" aria-hidden="true" />Редактировать
        </button>
      </Link>
    )
  }

  registry(registry_id){
    return this.props.registries.find((elm)=>{return elm.id == registry_id})
  }

  render (){
    const { isLoading, registry_items, registry_id, registry}= this.state
    return (
      <div>
        <h3>{registry && registry.name}</h3>
        <Link to={"/registries/"+registry_id+"/new"}>
          <button type="button" className="btn btn-primary">
            <span className="glyphicon glyphicon-plus" aria-hidden="true" />Добавить
          </button>
        </Link>
        <ReactTable
          className='-striped -highlight'
          columns={this.columns}
          manual
          defaultPageSize={10}
          //filterable
          data={registry_items} // Set the rows to be displayed
          pages={this.state.totalPages} // Display the total number of pages
          loading={isLoading} // Display the loading overlay when we need it
          onFetchData={this.fetchData} // Request new data when things change
        />
      </div>
    )
  }
}
