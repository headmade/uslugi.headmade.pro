import React from 'react'
import { connect } from 'react-redux'
import { Route } from 'react-router-dom'

import * as Passports from '~/routing/passports'
import * as UslugaRequests from '~/routing/usluga_requests'
import * as Uslugas from '~/routing/uslugas'
import * as Agents from '~/routing/agents'
import * as Registries from '~/routing/registries'
import * as Queries from '~/routing/queries'
import * as Statistics from '~/routing/statistics'
import ServantDashbord from '~/components/dashbord'

export default class ServantRoutes extends React.Component{
  render(){
    return (
      <div className="container">
        <Route exact path="/" component={ServantDashbord}/>
        <Route exact path="/services/:id" component={Passports.Show}/>
        <Route exact path="/passports" component={Passports.ServantList}/>
        <Route path="/services/:id/subscribe" component={Passports.Subscribe}/>
        <Route exact path="/services/:id/new" component={Passports.New}/>
        <Route path="/services/:id/new/:last" component={Passports.New}/>
        <Route exact path="/usluga_requests/:id" component={UslugaRequests.Show}/>
        <Route exact path="/user_requests/:id" component={UslugaRequests.Show}/>
        <Route exact path="/user_requests" component={UslugaRequests.UserRequests}/>
        <Route exact path="/user_requests/filter/:key" component={UslugaRequests.UserRequests}/>
        <Route exact path="/consultations" component={UslugaRequests.Consultations}/>
        <Route exact path="/uslugas" component={Uslugas.Index}/>
        <Route exact path="/uslugas/filter/:key" component={Uslugas.Index}/>
        <Route exact path="/uslugas/:id" component={Uslugas.Show}/>
        <Route exact path="/passports/:passport_id/uslugas/new" component={Uslugas.New}/>
        <Route exact path="/agents" component={Agents.Index}/>
        <Route exact path="/registries/:registry_id" component={Registries.Index}/>
        <Route exact path="/registries/:registry_id/new" component={Registries.New}/>
        <Route exact path="/registries/:registry_id/registry_items/:id" component={Registries.Edit}/>
        <Route exact path="/queries" component={Queries.Index}/>
        <Route exact path="/queries/filter/:key" component={Queries.Index}/>
        <Route exact path="/queries/:id" component={Queries.Show}/>
        <Route exact path="/statistics" component={Statistics.Show}/>
      </div>
    )
  }
}
