class Api::ApplicationController < ApplicationController
  include ActionContextable
  include AuthenticableApi
  include InstanceVieweable

  before_action :prepend_instance_views_path

  def prepend_instance_views_path
    prepend_view_path(instance_views_path())
  end
end
