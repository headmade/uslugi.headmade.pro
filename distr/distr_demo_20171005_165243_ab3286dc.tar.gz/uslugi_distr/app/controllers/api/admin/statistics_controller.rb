class Api::Admin::StatisticsController < Api::Servant::ApplicationController
  include Statisticable

  def set_filters
    @filters = {date_from: params[:date_from], date_to: params[:date_to]}
  end
end
