class Api::Admin::ApplicationController < Api::ApplicationController
end
