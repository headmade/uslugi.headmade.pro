class Api::S3Controller < Web::ApplicationController
  include AuthenticableWeb

  skip_before_action :check_role!

  def sign
		headers = {"Content-Type" => params[:contentType], "x-amz-acl" => "public-read"}

    filename = [params[:guid], params[:objectName]].join('/')
    url = S3Service.sign_file_put(filename, params[:contentType])

    render json: {signedUrl: url}
  end
end
