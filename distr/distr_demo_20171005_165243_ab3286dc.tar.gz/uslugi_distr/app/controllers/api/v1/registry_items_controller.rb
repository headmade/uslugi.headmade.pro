class Api::V1::RegistryItemsController < Api::V1::ApplicationController

  before_action :set_registry
  before_action :set_registry_item, only: %i(show)

  def index
    @registry_items = @registry.registry_items.search_inn(params[:inn]).search_fias_id(params[:fias_id])
    @total_records = @registry_items.count

    @registry_items = @registry_items.page(params[:page]).per(params[:per])
    @total_pages = @registry_items.total_pages

    @registry_items = @registry_items.decorate
  end

  def show
    @registry_item = @registry_item.decorate
  end

  private

  def registry_id(registry_key)
    @registry_ids ||= {
      'dit_docs' => 6,              # TOFIX: dirty hack
    }.with_indifferent_access

    registry_key ? (@registry_ids[registry_key] || registry_key): @registry_ids.values
  end

  def set_registry
    @registry = Registry.find(registry_id(params[:registry_id]))
  end

  def set_registry_item
    @registry_item = @registry.registry_items.find(params[:id])
  end
end
