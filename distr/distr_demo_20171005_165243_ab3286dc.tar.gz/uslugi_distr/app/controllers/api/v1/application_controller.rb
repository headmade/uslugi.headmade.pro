class Api::V1::ApplicationController < Api::ApplicationController
  skip_before_action :authenticate!
  skip_before_action :check_role!
end
