class Api::Servant::UslugasController < Api::Servant::ApplicationController

  before_action :set_uslugas
  before_action :set_usluga, only: %i(show event)
  before_action :set_passport, only: %i(create)
  before_action :set_user, only: %i(create)
  before_action :set_usluga_request, only: %i(create)
  before_action :set_agent, only: %i(create)

  before_action :set_organization_recipient, only: %i(create)

  def index
    prepare_list_response
  end

  def show
    @usluga = UslugaServantDecorator.decorate(@usluga)
    respond_to do |format|
      format.json
      format.pdf
    end
  end

  def create
    ApplicationRecord.transaction do
      # TODO: @usluga_request.user = ?
      Usluga.transaction do
        @usluga_request = current_servant.usluga_requests.create!(
          passport: @passport,
          agent: @agent,
          organization_recipient: @organization_recipient,
          data: usluga_params[:request_data].merge('source' => '01_servant'),
        )
        @usluga_request.submit!
        @usluga_request.assign!
        @usluga_request.accept! # this creates usluga

        @usluga = @usluga_request.usluga
      end
    end

    @usluga = UslugaServantDecorator.decorate(@usluga)
    render :show
  end

  def event
    name = params[:name].to_s
    # TODO: check if permitted
    @usluga.send(name+'!', params[:data])
    @usluga = UslugaServantDecorator.decorate(@usluga)
    head :ok
  end

  private

  def prepare_list_response
    # TODO: use locale
    @filter_config = [
      {key: :new, name: 'Новые', style: :info},
      {key: :assigned, name: 'В работе', style: :primary},
      {key: :assigned_again, name: 'На доработке', style: :warning},
      {key: :waits_sign, name: 'На подписании', style: :info},
      {key: :rejects, name: 'Отказано', style: :info},
      {key: :completes, name: 'Разрешено', style: :info},
      {key: :my, name: 'Мои', style: :warning},
      {key: :archive, name: 'Архив', style: :info},
    ]

    filters = (params[:filter].present? ? params[:filter] : :new).to_s.split(',').map{|name| [name,1]}.to_h.with_indifferent_access

    @filter_config.each {|f| f[:active] = true if filters[f[:key]]}

    @uslugas = @uslugas.started if filters[:new]
    @uslugas = @uslugas.where(state: %i(assigned assigned_again)) if filters[:assigned]
    @uslugas = @uslugas.assigned_again if filters[:assigned_again]
    @uslugas = @uslugas.where(state: %i(completed rejected)) if filters[:waits_sign]
    @uslugas = @uslugas.where(state: %i(rejected rejected_signed)) if filters[:rejects]
    @uslugas = @uslugas.where(state: %i(completed completed_signed)) if filters[:completes]
    @uslugas = @uslugas.where(servant_id: current_servant.id) if filters[:my]
    @uslugas = @uslugas.signed if filters[:archive]

    @total_records = @uslugas.count

    @uslugas = @uslugas.page(params[:page]).per(params[:per])
    @total_pages = @uslugas.total_pages

    @uslugas = UslugaServantDecorator.decorate_collection(@uslugas)

    render :index
  end

  def set_uslugas
    #@uslugas = current_servant.uslugas
    @uslugas = Usluga.with_passport_ids(current_servant.passport_ids)
    unless params[:id]
      sort_name = params[:sort_id].present? ? params[:sort_id] : :id
      sort_name = {
        'expires_at' => 'created_at'   # TODO: fix this - must be kinda (created_at + passport.duration), not just created_at
      }[sort_name] || sort_name
      sort_order = params[:sort_desc] == 'true' ? :desc : :asc
      @uslugas = @uslugas.order(sort_name => sort_order)
    end
  end

  def set_usluga
    @usluga = @uslugas.find(params[:id])
  end

  def set_passport
    @passport = Passport.find(params[:usluga][:request_data][:passport_id])
  end

  def set_user
    user_id = params[:usluga][:user_id]
    @user = User.with_role(:user).find(user_id) if user_id.present?
  end

  def set_usluga_request
    usluga_request_id = params[:usluga][:usluga_request_id]
    @usluga_request = UslugaRequest.find(usluga_request_id) if usluga_request_id.present?
  end

  def set_agent
    data_agent = usluga_params[:request_data][:agent].permit(:passport_number, :mobile, :email, fio: {})
    @agent = AgentService.find_or_create_agent(data_agent.to_hash)
  end

  def set_organization_recipient
    data_organization = usluga_params[:request_data][:organization].permit(:inn, :phone, :mobile, :email)
    @organization_recipient = OrganizationRecipientService.find_or_create_organization_recipient(data_organization.to_hash)
  end

  def usluga_params()
    params.require(:usluga).permit!
    #TODO: проверить почему не сохраняются полигоны в geoJSON
    #params.require(:usluga).permit(:state, request_data: {}, result_data: {}).tap do |p|
      #%i(request_data result_data).each { |k| p[k] = JSON.parse(p[k]) if p[k].is_a?(String) }
    #end
  end

end
