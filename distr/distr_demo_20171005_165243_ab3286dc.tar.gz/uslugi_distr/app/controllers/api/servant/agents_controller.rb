class Api::Servant::AgentsController < Api::Servant::ApplicationController

  before_action :set_agents, only: %i(index)
  before_action :set_agent, only: %i(usluga_requests)

  def index
    @total_records = @agents.count
    @agents = @agents.page(params[:page]).per(params[:per])
    @total_pages = @agents.total_pages
    @agents = @agents.decorate
  end

  def usluga_requests
    @usluga_requests = @agent.usluga_requests
    @total_records = @usluga_requests.count
    @usluga_requests = @usluga_requests.page(params[:page]).per(params[:per])
    @total_pages = @usluga_requests.total_pages
    @usluga_requests = @usluga_requests.decorate
  end

  private

  def set_agents
    @agents = Agent.passport_number_like(params[:passport_number]).order(updated_at: :desc).limit(10)
  end

  def set_agent
    @agent = Agent.find(params[:id])
  end

end
