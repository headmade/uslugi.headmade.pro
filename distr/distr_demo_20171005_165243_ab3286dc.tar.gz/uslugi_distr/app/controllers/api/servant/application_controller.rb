class Api::Servant::ApplicationController < Api::ApplicationController
end
