class Api::Servant::PassportsController < Api::Servant::ApplicationController
  before_action :set_passports
  before_action :set_passport, only: %i(show)

  def index
    @total_records = @passports.count
    @passports = @passports.page(params[:page]).per(params[:per])
    @total_pages = @passports.total_pages
    @passports = @passports.decorate
  end

  def show
    @passport = @passport.decorate
  end

  private

  def set_passports
    @passports = current_servant.passports.active.order(id: :desc)
  end

  def set_passport
    @passport = @passports.find(params[:id])
  end

end
