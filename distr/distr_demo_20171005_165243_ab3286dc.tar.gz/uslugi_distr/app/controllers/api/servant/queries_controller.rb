class Api::Servant::QueriesController < Api::Servant::ApplicationController

  before_action :set_queries, except: %i(recipients)
  before_action :set_query, only: %i(show event)
  before_action :set_usluga, only: %i(create)

  def index
    prepare_list_response
  end

  def show
    @query = @query.decorate
  end

  def event
    name = params[:name].to_s
    @query.send(name+'!', params[:data])
    @query = @query.decorate
    head :ok
  end

  def create
    qp = QueryPassport.find(params[:query_passport_id])
    Query.transaction do
      @query = @usluga.queries.create!(query_passport: qp, from_servant: current_servant, query_data: params[:data])
      @query.start!
    end

    @query = @query.decorate
    render :show
  end

  def recipients
    q = params[:q]

    @recipients = []
    if q.present?
      @recipients = ApplicationRecord.connection.exec_query( %q(
        (select id, surname as title, 'servant' as type
         from servants where surname ilike $1 order by surname limit 10)
        union
        (select id, short_name as title, 'department' as type
         from departments where short_name ilike $1 order by short_name limit 10)
        order by type, title
        ),
      'recipients', [[nil,"%#{q}%"]]).to_a
    end

    @total_records = @recipients.count
    @total_pages = 1

  end

  private

  def prepare_list_response
    # TODO: use locale
    @filter_config = [
      {key: :new, name: 'Новые', style: :info},
      {key: :assigned, name: 'В работе', style: :primary},
      #{key: :waits_sign, name: 'На подписании', style: :info},
      {key: :rejected, name: 'Отказано', style: :info},
      {key: :completed, name: 'Разрешено', style: :info},
      {key: :my, name: 'Мои', style: :warning},
    ]

    filters = (params[:filter].present? ? params[:filter] : :new).to_s.split(',').map{|name| [name,1]}.to_h.with_indifferent_access

    @filter_config.each {|f| f[:active] = true if filters[f[:key]]}

    @queries = @queries.started if filters[:new]
    @queries = @queries.assigned if filters[:assigned]
    #@queries = @queries.where(state: %i(completed rejected)) if filters[:waits_sign]
    @queries = @queries.rejected if filters[:rejected]
    @queries = @queries.completed if filters[:completed]
    @queries = @queries.where(servant_id: current_servant.id) if filters[:my]

    @total_records = @queries.count

    @queries = @queries.page(params[:page]).per(params[:per])
    @total_pages = @queries.total_pages

    @queries = @queries.decorate

    render :index
  end

  def set_queries
    qp_by_department_ids = QueryPassport.where(department_id: current_servant.department_ids).pluck(:id)
    qp_by_servant_ids = current_servant.query_passport_ids
    qp_no_receiver_ids = QueryPassport.where(department_id: nil, servant_id: nil).pluck(:id)

    @queries = Query.where(query_passport_id: qp_by_department_ids + qp_by_servant_ids + qp_no_receiver_ids)

    unless params[:id]
      sort_name = params[:sort_id].present? ? params[:sort_id] : :id
      sort_name = {
        'passport_id' => 'query_passport_id',
      }[sort_name] || sort_name
      sort_order = params[:sort_desc] == 'true' ? :desc : :asc
      @queries = @queries.order(sort_name => sort_order)
    end
  end

  def set_query
    @query = @queries.find(params[:id])
  end

  def set_usluga
    @usluga = Usluga.find(params[:usluga_id]) # TODO: check if may add query into this usluga
  end
end
