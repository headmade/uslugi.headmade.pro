class Api::Servant::RegistriesController < Api::Servant::ApplicationController

  before_action :set_registries, only: %i(index registry_items)
  before_action :set_registry, only: %i(registry_items)

  def index
    @total_records = @registries.count
    @registries = @registries.page(params[:page]).per(params[:per])
    @total_pages = @registries.total_pages
    @registries = @registries.decorate
  end

  def registry_items
    @registry_items = @registry.registry_items
    @total_records = @registry_items.count

    @registry_items = @registry_items.page(params[:page]).per(params[:per])
    @total_pages = @registry_items.total_pages

    @registry_items = @registry_items.decorate
  end

  private

  def set_registry
    @registry = @registries.find(params[:id])
  end

  def set_registries
    @registries = Registry.where(id: current_servant.registry_ids)
  end

end
