class Api::Servant::QueryPassportsController < Api::Servant::ApplicationController
  before_action :set_query_passports
  before_action :set_query_passport, only: %i(show)

  # TODO: check if is in use
  def index
    @total_records = @query_passports.count
    @query_passports = @query_passports.page(params[:page]).per(params[:per])
    @total_pages = @query_passports.total_pages
    @query_passports = @query_passports.decorate
  end

  def show
    @query_passport = @query_passport.decorate
  end

  private

  def set_query_passports
    @query_passports = QueryPassport.all.order(id: :desc)
  end

  def set_query_passport
    @query_passport = @query_passports.find(params[:id])
  end

end
