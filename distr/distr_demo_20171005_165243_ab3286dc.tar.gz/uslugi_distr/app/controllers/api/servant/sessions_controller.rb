class Api::Servant::SessionsController < Api::Servant::ApplicationController
  def show
  end
end
