class Api::Servant::CheckoutsController < Api::Servant::ApplicationController
  Addresses = {
    "ba563858-c6fa-4cdf-aa50-3af6c1288dd0":[
      {title: "Объект культурного наследия", type:"warning"},
      {title: "Ансамбль Казанского кремля", type:"danger"}
    ],
    "d5c53f2b-9b17-4e73-be35-0d2fa31c3f97":[
      {title: "Объект культурного наследия", type:"warning"}
    ]
  }
  def address
    render json: Addresses[params[:fias_id].to_sym].to_json
  end
end
