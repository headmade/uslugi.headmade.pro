class Api::Servant::UslugaRequestsController < Api::Servant::ApplicationController
  before_action :set_usluga_requests
  before_action :set_usluga_request, only: %i(show event)

  #before_action :set_external_system_request_types, only: %i(consult) # TODO: REVIVE THIS!

  before_action :set_passport, only: %i(create)
  before_action :set_agent, only: %i(create)
  before_action :set_organization_recipient, only: %i(create)

  def index
    prepare_list_response
  end

  def my
    @usluga_requests = @usluga_requests.where(servant_id: current_servant.id)
    prepare_list_response
  end

  def user_requests
    #@usluga_requests = @usluga_requests.with_work_for_servant
    prepare_list_response
  end

  def my_user_requests
    #@usluga_requests = @usluga_requests.with_work_for_servant.where(servant_id: current_servant.id)
    prepare_list_response
  end

  def consultations
    @usluga_requests = @usluga_requests.where(state: %i(created consultation consulted)) # TODO: убрать created, перенести в scope
    prepare_list_response
  end

  def my_consultations
    @usluga_requests = @usluga_requests.where(servant_id: current_servant.id).where(state: %i(created consultation consulted)) # TODO: убрать created, перенести в scope
    prepare_list_response
  end

  def show
    @usluga_request = @usluga_request.decorate
  end

  def create
    UslugaRequest.transaction do
      @usluga_request = current_servant.usluga_requests.build(passport: @passport, agent: @agent, organization_recipient: @organization_recipient)
      @usluga_request.update!(usluga_request_params())
      @usluga_request.begin_consultation!
    end
    @usluga_request = @usluga_request.decorate
    render :show
  end

  def event
    name = params[:name].to_s
    # TODO: check if permitted
    @usluga_request.send(name+'!', params[:data])
    @usluga_request = @usluga_request.decorate
    head :ok
  end

  private

  def prepare_list_response
    #TODO: use locale
    @filter_config = [
      {key: :new, name: 'Новые', style: :info},
      {key: :assigned, name: 'В работе', style: :primary},
      {key: :rejects, name: 'Отказано', style: :info},
      {key: :my, name: 'Мои', style: :warning},
      {key: :archive, name: 'Архив', style: :info},
    ]

    filter_default = %w(consultations my_consultations).include?(params[:action]) ? '' : :new
    filters = (params[:filter].present? ? params[:filter] : filter_default).to_s.split(',').map{|name| [name,1]}.to_h.with_indifferent_access

    @filter_config.each {|f| f[:active] = true if filters[f[:key]]}

    @usluga_requests = @usluga_requests.submitted if filters[:new]
    @usluga_requests = @usluga_requests.assigned if params[:action] == 'user_requests' && filters[:assigned]
    @usluga_requests = @usluga_requests.consultation if params[:action] == 'consultations' && filters[:assigned]
    @usluga_requests = @usluga_requests.rejected if filters[:rejects]
    @usluga_requests = @usluga_requests.where(servant_id: current_servant.id) if filters[:my]
    @usluga_requests = @usluga_requests.where(state: %i(accepted rejected)) if filters[:archive]

    @total_records = @usluga_requests.count

    @usluga_requests = @usluga_requests.page(params[:page]).per(params[:per])
    @total_pages = @usluga_requests.total_pages

    @usluga_requests = @usluga_requests.decorate
    render :index
  end

  def set_passport
    @passport = current_servant.passports.find(usluga_request_params[:data][:passport_id])
  end

  def set_usluga_requests
    #@usluga_requests = current_servant.usluga_requests
    @usluga_requests = UslugaRequest.with_passport_ids(current_servant.passport_ids)
    unless params[:id]
      sort_name = params[:sort_id].present? ? params[:sort_id] : :id
      sort_name = {
      }[sort_name] || sort_name
      sort_order = params[:sort_desc] == 'true' ? :desc : :asc
      @usluga_requests = @usluga_requests.order(sort_name => sort_order)
    end
  end

  def set_usluga_request
    @usluga_request = @usluga_requests.find(params[:id])
  end

  def set_agent
    data_agent = usluga_request_params[:data][:agent].permit(:passport_number, :mobile, :email, fio: {})
    @agent = AgentService.find_or_create_agent(data_agent.to_hash)
  end

  def set_organization_recipient
    return unless usluga_request_params[:data][:organization]
    data_organization = usluga_request_params[:data][:organization].permit(:inn, :phone, :mobile, :email)
    @organization_recipient = OrganizationRecipientService.find_or_create_organization_recipient(data_organization.to_hash)
  end

  def set_external_system_request_types
    @usluga_request.transaction do
      @usluga_request.external_system_requests.destroy_all
      usluga_request_consult_params[:data][:external_system_request_type_ids]&.each do |esrt_id|
        @usluga_request.external_system_requests.create!(external_system_request_type_id: esrt_id, data: {})
      end
    end
  end

  def usluga_request_params
    params.require(:usluga_request).permit!.tap do |p|
      p[:created_at] = Time.at(p[:data][:created_at]/1000.0) # TODO: wtf - client time :-?
    end
  end

  def usluga_request_consult_params
    return {} unless params[:usluga_request].present?
    params.require(:usluga_request).permit(data: [:comments, external_system_request_type_ids: []])
  end
end
