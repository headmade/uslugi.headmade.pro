class Api::Servant::OrganizationRecipientsController < Api::Servant::ApplicationController

  before_action :set_organization_recipients, only: %i(index)
  before_action :set_organization_recipient, only: %i(usluga_requests)

  def index
    @total_records = @organization_recipients.decorate.count
    @organization_recipients = @organization_recipients.decorate.page(params[:page]).per(params[:per])
    @total_pages = @organization_recipients.decorate.total_pages
    @organization_recipients = @organization_recipients.decorate
  end

  def usluga_requests
    @usluga_requests = @organization_recipient.usluga_requests
    @total_records = @usluga_requests.count
    @usluga_requests = @usluga_requests.page(params[:page]).per(params[:per])
    @total_pages = @usluga_requests.total_pages
    @usluga_requests = @usluga_requests.decorate
  end

  private

  def set_organization_recipients
    @organization_recipients = OrganizationRecipient.inn_like(params[:inn]).order(updated_at: :desc).limit(10)
  end

  def set_organization_recipient
    @organization_recipient = OrganizationRecipient.find(params[:id])
  end

end
