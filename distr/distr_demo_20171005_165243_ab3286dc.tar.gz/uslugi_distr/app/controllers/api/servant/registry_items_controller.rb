class Api::Servant::RegistryItemsController < Api::Servant::ApplicationController

  before_action :set_registry_items, only: %i(index)
  before_action :set_registry, only: %i(create)
  before_action :set_registry_item, only: %i(show update)

  def index
    @total_records = @registry_items.count
    @registry_items = @registry_items.page(params[:page]).per(params[:per])
    @total_pages = @registry_items.total_pages
    @registry_items = @registry_items.decorate
  end

  def show
    @registry_item = @registry_item.decorate
  end

  def create
    @registry_item = @registry.registry_items.create!(registry_item_params)
    @registry_item = @registry_item.decorate
    render :show
  end

  def update
    attrs = registry_item_params.to_hash
    attrs['data'] = S3Service.substitute_url_remove_query(attrs['data'])
    @registry_item.update(attrs)
    raise @registry_item.errors.inspect if @registry_item.errors.present?
    head :ok
  end

  private

  def set_registry_items
    @registry_items = RegistryItem.search_inn(params[:inn]).search_fias_id(params[:fias_id])
  end

  def set_registry_item
    @registry_item = RegistryItem.find(params[:id])
  end

  def set_registry
    @registry = Registry.find(registry_item_params[:data][:registry_id])
  end

  def registry_item_params
    params.require(:registry_item).permit(:registry_id, data: {})
  end

end
