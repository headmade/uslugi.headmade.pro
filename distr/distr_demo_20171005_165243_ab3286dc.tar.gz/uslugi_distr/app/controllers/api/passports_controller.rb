class Api::PassportsController < Api::ApplicationController
  # TODO: do we use it? - lev, 20170710
  def index
    @passports = Passport.all.decorate
  end

  def show
    @passport = Passport.find(params[:id]).decorate
  end
end
