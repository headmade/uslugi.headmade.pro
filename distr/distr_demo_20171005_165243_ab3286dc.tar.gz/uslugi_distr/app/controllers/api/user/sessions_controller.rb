class Api::User::SessionsController < Api::User::ApplicationController
  def show
  end
end
