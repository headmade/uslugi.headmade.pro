class Api::User::UslugaRequestsController < Api::User::ApplicationController

  before_action :link_existing_usluga_requests_by_agent, only: %i(index)

  before_action :set_usluga_requests
  before_action :set_passport, only: %i(create)
  before_action :set_agent, only: %i(create)
  before_action :set_organization_recipient, only: %i(create)

  before_action :set_usluga_request, only: %i(show event)

  def index
    @total_records = @usluga_requests.count
    @usluga_requests = @usluga_requests.page(params[:page]).per(params[:per])
    @total_pages = @usluga_requests.total_pages
    @usluga_requests = @usluga_requests.decorate
  end

  def show
    @usluga_request = @usluga_request.decorate
  end

  def create
    UslugaRequest.transaction do
      @usluga_request = current_user.usluga_requests.create!(
        passport: @passport,
        agent: @agent,
        organization_recipient: @organization_recipient,
        data: usluga_request_params[:data].merge('source' => '02_user'),
      )

      @usluga_request.submit!
    end
    @usluga_request = @usluga_request.decorate

    render :show
  end

  def event
    name = params[:name].to_s
    # TODO: check if permitted
    @usluga_request.send(name+'!', params[:data])
    @usluga_request = @usluga_request.decorate
    head :ok
  end

  private

  def link_existing_usluga_requests_by_agent
    # TODO: move to job
    agent_ids = Agent.where(mobile: current_user.mobile).pluck(:id)
    UslugaRequest.without_user.where(agent_id: agent_ids).each do |ur|
      ur.update!(user_id: current_user.id)
    end
  end

  def set_usluga_requests
    @usluga_requests = current_user.usluga_requests.not_consultations.where.not(state: :accepted)
  end

  def set_passport
    @passport = Passport.active.find(params[:usluga_request][:passport_id])
  end

  def set_usluga_request
    @usluga_request = current_user.usluga_requests.find(params[:id])
  end

  def set_agent
    data_agent = usluga_request_params[:data][:agent].permit(:passport_number, :mobile, :email, fio: {})
    @agent = AgentService.find_or_create_agent(data_agent.to_hash)
  end

  def set_organization_recipient
    data_organization = usluga_request_params[:data][:organization].permit(:inn, :phone, :mobile, :email)
    @organization_recipient = OrganizationRecipientService.find_or_create_organization_recipient(data_organization.to_hash)
  end

  def usluga_request_params()
    params.require(:usluga_request).permit!
    #params.require(:usluga_request).permit(data: {})
  end

end
