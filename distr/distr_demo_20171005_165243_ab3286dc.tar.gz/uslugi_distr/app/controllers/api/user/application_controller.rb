class Api::User::ApplicationController < Api::ApplicationController
end
