class Api::User::UslugasController < Api::User::ApplicationController

  before_action :link_existing_uslugas_by_agent, only: %i(index)

  before_action :set_uslugas
  before_action :set_usluga, only: %i(show)

  def index
    @total_records = @uslugas.count
    @uslugas = @uslugas.page(params[:page]).per(params[:per])
    @total_pages = @uslugas.total_pages
    @uslugas = UslugaUserDecorator.decorate_collection(@uslugas)
  end

  def show
    @usluga = UslugaUserDecorator.decorate(@usluga)
    respond_to do |format|
      format.json
      format.pdf
    end
  end

  def link_existing_uslugas_by_agent
    # TODO: move to job
    agent_ids = Agent.where(mobile: current_user.mobile).pluck(:id)
    Usluga.without_user.where(agent_id: agent_ids).each do |u|
      u.update!(user_id: current_user.id)
    end
  end

  private

  def set_uslugas
    @uslugas = current_user.uslugas
  end

  def set_usluga
    @usluga = @uslugas.find(params[:id])
  end

end
