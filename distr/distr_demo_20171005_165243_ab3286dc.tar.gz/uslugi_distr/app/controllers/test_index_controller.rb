class TestIndexController < ApplicationController
  def index
  end
end
