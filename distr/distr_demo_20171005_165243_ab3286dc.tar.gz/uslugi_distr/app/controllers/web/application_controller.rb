class Web::ApplicationController < ::ApplicationController
  #include AuthenticableWeb
  #include ActionContextable
  include InstanceVieweable

  before_action :prepend_instance_views_path

  def prepend_instance_views_path
    prepend_view_path(instance_views_path())
  end

  def exception(exc)
    logger.info "500: #{exc.message}: " + params.inspect
    render :file => "#{Rails.root}/public/500.html", status: 500, layout: false
  end

end
