class Web::User::WelcomeController < Web::User::ApplicationController
  def index
  end
end
