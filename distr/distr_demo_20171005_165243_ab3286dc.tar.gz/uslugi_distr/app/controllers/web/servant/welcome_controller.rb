class Web::Servant::WelcomeController < Web::Servant::ApplicationController
  def index
  end
end
