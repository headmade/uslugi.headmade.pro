# encoding: utf-8

class Web::SessionsController < Web::ApplicationController
  include AuthenticableWeb

  skip_before_action :authenticate!
  skip_before_action :check_role!
  #skip_before_action :set_default_action_context

  layout 'web/session'

  def new
    redirect_to current_user_main_role_path() if signed_in?
    @session = UserSignInType.new
  end

  def create
    @session = UserSignInType.new(session_params[:user_sign_in_type])
    @session.login ||= session[:login_to_confirm]

    #if @session.login =~ /\+79\d+/
    #  redirect_to default_auth_path
    #  return
    #end

    unless @session.user.present?
      password = generate_password()
      ActiveRecord::Base.transaction do
        identity = get_identity()
        unless identity.user.present?
          user = UserService.create_regular_user(@session.login.strip, password)
          identity.update!(user: user)
          @new_password_generated = true
        end
        @session.user = identity.user
      end
    end

    user = @session.user
    cu = user.decorate

    if @session.need_confirm?
      if user.updated_at < Time.now - 1.hour
        password = generate_password()
        user.update!(password: password)
        @new_password_generated = true
      end
      session[:login_to_confirm] = @session.login
      render :confirm
      return
    end

    if @session.valid?
      reset_session()

      sign_in(user)
      #Rollbar.info('Login successful', login: user.login, time: Time.now.to_s)

      Rails.logger.debug [:esia_roles, 2, cu.esia_roles()]

      if !user.admin? && cu.esia_roles()
        redirect_to organizations_session_path()
      else
        redirect_to current_user_main_role_path()
      end

    else
      render action: :new
    end
  end

  def destroy
    sign_out()
    if Rails.env.production?
      redirect_to "https://esia.gosuslugi.ru/idp/ext/Logout?client_id=#{Rails.application.config.x.esia.client_id}&redirect_url=#{Rails.application.config.x.base_url}/"
    else
      redirect_to default_auth_path
    end
  end

  def organizations
    @esia_roles = current_user.esia_roles()
  end

  def set_organization
    Servant.transaction do
      servant = UserService.create_servant_for_user(current_user)

      oid = params[:user]['oid'].to_s
      esia_role = current_user.esia_roles().select{ |er| er['oid'].to_s == oid.to_s }.first
      if esia_role.present?
        session[:esia_role] = esia_role
        unless current_servant.present?
          Rails.logger.debug [:init_servant_from_esia, esia_role, current_user]
          UserService.init_servant_from_esia(servant, esia_role)
        end
      end
    end

    redirect_to current_user_main_role_path()
  end

  private

  def auth_hash
    @auth_hash ||= if params[:provider].present?
      request.env['omniauth.auth']
    else
      @session = UserSignInType.new(session_params[:user_sign_in_type])
      @session.login ||= session[:login_to_confirm]
      mobile = @session.login.strip
      Hashie::Mash.new({
        provider: :mobile,
        uid: mobile,
        data: {provider: :mobile, uid: mobile}
      })
    end
  end

  def auth_provider_mobile?
    auth_hash.provider == :mobile
  end

  def get_identity()
    identity = UserIdentity.find_or_initialize_by(provider: auth_hash.provider, uid: auth_hash.uid)
    attrs = {data: auth_hash}
    if identity.new_record?
      attrs.merge!(user_id: get_user_id_from_matching_idendity())
    end
    identity.assign_attributes(attrs)
    return identity
  end

  def get_user_id_from_matching_idendity()
    auth_provider_mobile? ? get_user_id_from_matching_idendity_provider() : get_user_id_from_matching_idendity_mobile()
  end

  def get_user_id_from_matching_idendity_mobile()
    mobile = auth_hash.info.mobile
    if mobile.present?
      identity_mobile = UserIdentity.find_by(provider: :mobile, uid: mobile)
      return identity_mobile.user_id if identity_mobile.present?
    end
  end

  def get_user_id_from_matching_idendity_provider()
    identity_provider = UserIdentity.where("data->'info'->>'mobile' = ?", auth_hash.uid).first
    return identity_provider.user_id if identity_provider.present?
  end
  def session_params
    params.permit!
  end

end

