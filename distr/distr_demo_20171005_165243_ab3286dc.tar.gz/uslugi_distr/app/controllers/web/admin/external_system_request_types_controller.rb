class Web::Admin::ExternalSystemRequestTypesController < Web::Admin::ApplicationController
  before_action :set_external_system_request_type, only: %i(show edit update)
  before_action :set_external_system_request_types, only: %i(index)

  def index
    @external_system_request_types = @external_system_request_types.decorate
  end

  def show
    @external_system_request_type = @external_system_request_type.decorate
  end

  def new
    @external_system_request_type = ExternalSystemRequestType.new.decorate
  end

  def create
    @external_system_request_type = ExternalSystemRequestType.create(external_system_request_type_params)
    @external_system_request_type = @external_system_request_type.decorate
    if @external_system_request_type.errors.any?
      render :new
    else
      redirect_to admin_external_system_request_type_path(@external_system_request_type)
    end
  end

  def update
    @external_system_request_type.update(external_system_request_type_params)
    if @external_system_request_type.errors.any?
      render :edit
    else
      redirect_to admin_external_system_request_type_path(@external_system_request_type)
    end
  end

  private

  def set_external_system_request_type
    @external_system_request_type = ExternalSystemRequestType.find(params[:id])
  end

  def set_external_system_request_types
    @external_system_request_types = ExternalSystemRequestType.all
  end

  def external_system_request_type_params
    params.require(:external_system_request_type).permit(:name, :schema)
  end
end
