class Web::Admin::UsersController < Web::Admin::ApplicationController
  before_action :set_user, only: %i(show edit update)
  before_action :set_users, only: %i(index)

  def index
    @users = @users.order(:phone)
    @users = @users.decorate
  end

  def show
    @user = @user.decorate
  end

  def new
    @user_create_type = UserCreateType.new
  end

  def edit
    @user = @user.decorate
  end

  def create
    User.transaction do
      @user = User.new(user_params.to_hash.merge(state: :active, roles: %i(servant), servants: [::Servant.new(servant_params)]))
      @user = @user.decorate
      unless @user.save
        @user_create_type = UserCreateType.new(user_create_params)
        render :new
      else
        redirect_to admin_user_path(@user)
      end
    end
  end

  def update
    if params[:commit] == 'Create servant'
      UserService.create_servant_for_user(@user)
    else
      if @user.servant
        @user.servant.passport_ids = params[:user][:passport_ids]
        @user.servant.department_ids = params[:user][:department_ids]
      end
      @user.update(user_params.merge(roles: [user_params[:roles]]))
    end
    if @user.errors.any?
      render :edit
    else
      redirect_to admin_user_path(@user)
    end
  end

  private

  def set_user
    @user = User.find(params[:id])
  end

  def set_users
    @users = User.all.order(:phone)
  end

  def user_create_type_params
    params.require(:user).permit(:phone, :password, :surname, :name, :patronymic_name)
  end

  def user_params
    params.require(:user).permit(:phone, :password, :roles)
  end

  def servant_params
    params.require(:user).permit(:surname, :name, :patronymic_name)
  end
end
