class Web::Admin::QueryPassportsController < Web::Admin::ApplicationController
  before_action :set_query_passport, only: %i(show edit update)
  before_action :set_query_passports, only: %i(index)

  def index
    @query_passports = @query_passports.decorate
  end

  def show
    @query_passport = @query_passport.decorate
  end

  def new
    @query_passport = QueryPassport.new.decorate
  end

  def edit
    @query_passport = @query_passport.decorate
  end

  def create
    @query_passport = QueryPassport.create(query_passport_params)
    @query_passport = @query_passport.decorate
    if @query_passport.errors.any?
      render :new
    else
      redirect_to admin_query_passport_path(@query_passport)
    end
  end

  def update
    @query_passport.update(query_passport_params)
    if @query_passport.errors.any?
      render :edit
    else
      redirect_to admin_query_passport_path(@query_passport)
    end
  end

  private

  def set_query_passport
    @query_passport = QueryPassport.find(params[:id])
  end

  def set_query_passports
    @query_passports = QueryPassport.all
  end

  def query_passport_params
    params.require(:query_passport).permit!.tap do |p|
      p[:data] = JSON.parse(p[:data]) if p[:data].is_a?(String)
      p[:data] ||= {}
      p[:state] ||= :active
      p.permit!
    end
  end
end
