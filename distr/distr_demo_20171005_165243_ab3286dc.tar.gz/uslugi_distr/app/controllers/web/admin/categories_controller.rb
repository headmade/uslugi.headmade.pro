class Web::Admin::CategoriesController < Web::Admin::ApplicationController
  before_action :set_category, only: %i(show edit update)
  before_action :set_categories, only: %i(index)

  def index
    @categories = @categories.decorate
  end

  def show
    @category = @category.decorate
  end

  def new
    @category = Category.new.decorate
  end

  def create
    @category = Category.create(category_params)
    @category = @category.decorate
    if @category.errors.any?
      render :new
    else
      redirect_to admin_category_path(@category)
    end
  end

  def update
    @category.update(category_params)
    if @category.errors.any?
      render :edit
    else
      redirect_to admin_category_path(@category)
    end
  end

  private

  def set_category
    @category = Category.find(params[:id])
  end

  def set_categories
    @categories = Category.all
  end

  def category_params
    params.require(:category).permit(:name, :description, :icon)
  end
end
