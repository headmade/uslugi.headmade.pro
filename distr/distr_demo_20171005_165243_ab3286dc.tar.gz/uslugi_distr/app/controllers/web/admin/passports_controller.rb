class Web::Admin::PassportsController < Web::Admin::ApplicationController
  before_action :set_passport, only: %i(show edit update)
  before_action :set_passports, only: %i(index)

  def index
    @passports = @passports.decorate
  end

  def show
    @passport = @passport.decorate
  end

  def new
    @passport = Passport.new.decorate
  end

  def edit
    @passport = @passport.decorate
  end

  def create
    @passport = Passport.create(passport_params)
    @passport = @passport.decorate
    if @passport.errors.any?
      render :new
    else
      redirect_to admin_passport_path(@passport)
    end
  end

  def update
    @passport.update(passport_params)
    if @passport.errors.any?
      render :edit
    else
      redirect_to admin_passport_path(@passport)
    end
  end

  private

  def set_passport
    @passport = Passport.find(params[:id])
  end

  def set_passports
    @passports = Passport.all
  end

  def passport_params
    params.require(:passport).permit(:active, :name, :category_id, :description, :documents, :reglament, :duration, :data, servant_ids: [], external_system_request_type_ids: [], query_passport_ids: []).tap do |p|
      p[:data] = p[:data].present? ? JSON.parse(p[:data]) : nil
      p[:duration] = p[:duration].present? ? p[:duration] : 15*60*PassportDecorator::DURATION_FRACTION
    end
  end
end
