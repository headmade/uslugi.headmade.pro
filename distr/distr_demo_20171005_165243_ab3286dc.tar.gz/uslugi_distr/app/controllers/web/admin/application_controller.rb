class Web::Admin::ApplicationController < ::Web::ApplicationController
  include ActionContextable
  include AuthenticableWeb
  layout 'web/admin'
end
