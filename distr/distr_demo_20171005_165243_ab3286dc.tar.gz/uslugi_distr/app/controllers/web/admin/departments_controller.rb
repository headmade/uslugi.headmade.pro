class Web::Admin::DepartmentsController < Web::Admin::ApplicationController
  before_action :set_department, only: %i(show edit update)
  before_action :set_departments, only: %i(index)

  def index
    @departments = @departments.decorate
  end

  def show
    @department = @department.decorate
  end

  def new
    @department = Department.new.decorate
  end

  def create
    @department = Department.create(department_params)
    @department = @department.decorate
    if @department.errors.any?
      render :new
    else
      redirect_to admin_department_path(@department)
    end
  end

  def update
    @department.update(department_params)
    if @department.errors.any?
      render :edit
    else
      redirect_to admin_department_path(@department)
    end
  end

  private

  def set_department
    @department = Department.find(params[:id])
  end

  def set_departments
    @departments = Department.all
  end

  def department_params
    params.require(:department).permit(:short_name, :full_name, servant_ids: [], registry_ids: [])
  end
end
