class Web::HealthCheckController < Web::ApplicationController
  def index
    head :ok
  end
end
