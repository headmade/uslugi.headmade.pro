class Web::WelcomeController < Web::ApplicationController
  include AuthenticableWeb

  skip_before_action :authenticate!

  def index
  end
end
