module InstanceVieweable
  extend ActiveSupport::Concern

  def instance_views_path(instance_name=nil)
    instance_name ||= Rails.application.config.x.instance_name
    ['app/views', instance_name].join('/')
  end
end
