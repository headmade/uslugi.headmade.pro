module AuthenticableWeb
  extend ActiveSupport::Concern
  include Authenticable

  def authenticate!
    redirect_to default_auth_path unless signed_in?
  end

end

