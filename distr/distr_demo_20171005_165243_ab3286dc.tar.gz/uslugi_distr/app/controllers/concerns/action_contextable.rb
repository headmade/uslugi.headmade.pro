require 'action_context'
module ActionContextable
  extend ActiveSupport::Concern

  included do
    around_action :set_default_action_context
  end

  def set_default_action_context
    begin
      ActionContext.create
      ActionContext.current_user = current_user
      if current_user && current_user.servant
        ActionContext.current_servant = current_servant
      end
      ActionContext.current_role = required_role
      ActionContext.request_params = params.permit!.to_hash.freeze
      ActionContext.request_headers = request.headers.to_h.select{|k,v| v.is_a?(String)}.freeze
      ActionContext.request = request
      ActionContext.now = Time.now
      yield
    ensure
      ActionContext.destroy
    end
  end

end

