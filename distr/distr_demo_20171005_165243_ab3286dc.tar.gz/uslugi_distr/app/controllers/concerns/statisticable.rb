module Statisticable
  extend ActiveSupport::Concern


  KNOWN_STATISTICS_REPORTS = %w(
    top_agents_usluga_requests
    top_agents_uslugas
    top_organizations_usluga_requests
    top_organizations_uslugas
    distribution_time_usluga_requests
    distribution_time_uslugas
    count_per_hour_usluga_requests
    count_per_date_usluga_requests
    count_per_hour_uslugas
    count_per_date_uslugas
    share_per_external_system_request_type_usluga_requests
    share_per_passport_usluga_requests
    share_per_passport_uslugas
    percental_usluga_requests
    percental_uslugas
  )

  included do
    before_action :set_filters
  end

  def index
    render json: StatisticsService.build_reports(@filters, KNOWN_STATISTICS_REPORTS)
  end

  def report_key
    rk = params[:report_key]
    if KNOWN_STATISTICS_REPORTS.include?(rk)
      render json: StatisticsService.build_reports(@filters, [rk])
    else
      head :unprocessable_entity
    end
  end

  private

  def set_filters
    raise 'must overload set_filters()'
  end

end
