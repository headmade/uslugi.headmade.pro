module Authenticable
  extend ActiveSupport::Concern

  included do
    include AuthHelper
    include AuthRoleHelper

    before_action :authenticate!
    before_action :check_role!

    helper_method :current_user, :current_servant, :signed_in?, :required_role
    helper_method :default_auth_path
  end

  def default_auth_path
    Rails.application.config.x.instance.auth_path
  end

  def authenticate!
    raise 'must overload'
  end

  def check_role!
    if current_user && !current_user.has_role?(required_role)
      redirect_to current_user_main_role_path || :root
    end
  end

  def required_role
    @required_role ||= self.class.parent.name.demodulize.downcase.to_sym
  end

end

